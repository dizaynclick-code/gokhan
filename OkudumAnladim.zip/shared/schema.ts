import { sql } from "drizzle-orm";
import { pgTable, text, varchar, timestamp, integer, boolean, jsonb, uuid } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const users = pgTable("users", {
  id: uuid("id").primaryKey().default(sql`gen_random_uuid()`),
  username: text("username").notNull().unique(),
  email: text("email").notNull().unique(),
  password: text("password").notNull(),
  fullName: text("full_name"),
  phone: text("phone"),
  plan: text("plan").default("free"), // free, personal, professional, agency
  monthlyCharacterLimit: integer("monthly_character_limit").default(10000), // Free plan: 10k characters
  usedCharactersThisMonth: integer("used_characters_this_month").default(0),
  planExpiryDate: timestamp("plan_expiry_date"),
  monthlyResetDate: timestamp("monthly_reset_date").defaultNow(),
  isActive: boolean("is_active").default(true),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});


// Kullanıcı oturumları tablosu
export const userSessions = pgTable("user_sessions", {
  id: uuid("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: uuid("user_id").references(() => users.id).notNull(),
  token: text("token").notNull().unique(),
  expiresAt: timestamp("expires_at").notNull(),
  createdAt: timestamp("created_at").defaultNow(),
});

export const translations = pgTable("translations", {
  id: uuid("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: uuid("user_id").references(() => users.id).notNull(),
  sourceText: text("source_text").notNull(),
  translatedText: text("translated_text").notNull(),
  sourceLang: text("source_lang").notNull(),
  targetLang: text("target_lang").notNull(),
  model: text("model").default("gpt-4o"),
  category: text("category").default("general"), // Content category for specialized translations
  translationTime: integer("translation_time"), // in milliseconds
  quality: integer("quality"), // 1-5 rating
  createdAt: timestamp("created_at").defaultNow(),
});

export const documents = pgTable("documents", {
  id: uuid("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: uuid("user_id").references(() => users.id).notNull(),
  fileName: text("file_name").notNull(),
  originalContent: text("original_content").notNull(),
  translatedContent: text("translated_content"),
  sourceLang: text("source_lang").notNull(),
  targetLang: text("target_lang").notNull(),
  status: text("status").default("pending"), // pending, completed, failed
  createdAt: timestamp("created_at").defaultNow(),
});

export const audioTranscriptions = pgTable("audio_transcriptions", {
  id: uuid("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: uuid("user_id").references(() => users.id).notNull(),
  fileName: text("file_name").notNull(),
  transcription: text("transcription"),
  language: text("language").notNull(),
  duration: integer("duration"), // in seconds
  status: text("status").default("pending"),
  createdAt: timestamp("created_at").defaultNow(),
});

export const glossary = pgTable("glossary", {
  id: uuid("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: uuid("user_id").references(() => users.id).notNull(),
  sourceTerm: text("source_term").notNull(),
  targetTerm: text("target_term").notNull(),
  sourceLang: text("source_lang").notNull(),
  targetLang: text("target_lang").notNull(),
  context: text("context"),
  createdAt: timestamp("created_at").defaultNow(),
});

export const translationMemory = pgTable("translation_memory", {
  id: uuid("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: uuid("user_id").references(() => users.id).notNull(),
  sourceSegment: text("source_segment").notNull(),
  targetSegment: text("target_segment").notNull(),
  sourceLang: text("source_lang").notNull(),
  targetLang: text("target_lang").notNull(),
  matchScore: integer("match_score").default(100), // percentage
  context: text("context"),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

export const teams = pgTable("teams", {
  id: uuid("id").primaryKey().default(sql`gen_random_uuid()`),
  name: text("name").notNull(),
  description: text("description"),
  ownerId: uuid("owner_id").references(() => users.id).notNull(),
  createdAt: timestamp("created_at").defaultNow(),
});

export const teamMembers = pgTable("team_members", {
  id: uuid("id").primaryKey().default(sql`gen_random_uuid()`),
  teamId: uuid("team_id").references(() => teams.id).notNull(),
  userId: uuid("user_id").references(() => users.id).notNull(),
  role: text("role").default("member"), // owner, admin, member
  joinedAt: timestamp("joined_at").defaultNow(),
});

export const projects = pgTable("projects", {
  id: uuid("id").primaryKey().default(sql`gen_random_uuid()`),
  name: text("name").notNull(),
  description: text("description"),
  teamId: uuid("team_id").references(() => teams.id),
  userId: uuid("user_id").references(() => users.id).notNull(),
  sourceLang: text("source_lang").notNull(),
  targetLang: text("target_lang").notNull(),
  status: text("status").default("active"), // active, completed, archived
  createdAt: timestamp("created_at").defaultNow(),
});

export const catProjects = pgTable("cat_projects", {
  id: uuid("id").primaryKey().default(sql`gen_random_uuid()`),
  name: text("name").notNull(),
  userId: uuid("user_id").references(() => users.id).notNull(),
  sourceLanguage: text("source_language").notNull(),
  targetLanguage: text("target_language").notNull(),
  fileFormat: text("file_format").notNull(), // xliff, tmx, tbx, sdlxliff
  status: text("status").default("importing"), // importing, ready, processing, completed, error
  segmentCount: integer("segment_count").default(0),
  translatedCount: integer("translated_count").default(0),
  createdAt: timestamp("created_at").defaultNow(),
});


// Insert schemas
export const insertUserSchema = createInsertSchema(users).omit({
  id: true,
  createdAt: true,
});

export const insertTranslationSchema = createInsertSchema(translations).omit({
  id: true,
  createdAt: true,
});

export const insertDocumentSchema = createInsertSchema(documents).omit({
  id: true,
  createdAt: true,
});

export const insertAudioTranscriptionSchema = createInsertSchema(audioTranscriptions).omit({
  id: true,
  createdAt: true,
});

export const insertGlossarySchema = createInsertSchema(glossary).omit({
  id: true,
  createdAt: true,
});

export const insertTranslationMemorySchema = createInsertSchema(translationMemory).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export const insertTeamSchema = createInsertSchema(teams).omit({
  id: true,
  createdAt: true,
});

export const insertTeamMemberSchema = createInsertSchema(teamMembers).omit({
  id: true,
  joinedAt: true,
});

export const insertProjectSchema = createInsertSchema(projects).omit({
  id: true,
  createdAt: true,
});



export const insertUserSessionSchema = createInsertSchema(userSessions).omit({
  id: true,
  createdAt: true,
});

export const insertCatProjectSchema = createInsertSchema(catProjects).omit({
  id: true,
  createdAt: true,
});

// Types
export type User = typeof users.$inferSelect;
export type InsertUser = z.infer<typeof insertUserSchema>;
export type UserSession = typeof userSessions.$inferSelect;
export type InsertUserSession = z.infer<typeof insertUserSessionSchema>;
export type Translation = typeof translations.$inferSelect;
export type InsertTranslation = z.infer<typeof insertTranslationSchema>;
export type Document = typeof documents.$inferSelect;
export type InsertDocument = z.infer<typeof insertDocumentSchema>;
export type AudioTranscription = typeof audioTranscriptions.$inferSelect;
export type InsertAudioTranscription = z.infer<typeof insertAudioTranscriptionSchema>;
export type Glossary = typeof glossary.$inferSelect;
export type InsertGlossary = z.infer<typeof insertGlossarySchema>;
export type TranslationMemory = typeof translationMemory.$inferSelect;
export type InsertTranslationMemory = z.infer<typeof insertTranslationMemorySchema>;
export type Team = typeof teams.$inferSelect;
export type InsertTeam = z.infer<typeof insertTeamSchema>;
export type TeamMember = typeof teamMembers.$inferSelect;
export type InsertTeamMember = z.infer<typeof insertTeamMemberSchema>;
export type Project = typeof projects.$inferSelect;
export type InsertProject = z.infer<typeof insertProjectSchema>;
export type CatProject = typeof catProjects.$inferSelect;
export type InsertCatProject = z.infer<typeof insertCatProjectSchema>;
