import { drizzle } from "drizzle-orm/postgres-js";
import postgres from "postgres";
import { eq, desc, and, like, or, sql as sqlOp } from "drizzle-orm";
import {
  type User, type InsertUser,
  type UserSession, type InsertUserSession,
  type Translation, type InsertTranslation,
  type Document, type InsertDocument,
  type AudioTranscription, type InsertAudioTranscription,
  type Glossary, type InsertGlossary,
  type TranslationMemory, type InsertTranslationMemory,
  type Team, type InsertTeam,
  type TeamMember, type InsertTeamMember,
  type Project, type InsertProject,
  type CatProject, type InsertCatProject,
  users, userSessions, translations, documents, audioTranscriptions, glossary,
  translationMemory, teams, teamMembers, projects, catProjects
} from "@shared/schema";

const sql = postgres(process.env.DATABASE_URL!, {
  // Supabase için özelleştirilmiş bağlantı ayarları
  connect_timeout: 60, // 60 saniye timeout
  idle_timeout: 20, // 20 saniye idle timeout
  max: 10, // Maksimum bağlantı sayısı
  ssl: 'require', // SSL zorunlu
  // Supabase connection pooling için gerekli
  prepare: false,
  // Bağlantı havuzu yönetimi
  max_lifetime: 60 * 30 // 30 dakika
});
const db = drizzle(sql);

export interface IStorage {
  // Users
  getUser(id: string): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  getUserByEmail(email: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  updateUser(id: string, updates: Partial<User>): Promise<void>;


  // User Sessions
  createUserSession(session: InsertUserSession): Promise<UserSession>;
  getUserSession(token: string): Promise<UserSession | undefined>;
  deleteUserSession(token: string): Promise<void>;
  cleanupExpiredSessions(): Promise<void>;

  // Translations
  createTranslation(translation: InsertTranslation): Promise<Translation>;
  getTranslations(userId: string, limit?: number): Promise<Translation[]>;
  updateTranslationQuality(id: string, quality: number): Promise<void>;

  // Documents
  createDocument(document: InsertDocument): Promise<Document>;
  getDocuments(userId: string): Promise<Document[]>;
  updateDocument(id: string, updates: Partial<Document>): Promise<void>;

  // Audio Transcriptions
  createAudioTranscription(transcription: InsertAudioTranscription): Promise<AudioTranscription>;
  getAudioTranscriptions(userId: string): Promise<AudioTranscription[]>;
  updateAudioTranscription(id: string, updates: Partial<AudioTranscription>): Promise<void>;

  // Glossary
  createGlossaryEntry(entry: InsertGlossary): Promise<Glossary>;
  getGlossaryEntries(userId: string, sourceLang?: string, targetLang?: string): Promise<Glossary[]>;
  deleteGlossaryEntry(id: string, userId: string): Promise<void>;

  // Translation Memory
  createTranslationMemoryEntry(entry: InsertTranslationMemory): Promise<TranslationMemory>;
  getTranslationMemoryEntries(userId: string, sourceLang?: string, targetLang?: string, search?: string): Promise<TranslationMemory[]>;
  deleteTranslationMemoryEntry(id: string, userId: string): Promise<void>;
  findTranslationMemoryMatches(text: string, sourceLang: string, targetLang: string, userId: string): Promise<TranslationMemory[]>;

  // Teams
  createTeam(team: InsertTeam): Promise<Team>;
  getTeams(userId: string): Promise<Team[]>;
  getTeam(id: string): Promise<Team | undefined>;
  deleteTeam(id: string, userId: string): Promise<void>;

  // Team Members
  addTeamMember(member: InsertTeamMember): Promise<TeamMember>;
  getTeamMembers(teamId: string): Promise<(TeamMember & { user: User })[]>;
  removeTeamMember(teamId: string, userId: string): Promise<void>;

  // Projects
  createProject(project: InsertProject): Promise<Project>;
  getProjects(userId: string, teamId?: string): Promise<Project[]>;
  updateProject(id: string, updates: Partial<Project>): Promise<void>;


  // CAT Projects
  createCatProject(project: InsertCatProject): Promise<CatProject>;
  getCatProjects(userId: string): Promise<CatProject[]>;
  updateCatProject(id: string, updates: Partial<CatProject>): Promise<void>;

  // Alias methods for CAT tools compatibility
  getGlossary(userId: string, filters: any): Promise<Glossary[]>;
  getTranslationMemory(userId: string, filters: any): Promise<TranslationMemory[]>;
}

export class DatabaseStorage implements IStorage {
  async getUser(id: string): Promise<User | undefined> {
    try {
      const result = await db.select().from(users).where(eq(users.id, id)).limit(1);
      return result[0];
    } catch (error) {
      console.error('Kullanıcı getirilirken hata:', error);
      throw error;
    }
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    try {
      const result = await db.select().from(users).where(eq(users.username, username)).limit(1);
      return result[0];
    } catch (error) {
      console.error('Kullanıcı adıyla kullanıcı getirilirken hata:', error);
      throw error;
    }
  }

  async getUserByEmail(email: string): Promise<User | undefined> {
    try {
      const result = await db.select().from(users).where(eq(users.email, email)).limit(1);
      return result[0];
    } catch (error) {
      console.error('Email ile kullanıcı getirilirken hata:', error);
      throw error;
    }
  }

  async createUser(user: InsertUser): Promise<User> {
    try {
      const result = await db.insert(users).values(user).returning();
      return result[0];
    } catch (error) {
      console.error('Kullanıcı oluşturulurken hata:', error);
      throw error;
    }
  }

  async updateUser(id: string, updates: Partial<User>): Promise<void> {
    try {
      await db.update(users).set({
        ...updates,
        updatedAt: new Date()
      }).where(eq(users.id, id));
    } catch (error) {
      console.error('Kullanıcı güncellenirken hata:', error);
      throw error;
    }
  }


  // User Session metodları
  async createUserSession(session: InsertUserSession): Promise<UserSession> {
    try {
      const result = await db.insert(userSessions).values(session).returning();
      return result[0];
    } catch (error) {
      console.error('Kullanıcı oturumu oluşturulurken hata:', error);
      throw error;
    }
  }

  async getUserSession(token: string): Promise<UserSession | undefined> {
    try {
      const result = await db.select().from(userSessions)
        .where(eq(userSessions.token, token))
        .limit(1);
      return result[0];
    } catch (error) {
      console.error('Kullanıcı oturumu getirilirken hata:', error);
      throw error;
    }
  }

  async deleteUserSession(token: string): Promise<void> {
    try {
      await db.delete(userSessions).where(eq(userSessions.token, token));
    } catch (error) {
      console.error('Kullanıcı oturumu silinirken hata:', error);
      throw error;
    }
  }

  async cleanupExpiredSessions(): Promise<void> {
    try {
      await db.delete(userSessions).where(
        sqlOp`expires_at < now()`
      );
    } catch (error) {
      console.error('Süresi dolmuş oturumlar temizlenirken hata:', error);
      throw error;
    }
  }

  async createTranslation(translation: InsertTranslation): Promise<Translation> {
    try {
      const result = await db.insert(translations).values(translation).returning();
      return result[0];
    } catch (error) {
      console.error('Çeviri oluşturulurken hata:', error);
      throw error;
    }
  }

  async getTranslations(userId: string, limit = 50): Promise<Translation[]> {
    try {
      return await db.select().from(translations)
        .where(eq(translations.userId, userId))
        .orderBy(desc(translations.createdAt))
        .limit(limit);
    } catch (error) {
      console.error('Çeviriler getirilirken hata:', error);
      throw error;
    }
  }

  async updateTranslationQuality(id: string, quality: number): Promise<void> {
    await db.update(translations).set({ quality }).where(eq(translations.id, id));
  }

  async createDocument(document: InsertDocument): Promise<Document> {
    const result = await db.insert(documents).values(document).returning();
    return result[0];
  }

  async getDocuments(userId: string): Promise<Document[]> {
    try {
      return await db.select().from(documents)
        .where(eq(documents.userId, userId))
        .orderBy(desc(documents.createdAt));
    } catch (error) {
      console.error('Belgeler getirilirken hata:', error);
      throw error;
    }
  }

  async updateDocument(id: string, updates: Partial<Document>): Promise<void> {
    await db.update(documents).set(updates).where(eq(documents.id, id));
  }

  async createAudioTranscription(transcription: InsertAudioTranscription): Promise<AudioTranscription> {
    const result = await db.insert(audioTranscriptions).values(transcription).returning();
    return result[0];
  }

  async getAudioTranscriptions(userId: string): Promise<AudioTranscription[]> {
    return await db.select().from(audioTranscriptions)
      .where(eq(audioTranscriptions.userId, userId))
      .orderBy(desc(audioTranscriptions.createdAt));
  }

  async updateAudioTranscription(id: string, updates: Partial<AudioTranscription>): Promise<void> {
    await db.update(audioTranscriptions).set(updates).where(eq(audioTranscriptions.id, id));
  }

  async createGlossaryEntry(entry: InsertGlossary): Promise<Glossary> {
    const result = await db.insert(glossary).values(entry).returning();
    return result[0];
  }

  async getGlossaryEntries(userId: string, sourceLang?: string, targetLang?: string): Promise<Glossary[]> {
    const conditions = [eq(glossary.userId, userId)];
    
    if (sourceLang && targetLang) {
      conditions.push(eq(glossary.sourceLang, sourceLang));
      conditions.push(eq(glossary.targetLang, targetLang));
    }
    
    return await db.select().from(glossary)
      .where(and(...conditions))
      .orderBy(desc(glossary.createdAt));
  }

  async deleteGlossaryEntry(id: string, userId: string): Promise<void> {
    await db.delete(glossary).where(and(
      eq(glossary.id, id),
      eq(glossary.userId, userId)
    ));
  }

  async createTranslationMemoryEntry(entry: InsertTranslationMemory): Promise<TranslationMemory> {
    const result = await db.insert(translationMemory).values(entry).returning();
    return result[0];
  }

  async getTranslationMemoryEntries(userId: string, sourceLang?: string, targetLang?: string, search?: string): Promise<TranslationMemory[]> {
    let conditions = [eq(translationMemory.userId, userId)];
    
    if (sourceLang && targetLang) {
      conditions.push(
        eq(translationMemory.sourceLang, sourceLang),
        eq(translationMemory.targetLang, targetLang)
      );
    }
    
    if (search) {
      conditions.push(
        or(
          like(translationMemory.sourceSegment, `%${search}%`),
          like(translationMemory.targetSegment, `%${search}%`)
        )!
      );
    }
    
    return await db.select().from(translationMemory)
      .where(and(...conditions))
      .orderBy(desc(translationMemory.updatedAt));
  }

  async deleteTranslationMemoryEntry(id: string, userId: string): Promise<void> {
    await db.delete(translationMemory).where(and(
      eq(translationMemory.id, id),
      eq(translationMemory.userId, userId)
    ));
  }

  async findTranslationMemoryMatches(text: string, sourceLang: string, targetLang: string, userId: string): Promise<TranslationMemory[]> {
    return await db.select().from(translationMemory)
      .where(and(
        eq(translationMemory.userId, userId),
        eq(translationMemory.sourceLang, sourceLang),
        eq(translationMemory.targetLang, targetLang),
        like(translationMemory.sourceSegment, `%${text}%`)
      ))
      .orderBy(desc(translationMemory.matchScore))
      .limit(5);
  }

  async createTeam(team: InsertTeam): Promise<Team> {
    const result = await db.insert(teams).values(team).returning();
    return result[0];
  }

  async getTeams(userId: string): Promise<Team[]> {
    return await db.select().from(teams)
      .where(eq(teams.ownerId, userId))
      .orderBy(desc(teams.createdAt));
  }

  async getTeam(id: string): Promise<Team | undefined> {
    const result = await db.select().from(teams).where(eq(teams.id, id)).limit(1);
    return result[0];
  }

  async deleteTeam(id: string, userId: string): Promise<void> {
    await db.delete(teams).where(and(
      eq(teams.id, id),
      eq(teams.ownerId, userId)
    ));
  }

  async addTeamMember(member: InsertTeamMember): Promise<TeamMember> {
    const result = await db.insert(teamMembers).values(member).returning();
    return result[0];
  }

  async getTeamMembers(teamId: string): Promise<(TeamMember & { user: User })[]> {
    return await db.select({
      id: teamMembers.id,
      teamId: teamMembers.teamId,
      userId: teamMembers.userId,
      role: teamMembers.role,
      joinedAt: teamMembers.joinedAt,
      user: users
    }).from(teamMembers)
      .innerJoin(users, eq(teamMembers.userId, users.id))
      .where(eq(teamMembers.teamId, teamId));
  }

  async removeTeamMember(teamId: string, userId: string): Promise<void> {
    await db.delete(teamMembers).where(and(
      eq(teamMembers.teamId, teamId),
      eq(teamMembers.userId, userId)
    ));
  }

  async createProject(project: InsertProject): Promise<Project> {
    const result = await db.insert(projects).values(project).returning();
    return result[0];
  }

  async getProjects(userId: string, teamId?: string): Promise<Project[]> {
    const conditions = [eq(projects.userId, userId)];
    
    if (teamId) {
      conditions.push(eq(projects.teamId, teamId));
    }
    
    return await db.select().from(projects)
      .where(and(...conditions))
      .orderBy(desc(projects.createdAt));
  }

  async updateProject(id: string, updates: Partial<Project>): Promise<void> {
    await db.update(projects).set(updates).where(eq(projects.id, id));
  }


  // CAT Projects metodları
  async createCatProject(project: InsertCatProject): Promise<CatProject> {
    const result = await db.insert(catProjects).values(project).returning();
    return result[0];
  }

  async getCatProjects(userId: string): Promise<CatProject[]> {
    return await db.select().from(catProjects)
      .where(eq(catProjects.userId, userId))
      .orderBy(desc(catProjects.createdAt));
  }

  async updateCatProject(id: string, updates: Partial<CatProject>): Promise<void> {
    await db.update(catProjects).set(updates).where(eq(catProjects.id, id));
  }

  // CAT tools uyumluluğu için alias metodlar
  async getGlossary(userId: string, filters: any): Promise<Glossary[]> {
    const { sourceLang, targetLang } = filters;
    return this.getGlossaryEntries(userId, sourceLang, targetLang);
  }

  async getTranslationMemory(userId: string, filters: any): Promise<TranslationMemory[]> {
    const { sourceLang, targetLang, search } = filters;
    return this.getTranslationMemoryEntries(userId, sourceLang, targetLang, search);
  }
}

export const storage = new DatabaseStorage();
