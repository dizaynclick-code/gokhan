import type { Express, Request, Response, NextFunction } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { insertTranslationSchema, insertDocumentSchema, insertAudioTranscriptionSchema, insertGlossarySchema, insertTranslationMemorySchema, insertTeamSchema, insertProjectSchema, insertUserSchema, insertUserSessionSchema } from "@shared/schema";
import OpenAI from "openai";
import { z } from "zod";
import axios from "axios";
import crypto from "crypto";
import bcrypt from "bcrypt";
import multer from "multer";
import xml2js from "xml2js";
import fs from "fs/promises";
import path from "path";

const openai = new OpenAI({ 
  apiKey: process.env.OPENAI_API_KEY || process.env.VITE_OPENAI_API_KEY || "default_key" 
});

// DeepL API configuration
const DEEPL_API_URL = "https://api-free.deepl.com/v2/translate";
const DEEPL_API_KEY = process.env.DEEPL_API_KEY;

// Supported languages with their configurations
const SUPPORTED_LANGUAGES: Record<string, { name: string; code: string; deepl?: string }> = {
  "tr": { name: "Turkish", code: "tr", deepl: "TR" },
  "en": { name: "English", code: "en", deepl: "EN-US" },
  "fr": { name: "French", code: "fr", deepl: "FR" },
  "nl": { name: "Dutch", code: "nl", deepl: "NL" },
  "no": { name: "Norwegian", code: "no", deepl: "NB" },
  "sv": { name: "Swedish", code: "sv", deepl: "SV" },
  "de": { name: "German", code: "de", deepl: "DE" },
  "es": { name: "Spanish", code: "es", deepl: "ES" },
  "it": { name: "Italian", code: "it", deepl: "IT" },
  "pt": { name: "Portuguese", code: "pt", deepl: "PT-PT" },
  "ru": { name: "Russian", code: "ru", deepl: "RU" },
  "ja": { name: "Japanese", code: "ja", deepl: "JA" },
  "ko": { name: "Korean", code: "ko", deepl: "KO" },
  "zh": { name: "Chinese", code: "zh", deepl: "ZH" },
  "ar": { name: "Arabic", code: "ar" }
};

// Content categories with specialized translation requirements
const CONTENT_CATEGORIES: Record<string, { name: string; description: string; keywords: string[]; tone: string }> = {
  "health": {
    name: "Sağlık",
    description: "Medical, healthcare, and wellness content",
    keywords: ["sağlık", "tıp", "tedavi", "hasta", "doktor", "hastane", "ilaç", "tanı"],
    tone: "Professional, trustworthy, and reassuring. Use medical terminology accurately while remaining accessible."
  },
  "technology": {
    name: "Teknoloji",
    description: "IT, software, hardware, and tech industry content",
    keywords: ["teknoloji", "yazılım", "donanım", "dijital", "uygulama", "platform", "sistem", "AI"],
    tone: "Technical but accessible, innovative, and forward-thinking. Use established tech terminology."
  },
  "fashion": {
    name: "Moda",
    description: "Fashion, clothing, style, and lifestyle content",
    keywords: ["moda", "stil", "giyim", "trend", "tasarım", "koleksiyon", "sezon", "aksesuar"],
    tone: "Stylish, trendy, and aspirational. Use fashion-forward language that inspires."
  },
  "food": {
    name: "Gıda",
    description: "Food, recipes, nutrition, and culinary content",
    keywords: ["yemek", "tarif", "mutfak", "beslenme", "lezzet", "malzeme", "pişirme", "restorant"],
    tone: "Appetizing, descriptive, and engaging. Make food sound delicious and achievable."
  },
  "travel": {
    name: "Seyahat",
    description: "Travel, tourism, and destination content",
    keywords: ["seyahat", "turizm", "tatil", "destinasyon", "otel", "uçak", "rezervasyon", "gezi"],
    tone: "Inspiring, adventurous, and informative. Evoke wanderlust and excitement."
  },
  "education": {
    name: "Eğitim",
    description: "Educational, academic, and learning content",
    keywords: ["eğitim", "öğrenme", "ders", "kurs", "okul", "öğrenci", "öğretmen", "akademik"],
    tone: "Clear, educational, and encouraging. Make learning accessible and engaging."
  },
  "finance": {
    name: "Finans",
    description: "Financial, banking, and investment content",
    keywords: ["finans", "para", "yatırım", "banka", "kredi", "faiz", "ekonomi", "borsa"],
    tone: "Professional, trustworthy, and authoritative. Build confidence in financial decisions."
  },
  "real_estate": {
    name: "Gayrimenkul",
    description: "Real estate, property, and housing content",
    keywords: ["gayrimenkul", "ev", "emlak", "mülk", "satış", "kiralık", "yatırım", "konut"],
    tone: "Professional, detailed, and persuasive. Help users make important property decisions."
  },
  "automotive": {
    name: "Otomotiv",
    description: "Cars, automotive industry, and transportation content",
    keywords: ["otomobil", "araba", "motor", "sürücü", "araç", "yakıt", "servis", "satış"],
    tone: "Knowledgeable, performance-focused, and exciting. Appeal to automotive enthusiasts."
  },
  "sports": {
    name: "Spor",
    description: "Sports, fitness, and athletic content",
    keywords: ["spor", "fitness", "egzersiz", "antrenman", "takım", "oyuncu", "maç", "şampiyonluk"],
    tone: "Energetic, motivational, and competitive. Inspire action and achievement."
  },
  "music": {
    name: "Müzik",
    description: "Music, entertainment, and audio content",
    keywords: ["müzik", "şarkı", "albüm", "sanatçı", "konser", "enstrüman", "melodi", "ritim"],
    tone: "Creative, emotional, and expressive. Capture the feeling and artistry of music."
  },
  "film": {
    name: "Film",
    description: "Movies, cinema, and entertainment content",
    keywords: ["film", "sinema", "oyuncu", "yönetmen", "senaryo", "yapım", "festival", "ödül"],
    tone: "Cinematic, dramatic, and engaging. Bring stories and characters to life."
  },
  "books": {
    name: "Kitap",
    description: "Books, literature, and publishing content",
    keywords: ["kitap", "yazar", "roman", "hikaye", "yayın", "okur", "edebiyat", "basım"],
    tone: "Literary, thoughtful, and intellectual. Appeal to readers and book lovers."
  },
  "games": {
    name: "Oyun",
    description: "Gaming, video games, and interactive entertainment",
    keywords: ["oyun", "oyuncu", "konsol", "PC", "mobil", "strateji", "aksiyon", "turnuva"],
    tone: "Exciting, competitive, and immersive. Engage gaming communities effectively."
  },
  "news": {
    name: "Haber",
    description: "News, journalism, and current events content",
    keywords: ["haber", "gündem", "olay", "basın", "gazete", "dergi", "röportaj", "analiz"],
    tone: "Objective, informative, and timely. Present facts clearly and professionally."
  },
  "blog": {
    name: "Blog",
    description: "Blog posts, personal content, and opinion pieces",
    keywords: ["blog", "makale", "görüş", "deneyim", "paylaşım", "kişisel", "yorum", "hikaye"],
    tone: "Personal, conversational, and authentic. Connect with readers on a human level."
  },
  "ecommerce": {
    name: "E-ticaret",
    description: "E-commerce, online shopping, and retail content",
    keywords: ["alışveriş", "satın alma", "ürün", "fiyat", "indirim", "kampanya", "kargo", "iade"],
    tone: "Persuasive, clear, and customer-focused. Drive conversions and sales."
  },
  "legal": {
    name: "Hukuk",
    description: "Legal, law, and regulatory content",
    keywords: ["hukuk", "kanun", "mevzuat", "mahkeme", "avukat", "dava", "sözleşme", "haklar"],
    tone: "Precise, authoritative, and formal. Ensure legal accuracy and clarity."
  },
  "hr": {
    name: "İnsan Kaynakları",
    description: "Human resources, recruitment, and workplace content",
    keywords: ["işe alım", "kariyer", "çalışan", "şirket", "maaş", "pozisyon", "CV", "mülakat"],
    tone: "Professional, supportive, and growth-oriented. Foster career development."
  },
  "psychology": {
    name: "Psikoloji",
    description: "Psychology, mental health, and behavioral content",
    keywords: ["psikoloji", "zihinsel sağlık", "davranış", "duygular", "terapi", "gelişim", "kişilik", "stres"],
    tone: "Empathetic, supportive, and scientifically grounded. Promote well-being."
  }
};

// DeepL language mapping (legacy support)
const DEEPL_LANGUAGE_MAP: Record<string, string> = {
  "en": "EN-US",
  "tr": "TR",
  "fr": "FR",
  "de": "DE",
  "es": "ES",
  "it": "IT",
  "pt": "PT-PT",
  "ru": "RU",
  "ja": "JA",
  "ko": "KO",
  "zh": "ZH",
  "nl": "NL",
  "no": "NB",
  "sv": "SV"
};

// DeepL translation function
async function translateWithDeepL(text: string, sourceLang: string, targetLang: string): Promise<string> {
  if (!DEEPL_API_KEY) {
    throw new Error("DeepL API key not configured");
  }

  const sourceCode = DEEPL_LANGUAGE_MAP[sourceLang];
  const targetCode = DEEPL_LANGUAGE_MAP[targetLang];

  if (!sourceCode || !targetCode) {
    throw new Error(`Language not supported by DeepL: ${sourceLang} -> ${targetLang}`);
  }

  const response = await axios.post(DEEPL_API_URL, {
    auth_key: DEEPL_API_KEY,
    text: [text],
    source_lang: sourceCode,
    target_lang: targetCode,
    preserve_formatting: true
  }, {
    headers: {
      'Content-Type': 'application/x-www-form-urlencoded'
    },
    transformRequest: [(data) => {
      return Object.keys(data)
        .map(key => {
          if (Array.isArray(data[key])) {
            return data[key].map((item: any) => `${key}=${encodeURIComponent(item)}`).join('&');
          }
          return `${key}=${encodeURIComponent(data[key])}`;
        })
        .join('&');
    }]
  });

  if (response.data.translations && response.data.translations.length > 0) {
    return response.data.translations[0].text;
  }

  throw new Error("DeepL translation failed");
}

// Session management
interface AuthRequest extends Request {
  userId?: string;
  user?: any;
}

// Authentication middleware
async function authenticate(req: AuthRequest, res: Response, next: NextFunction) {
  try {
    const token = req.headers.authorization?.replace('Bearer ', '');
    
    if (!token) {
      return res.status(401).json({ error: 'Token gerekli' });
    }

    const session = await storage.getUserSession(token);
    
    if (!session) {
      return res.status(401).json({ error: 'Geçersiz token' });
    }

    if (new Date() > session.expiresAt) {
      await storage.deleteUserSession(token);
      return res.status(401).json({ error: 'Token süresi dolmuş' });
    }

    const user = await storage.getUser(session.userId);
    
    if (!user || !user.isActive) {
      return res.status(401).json({ error: 'Kullanıcı bulunamadı veya aktif değil' });
    }

    req.userId = user.id;
    req.user = user;
    next();
  } catch (error) {
    console.error('Authentication error:', error);
    res.status(401).json({ error: 'Kimlik doğrulama hatası' });
  }
}

// Token oluşturma fonksiyonu
function generateToken(): string {
  return crypto.randomBytes(32).toString('hex');
}

// Mock user for development (fallback)
const MOCK_USER_ID = "cd29f029-8206-44ae-994c-0dd92ff3486b"; // Test kullanıcısının gerçek ID'si

export async function registerRoutes(app: Express): Promise<Server> {
  // Database connection validation
  try {
    console.log('Validating database connection...');
    
    // Test database connection by performing a simple query
    await storage.cleanupExpiredSessions();
    
    console.log('Database connection validated successfully');
  } catch (error: any) {
    console.error('Database connection failed:', error.message);
    console.error('Error details:', error);
    throw new Error(`Database connection failed: ${error.message}`);
  }
  
  // Authentication Routes
  
  // Forgot Password (Şifremi Unuttum)
  app.post("/api/auth/forgot-password", async (req, res) => {
    try {
      const { email } = req.body;

      if (!email) {
        res.status(400).json({ message: "Email gereklidir" });
        return;
      }

      // In a real application, you would:
      // 1. Check if user exists with this email
      // 2. Generate a password reset token
      // 3. Send an email with the reset link
      // 4. Store the token in the database with expiration

      // For development/demo purposes, we'll just simulate success
      console.log(`Şifre sıfırlama isteği: ${email}`);

      // Simulate a delay for more realistic behavior
      await new Promise(resolve => setTimeout(resolve, 1000));

      res.json({ 
        message: "Şifre sıfırlama bağlantısı gönderildi",
        email 
      });
    } catch (error) {
      console.error("Forgot password error:", error);
      res.status(500).json({ message: "Şifre sıfırlama isteği işlenemedi" });
    }
  });

  // Register (Kayıt olma)
  app.post("/api/auth/register", async (req, res) => {
    try {
      const { username, email, password, fullName } = req.body;
      
      if (!username || !email || !password) {
        return res.status(400).json({ error: "Kullanıcı adı, email ve şifre gerekli" });
      }

      // Kullanıcı zaten var mı kontrol et
      const existingUser = await storage.getUserByEmail(email);
      if (existingUser) {
        return res.status(400).json({ error: "Bu email adresi zaten kayıtlı" });
      }

      // Şifreyi hashle
      const hashedPassword = await bcrypt.hash(password, 10);

      // Kullanıcı oluştur
      const user = await storage.createUser({
        username,
        email,
        password: hashedPassword,
        fullName: fullName || null,
        plan: "free"
      });

      // Token oluştur
      const token = generateToken();
      const expiresAt = new Date(Date.now() + 7 * 24 * 60 * 60 * 1000); // 7 gün

      await storage.createUserSession({
        userId: user.id,
        token,
        expiresAt
      });

      res.json({
        user: {
          id: user.id,
          username: user.username,
          email: user.email,
          fullName: user.fullName,
          plan: user.plan
        },
        token
      });

    } catch (error) {
      console.error("Register error:", error);
      res.status(500).json({ error: "Kayıt işlemi başarısız" });
    }
  });

  // Login (Giriş yapma)
  app.post("/api/auth/login", async (req, res) => {
    try {
      const { email, password } = req.body;
      
      if (!email || !password) {
        return res.status(400).json({ error: "Email ve şifre gerekli" });
      }

      // Kullanıcıyı bul
      const user = await storage.getUserByEmail(email);
      if (!user) {
        return res.status(401).json({ error: "Geçersiz email veya şifre" });
      }

      // Şifreyi kontrol et
      const isValidPassword = await bcrypt.compare(password, user.password);
      if (!isValidPassword) {
        return res.status(401).json({ error: "Geçersiz email veya şifre" });
      }

      if (!user.isActive) {
        return res.status(401).json({ error: "Hesap aktif değil" });
      }

      // Token oluştur
      const token = generateToken();
      const expiresAt = new Date(Date.now() + 7 * 24 * 60 * 60 * 1000); // 7 gün

      await storage.createUserSession({
        userId: user.id,
        token,
        expiresAt
      });

      res.json({
        user: {
          id: user.id,
          username: user.username,
          email: user.email,
          fullName: user.fullName,
          plan: user.plan
        },
        token
      });

    } catch (error) {
      console.error("Login error:", error);
      res.status(500).json({ error: "Giriş işlemi başarısız" });
    }
  });

  // Logout (Çıkış yapma)
  app.post("/api/auth/logout", authenticate, async (req: AuthRequest, res) => {
    try {
      const token = req.headers.authorization?.replace('Bearer ', '');
      if (token) {
        await storage.deleteUserSession(token);
      }
      res.json({ message: "Başarıyla çıkış yapıldı" });
    } catch (error) {
      console.error("Logout error:", error);
      res.status(500).json({ error: "Çıkış işlemi başarısız" });
    }
  });

  // Me endpoint (Mevcut kullanıcı bilgisi)
  app.get("/api/auth/me", authenticate, async (req: AuthRequest, res) => {
    try {
      res.json({
        user: {
          id: req.user.id,
          username: req.user.username,
          email: req.user.email,
          fullName: req.user.fullName,
          plan: req.user.plan
        }
      });
    } catch (error) {
      console.error("Me endpoint error:", error);
      res.status(500).json({ error: "Kullanıcı bilgisi alınamadı" });
    }
  });

  // Profil güncelleme
  app.patch("/api/auth/profile", authenticate, async (req: AuthRequest, res) => {
    try {
      const { fullName, email, phone } = req.body;
      
      const updates: any = {};
      if (fullName !== undefined) updates.fullName = fullName;
      if (email !== undefined) {
        // Email benzersizlik kontrolü
        const existingUser = await storage.getUserByEmail(email);
        if (existingUser && existingUser.id !== req.userId) {
          return res.status(400).json({ error: "Bu email adresi başka bir kullanıcı tarafından kullanılıyor" });
        }
        updates.email = email;
      }
      if (phone !== undefined) updates.phone = phone;

      await storage.updateUser(req.userId!, updates);
      
      res.json({ message: "Profil başarıyla güncellendi" });
    } catch (error) {
      console.error("Profile update error:", error);
      res.status(500).json({ error: "Profil güncellenemedi" });
    }
  });

  // Şifre değiştirme
  app.patch("/api/auth/change-password", authenticate, async (req: AuthRequest, res) => {
    try {
      const { currentPassword, newPassword } = req.body;
      
      if (!currentPassword || !newPassword) {
        return res.status(400).json({ error: "Mevcut şifre ve yeni şifre gerekli" });
      }

      if (newPassword.length < 6) {
        return res.status(400).json({ error: "Yeni şifre en az 6 karakter olmalıdır" });
      }

      // Mevcut şifreyi kontrol et
      const isValidPassword = await bcrypt.compare(currentPassword, req.user.password);
      if (!isValidPassword) {
        return res.status(400).json({ error: "Mevcut şifre yanlış" });
      }

      // Yeni şifreyi hashle ve güncelle
      const hashedNewPassword = await bcrypt.hash(newPassword, 10);
      await storage.updateUser(req.userId!, { password: hashedNewPassword });
      
      res.json({ message: "Şifre başarıyla değiştirildi" });
    } catch (error) {
      console.error("Password change error:", error);
      res.status(500).json({ error: "Şifre değiştirilemedi" });
    }
  });

  // API Key Management Routes - Currently disabled due to schema migration
  // TODO: Add userApiKeys table to schema if API key management is needed

  // Text Translation API
  app.post("/api/translate", async (req, res) => {
    try {
      const { text, sourceLang, targetLang, model = "gpt-4o", category = "general" } = req.body;
      
      if (!text || !sourceLang || !targetLang) {
        return res.status(400).json({ error: "Missing required fields" });
      }

      const startTime = Date.now();

      // Validate language support
      if (!SUPPORTED_LANGUAGES[sourceLang] || !SUPPORTED_LANGUAGES[targetLang]) {
        return res.status(400).json({ error: "Unsupported language pair" });
      }

      // Get category information
      const categoryInfo = CONTENT_CATEGORIES[category] || {
        name: "General",
        description: "General purpose content",
        keywords: [],
        tone: "Clear, professional, and accessible."
      };

      // Get glossary terms for context
      const glossaryEntries = await storage.getGlossaryEntries(MOCK_USER_ID, sourceLang, targetLang);
      let glossaryContext = "";
      if (glossaryEntries.length > 0) {
        glossaryContext = "\n\nGlossary terms to use:\n" + 
          glossaryEntries.map(entry => `${entry.sourceTerm} → ${entry.targetTerm}`).join("\n");
      }

      // Get translation memory matches
      const memoryMatches = await storage.findTranslationMemoryMatches(text, sourceLang, targetLang, MOCK_USER_ID);

      const systemPrompt = `🚨 CRITICAL TASK: Professional translation from ${SUPPORTED_LANGUAGES[sourceLang].name} to ${SUPPORTED_LANGUAGES[targetLang].name}

⚠️ FORMATTING PRESERVATION (ABSOLUTELY MANDATORY):
- Keep EVERY line break, paragraph break, and empty line EXACTLY as shown in the input
- Preserve ALL spaces, tabs, indentation, and visual layout IDENTICALLY  
- Maintain bullet points, numbering, and list structures EXACTLY
- Keep all special characters, symbols, and formatting codes unchanged
- The output must look VISUALLY IDENTICAL to the input - same structure, same spacing, same layout

📝 CONTENT DETAILS:
Category: ${categoryInfo.name} (${categoryInfo.description})
Tone: ${categoryInfo.tone}
Keywords: ${categoryInfo.keywords.join(", ")}${glossaryContext}

✅ TRANSLATION QUALITY:
- Use natural, native ${SUPPORTED_LANGUAGES[targetLang].name} expressions (not literal translations)
- Apply proper ${categoryInfo.name} industry terminology
- Maintain professional quality and cultural appropriateness

🎯 REMEMBER: Translate only the text content - keep all formatting, line breaks, spacing, and structure exactly the same as the input!`;

      let translatedText = "";
      
      if (model === "deepl") {
        translatedText = await translateWithDeepL(text, sourceLang, targetLang);
      } else {
        // the newest OpenAI model is "gpt-4o" which was released May 13, 2024. do not change this unless explicitly requested by the user
        const response = await openai.chat.completions.create({
          model: "gpt-4o",
          messages: [
            { role: "system", content: systemPrompt },
            { role: "user", content: `Translate this ${categoryInfo.name} content from ${SUPPORTED_LANGUAGES[sourceLang].name} to ${SUPPORTED_LANGUAGES[targetLang].name}: ${text}` }
          ],
          temperature: 0.2, // Lower temperature for more consistent, professional translations
          max_tokens: 4000, // Ensure sufficient tokens for long content
        });
        
        translatedText = response.choices[0].message.content || "";
      }
      const translationTime = Date.now() - startTime;

      // Save translation to database
      const translation = await storage.createTranslation({
        userId: MOCK_USER_ID,
        sourceText: text,
        translatedText,
        sourceLang,
        targetLang,
        model,
        translationTime,
        category
      });

      // Add to translation memory
      await storage.createTranslationMemoryEntry({
        userId: MOCK_USER_ID,
        sourceSegment: text,
        targetSegment: translatedText,
        sourceLang,
        targetLang,
        matchScore: 100,
        context: "AI Translation"
      });

      res.json({
        id: translation.id,
        translatedText,
        translationTime,
        memoryMatches: memoryMatches.map(match => ({
          sourceSegment: match.sourceSegment,
          targetSegment: match.targetSegment,
          matchScore: match.matchScore
        }))
      });

    } catch (error) {
      console.error("Translation error:", error);
      res.status(500).json({ error: "Translation failed" });
    }
  });

  // Get supported languages
  app.get("/api/languages", (req, res) => {
    const languages = Object.entries(SUPPORTED_LANGUAGES).map(([code, info]) => ({
      code,
      name: info.name,
      available: true
    }));
    res.json(languages);
  });

  // Get content categories
  app.get("/api/categories", (req, res) => {
    const categories = Object.entries(CONTENT_CATEGORIES).map(([code, info]) => ({
      code,
      name: info.name,
      description: info.description,
      keywords: info.keywords,
      tone: info.tone
    }));
    res.json([{ code: "general", name: "Genel", description: "General purpose content", keywords: [], tone: "Clear, professional, and accessible." }, ...categories]);
  });

  // Document Translation API
  app.post("/api/document-translate", async (req, res) => {
    try {
      const { fileName, content, sourceLang, targetLang, model = "gpt-4o", category = "general" } = req.body;
      
      if (!fileName || !content || !sourceLang || !targetLang) {
        return res.status(400).json({ error: "Missing required fields" });
      }

      // Validate language support
      if (!SUPPORTED_LANGUAGES[sourceLang] || !SUPPORTED_LANGUAGES[targetLang]) {
        return res.status(400).json({ error: "Unsupported language pair" });
      }

      // Get category information
      const categoryInfo = CONTENT_CATEGORIES[category] || {
        name: "General",
        description: "General purpose content",
        keywords: [],
        tone: "Clear, professional, and accessible."
      };

      // Create document record
      const document = await storage.createDocument({
        userId: MOCK_USER_ID,
        fileName,
        originalContent: content,
        sourceLang,
        targetLang,
        status: "pending"
      });

      // Translate document content
      let translatedContent = "";
      
      if (model === "deepl") {
        translatedContent = await translateWithDeepL(content, sourceLang, targetLang);
      } else {
        const response = await openai.chat.completions.create({
          model: "gpt-4o", // the newest OpenAI model is "gpt-4o" which was released May 13, 2024. do not change this unless explicitly requested by the user
          messages: [
            {
              role: "system",
              content: `You are a senior professional document translator and SEO specialist with native-level expertise in both ${SUPPORTED_LANGUAGES[sourceLang].name} and ${SUPPORTED_LANGUAGES[targetLang].name}. You have 15+ years of experience in technical translation, content localization, and digital marketing across diverse industries and document types.

🎯 CONTENT CATEGORY: ${categoryInfo.name}
📝 Category Description: ${categoryInfo.description}
🔑 Target Keywords: ${categoryInfo.keywords.join(", ")}
💬 Required Tone: ${categoryInfo.tone}

🔥 CRITICAL FORMATTING PRESERVATION (ABSOLUTELY NON-NEGOTIABLE):
1. **Perfect Visual Match**: Output must have IDENTICAL formatting to input - every heading, paragraph, list, table, spacing, line break, and visual element must be preserved exactly.
2. **Document Structure**: Maintain ALL heading levels (# ## ### or H1 H2 H3), section breaks, and hierarchical organization in exact same positions.
3. **List & Table Formatting**: Preserve bullet points, numbered lists, sub-lists, tables, indentation, and ALL formatting exactly as provided.
4. **Line Breaks & Spacing**: Every line break, paragraph break, section spacing, and visual separation must be preserved precisely.
5. **Markup Preservation**: Preserve ALL HTML tags, Markdown syntax, formatting codes, and structural elements exactly - do not modify any technical formatting.
6. **Visual Layout**: The translated document must be visually indistinguishable from the original in terms of structure and layout.

🎯 PROFESSIONAL DOCUMENT TRANSLATION EXCELLENCE:
7. **Document Type Expertise**: Recognize document type (technical manual, marketing copy, legal document, etc.) and apply appropriate translation standards.
8. **Context Mastery**: Understand the complete document context, purpose, target audience, and business objectives.
9. **Native Fluency**: AVOID literal word-by-word translations. Use natural, idiomatic expressions that native ${targetLang} speakers would actually use in professional contexts.
10. **User-Centric Language**: Write for the end user, not developers. Use clear, engaging language that motivates action and understanding.
11. **Technical Accuracy**: Maintain perfect accuracy in technical terms, specifications, numbers, dates, and specialized vocabulary.
12. **Consistency Standards**: Ensure consistent terminology, style, and voice throughout the entire document.
13. **Industry Knowledge**: Apply deep knowledge of relevant industry standards, regulations, and best practices.
14. **Cultural Localization**: Adapt content appropriately for ${targetLang} cultural context while preserving professional tone.

📈 ADVANCED SEO & CONTENT OPTIMIZATION FOR ${targetLang}:
15. **Native Keywords**: Research and implement high-performing ${targetLang} keywords that your target market actually searches for.
16. **Established Terminology**: Use widely-accepted, industry-standard terms rather than literal translations (e.g., 'Homepage hero banner' not 'Homepage banner', 'Target URL' not 'Target link').
17. **Search Intent Mapping**: Understand and adapt to how ${targetLang} users search for information in this industry/topic.
18. **International Standards**: Apply terminology that works globally in ${targetLang} markets, not just one region.
19. **Competitive Intelligence**: Use terminology that effectively competes in ${targetLang} search results and market positioning.
20. **Multi-Engine Optimization**: Optimize for dominant search engines in ${targetLang} regions (Google, Yandex, Baidu, Naver, etc.).
21. **Content Hierarchy**: Optimize headings, subheadings, and content structure for ${targetLang} SEO best practices.
22. **Meta Optimization**: Ensure titles, descriptions, and headers are within optimal character limits for ${targetLang} search results.
23. **Regional Market Trends**: Incorporate current ${targetLang} market trends, industry terminology, and cultural references.
24. **User Experience**: Consider ${targetLang} user behavior, reading patterns, and content consumption preferences.
25. **Conversion Elements**: Translate CTAs, persuasive elements, and calls-to-action to be culturally compelling and conversion-optimized.

⚡ QUALITY ASSURANCE & PROFESSIONAL STANDARDS:
26. **Native Speaker Test**: The translation must pass the 'native speaker test' - it should sound like it was originally written by a native ${targetLang} speaker in the industry.
27. **Fluency Over Literalness**: Prioritize natural ${targetLang} expressions over literal translations. Use idiomatic phrases and established terminology.
28. **Action-Oriented Language**: Write in an engaging, action-oriented style that motivates users and drives conversion (e.g., 'Easy-to-fill form for advertisers' not 'Application form for those wishing to advertise').
29. **Professional Review**: Apply the same quality standards as certified professional translation services.
30. **International Localization**: Ensure terminology works for international ${targetLang} audiences and business contexts.
31. **User Experience Focus**: Write from the end user's perspective, making content easy to understand and act upon.
32. **Accuracy Verification**: Ensure 100% accuracy in meaning, context, technical details, and business information.
33. **Error Prevention**: Comprehensive check for grammar, spelling, cultural appropriateness, and technical accuracy.
34. **Consistency Check**: Maintain consistent terminology, formatting, and style throughout the document.

🚨 ABSOLUTE REQUIREMENT: The translated document must be visually and structurally IDENTICAL to the original - same formatting, same layout, same document structure - but with expertly translated, culturally adapted, and SEO-optimized ${targetLang} content that meets professional industry standards.

Translate with the expertise of a certified professional translator who has native-level fluency, deep industry knowledge, and extensive experience in ${targetLang} digital marketing and content optimization.`
            },
            { 
              role: "user", 
              content: `Translate this ${categoryInfo.name} document from ${SUPPORTED_LANGUAGES[sourceLang].name} to ${SUPPORTED_LANGUAGES[targetLang].name}, maintaining its search optimization value:\n\n${content}` 
            }
          ],
          temperature: 0.2, // Lower temperature for more consistent, professional translations
          max_tokens: 4000, // Ensure sufficient tokens for long documents
        });
        
        translatedContent = response.choices[0].message.content || "";
      }

      // Update document with translation
      await storage.updateDocument(document.id, {
        translatedContent,
        status: "completed"
      });

      res.json({
        id: document.id,
        translatedContent,
        status: "completed"
      });

    } catch (error) {
      console.error("Document translation error:", error);
      res.status(500).json({ error: "Document translation failed" });
    }
  });

  // Get Documents
  app.get("/api/documents", async (req, res) => {
    try {
      const documents = await storage.getDocuments(MOCK_USER_ID);
      res.json(documents);
    } catch (error) {
      console.error("Error fetching documents:", error);
      res.status(500).json({ error: "Failed to fetch documents" });
    }
  });

  // Audio Transcription API
  app.post("/api/audio-transcribe", async (req, res) => {
    try {
      const { fileName, language } = req.body;
      
      if (!fileName || !language) {
        return res.status(400).json({ error: "Missing required fields" });
      }

      // Create transcription record
      const transcription = await storage.createAudioTranscription({
        userId: MOCK_USER_ID,
        fileName,
        language,
        status: "pending"
      });

      // Simulate transcription with AI
      const response = await openai.chat.completions.create({
        model: "gpt-4o", // the newest OpenAI model is "gpt-4o" which was released May 13, 2024. do not change this unless explicitly requested by the user
        messages: [
          { 
            role: "user", 
            content: `Transcribe the content of an audio file named "${fileName}" in ${language}. Simulate a transcription of a typical business meeting or presentation audio clip.` 
          }
        ],
      });

      const transcriptionText = response.choices[0].message.content || "";

      // Update transcription with result
      await storage.updateAudioTranscription(transcription.id, {
        transcription: transcriptionText,
        duration: Math.floor(Math.random() * 300) + 60, // Random duration 1-5 minutes
        status: "completed"
      });

      res.json({
        id: transcription.id,
        transcription: transcriptionText,
        status: "completed"
      });

    } catch (error) {
      console.error("Audio transcription error:", error);
      res.status(500).json({ error: "Audio transcription failed" });
    }
  });

  // Get Audio Transcriptions
  app.get("/api/audio-transcriptions", async (req, res) => {
    try {
      const transcriptions = await storage.getAudioTranscriptions(MOCK_USER_ID);
      res.json(transcriptions);
    } catch (error) {
      console.error("Error fetching transcriptions:", error);
      res.status(500).json({ error: "Failed to fetch transcriptions" });
    }
  });

  // Text Summarization API
  app.post("/api/summarize", async (req, res) => {
    try {
      const { text, language = "en" } = req.body;
      
      if (!text) {
        return res.status(400).json({ error: "Text is required" });
      }

      const response = await openai.chat.completions.create({
        model: "gpt-4o", // the newest OpenAI model is "gpt-4o" which was released May 13, 2024. do not change this unless explicitly requested by the user
        messages: [
          { 
            role: "user", 
            content: `Summarize the following text in ${language}, keeping the key points and main ideas:\n\n${text}` 
          }
        ],
      });

      const summary = response.choices[0].message.content || "";

      res.json({ summary });

    } catch (error) {
      console.error("Summarization error:", error);
      res.status(500).json({ error: "Summarization failed" });
    }
  });

  // Glossary Management
  app.get("/api/glossary", async (req, res) => {
    try {
      const { sourceLang, targetLang } = req.query;
      const entries = await storage.getGlossaryEntries(
        MOCK_USER_ID, 
        sourceLang as string, 
        targetLang as string
      );
      res.json(entries);
    } catch (error) {
      console.error("Error fetching glossary:", error);
      res.status(500).json({ error: "Failed to fetch glossary" });
    }
  });

  app.post("/api/glossary", async (req, res) => {
    try {
      const validatedData = insertGlossarySchema.parse({
        ...req.body,
        userId: MOCK_USER_ID
      });
      
      const entry = await storage.createGlossaryEntry(validatedData);
      res.json(entry);
    } catch (error) {
      console.error("Error creating glossary entry:", error);
      res.status(500).json({ error: "Failed to create glossary entry" });
    }
  });

  app.delete("/api/glossary/:id", async (req, res) => {
    try {
      await storage.deleteGlossaryEntry(req.params.id, MOCK_USER_ID);
      res.json({ success: true });
    } catch (error) {
      console.error("Error deleting glossary entry:", error);
      res.status(500).json({ error: "Failed to delete glossary entry" });
    }
  });

  // Translation Memory Management
  app.get("/api/translation-memory", async (req, res) => {
    try {
      const { sourceLang, targetLang, search } = req.query;
      const entries = await storage.getTranslationMemoryEntries(
        MOCK_USER_ID,
        sourceLang as string,
        targetLang as string,
        search as string
      );
      res.json(entries);
    } catch (error) {
      console.error("Error fetching translation memory:", error);
      res.status(500).json({ error: "Failed to fetch translation memory" });
    }
  });

  app.post("/api/translation-memory", async (req, res) => {
    try {
      const validatedData = insertTranslationMemorySchema.parse({
        ...req.body,
        userId: MOCK_USER_ID
      });
      
      const entry = await storage.createTranslationMemoryEntry(validatedData);
      res.json(entry);
    } catch (error) {
      console.error("Error creating translation memory entry:", error);
      res.status(500).json({ error: "Failed to create translation memory entry" });
    }
  });

  app.delete("/api/translation-memory/:id", async (req, res) => {
    try {
      await storage.deleteTranslationMemoryEntry(req.params.id, MOCK_USER_ID);
      res.json({ success: true });
    } catch (error) {
      console.error("Error deleting translation memory entry:", error);
      res.status(500).json({ error: "Failed to delete translation memory entry" });
    }
  });

  // Teams Management
  app.get("/api/teams", async (req, res) => {
    try {
      const teams = await storage.getTeams(MOCK_USER_ID);
      res.json(teams);
    } catch (error) {
      console.error("Error fetching teams:", error);
      res.status(500).json({ error: "Failed to fetch teams" });
    }
  });

  app.post("/api/teams", async (req, res) => {
    try {
      const validatedData = insertTeamSchema.parse({
        ...req.body,
        ownerId: MOCK_USER_ID
      });
      
      const team = await storage.createTeam(validatedData);
      res.json(team);
    } catch (error) {
      console.error("Error creating team:", error);
      res.status(500).json({ error: "Failed to create team" });
    }
  });

  app.get("/api/teams/:teamId/members", async (req, res) => {
    try {
      const members = await storage.getTeamMembers(req.params.teamId);
      res.json(members);
    } catch (error) {
      console.error("Error fetching team members:", error);
      res.status(500).json({ error: "Failed to fetch team members" });
    }
  });

  // Projects Management
  app.get("/api/projects", async (req, res) => {
    try {
      const { teamId } = req.query;
      const projects = await storage.getProjects(MOCK_USER_ID, teamId as string);
      res.json(projects);
    } catch (error) {
      console.error("Error fetching projects:", error);
      res.status(500).json({ error: "Failed to fetch projects" });
    }
  });

  app.post("/api/projects", async (req, res) => {
    try {
      const validatedData = insertProjectSchema.parse({
        ...req.body,
        userId: MOCK_USER_ID
      });
      
      const project = await storage.createProject(validatedData);
      res.json(project);
    } catch (error) {
      console.error("Error creating project:", error);
      res.status(500).json({ error: "Failed to create project" });
    }
  });

  // Translation History
  app.get("/api/translations", async (req, res) => {
    try {
      const { limit } = req.query;
      const translations = await storage.getTranslations(MOCK_USER_ID, limit ? parseInt(limit as string) : undefined);
      res.json(translations);
    } catch (error) {
      console.error("Error fetching translations:", error);
      res.status(500).json({ error: "Failed to fetch translations" });
    }
  });

  // Update Translation Quality
  app.patch("/api/translations/:id/quality", async (req, res) => {
    try {
      const { quality } = req.body;
      await storage.updateTranslationQuality(req.params.id, quality);
      res.json({ success: true });
    } catch (error) {
      console.error("Error updating translation quality:", error);
      res.status(500).json({ error: "Failed to update translation quality" });
    }
  });

  // Learning Sessions - Currently disabled due to schema migration
  // TODO: Add learningSessions table to schema if learning functionality is needed

  // CAT Tools Integration
  const upload = multer({ 
    dest: '/tmp/uploads/',
    limits: { fileSize: 50 * 1024 * 1024 } // 50MB limit
  });

  // CAT Tools Projects
  app.get("/api/cat-tools/projects", async (req, res) => {
    try {
      const projects = await storage.getCatProjects(MOCK_USER_ID);
      res.json(projects);
    } catch (error) {
      console.error("Error fetching CAT projects:", error);
      res.status(500).json({ error: "Failed to fetch CAT projects" });
    }
  });

  // Import CAT file
  app.post("/api/cat-tools/import", upload.single('file'), async (req, res) => {
    try {
      if (!req.file) {
        return res.status(400).json({ error: "No file uploaded" });
      }

      const fileExtension = path.extname(req.file.originalname).toLowerCase();
      let projectData;

      // Parse different file formats
      switch (fileExtension) {
        case '.xliff':
        case '.xlf':
          projectData = await parseXLIFF(req.file.path, req.file.originalname);
          break;
        case '.tmx':
          projectData = await parseTMX(req.file.path, req.file.originalname);
          break;
        case '.tbx':
          projectData = await parseTBX(req.file.path, req.file.originalname);
          break;
        case '.sdlxliff':
          projectData = await parseSDLXLIFF(req.file.path, req.file.originalname);
          break;
        default:
          return res.status(400).json({ error: "Unsupported file format" });
      }

      // Save to database
      const project = await storage.createCatProject({
        ...projectData,
        userId: MOCK_USER_ID,
        status: 'importing'
      });

      // Clean up uploaded file
      await fs.unlink(req.file.path);

      res.json(project);
    } catch (error) {
      console.error("Error importing CAT file:", error);
      res.status(500).json({ error: "Failed to import CAT file" });
    }
  });

  // Export Translation Memory
  app.post("/api/cat-tools/export-tm", async (req, res) => {
    try {
      const { format } = req.body;
      const tmEntries = await storage.getTranslationMemory(MOCK_USER_ID, {});

      let exportData;
      let contentType;
      let filename;

      switch (format) {
        case 'tmx':
          exportData = generateTMX(tmEntries);
          contentType = 'application/xml';
          filename = 'translation-memory.tmx';
          break;
        case 'xliff':
          exportData = generateXLIFF(tmEntries);
          contentType = 'application/xml';
          filename = 'translation-memory.xliff';
          break;
        case 'tbx':
          const glossaryEntries = await storage.getGlossary(MOCK_USER_ID, {});
          exportData = generateTBX(glossaryEntries);
          contentType = 'application/xml';
          filename = 'glossary.tbx';
          break;
        default:
          return res.status(400).json({ error: "Unsupported export format" });
      }

      res.setHeader('Content-Type', contentType);
      res.setHeader('Content-Disposition', `attachment; filename="${filename}"`);
      res.send(exportData);
    } catch (error) {
      console.error("Error exporting data:", error);
      res.status(500).json({ error: "Failed to export data" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}

// File Format Parsers
async function parseXLIFF(filePath: string, originalName: string) {
  const xmlData = await fs.readFile(filePath, 'utf8');
  const parser = new xml2js.Parser();
  const result = await parser.parseStringPromise(xmlData);
  
  const xliff = result.xliff;
  const file = xliff.file[0];
  
  // Extract source and target languages
  const sourceLanguage = file.$['source-language'] || 'en';
  const targetLanguage = file.$['target-language'] || 'tr';
  
  // Extract translation units
  const body = file.body[0];
  const transUnits = body['trans-unit'] || [];
  
  let segmentCount = 0;
  let translatedCount = 0;
  
  // Process translation units
  for (const unit of transUnits) {
    segmentCount++;
    if (unit.target && unit.target[0] && unit.target[0]._ && unit.target[0]._.trim()) {
      translatedCount++;
    }
  }
  
  return {
    name: originalName.replace(/\.[^/.]+$/, ""),
    sourceLanguage,
    targetLanguage,
    fileFormat: 'xliff' as const,
    segmentCount,
    translatedCount,
    status: 'ready' as const
  };
}

async function parseTMX(filePath: string, originalName: string) {
  const xmlData = await fs.readFile(filePath, 'utf8');
  const parser = new xml2js.Parser();
  const result = await parser.parseStringPromise(xmlData);
  
  const tmx = result.tmx;
  const body = tmx.body[0];
  const tus = body.tu || [];
  
  let segmentCount = tus.length;
  let translatedCount = segmentCount; // TMX files contain completed translation pairs
  
  return {
    name: originalName.replace(/\.[^/.]+$/, ""),
    sourceLanguage: 'multiple', // TMX can contain multiple languages
    targetLanguage: 'multiple',
    fileFormat: 'tmx' as const,
    segmentCount,
    translatedCount,
    status: 'ready' as const
  };
}

async function parseTBX(filePath: string, originalName: string) {
  const xmlData = await fs.readFile(filePath, 'utf8');
  const parser = new xml2js.Parser();
  const result = await parser.parseStringPromise(xmlData);
  
  const tbx = result.martif || result.tbx;
  const body = tbx.text[0].body[0];
  const conceptEntries = body.conceptEntry || [];
  
  let segmentCount = conceptEntries.length;
  
  return {
    name: originalName.replace(/\.[^/.]+$/, ""),
    sourceLanguage: 'multiple',
    targetLanguage: 'multiple', 
    fileFormat: 'tbx' as const,
    segmentCount,
    translatedCount: segmentCount,
    status: 'ready' as const
  };
}

async function parseSDLXLIFF(filePath: string, originalName: string) {
  // SDL XLIFF is similar to standard XLIFF but with SDL-specific extensions
  return parseXLIFF(filePath, originalName).then(result => ({
    ...result,
    fileFormat: 'sdlxliff' as const
  }));
}

// Export Format Generators
function generateTMX(tmEntries: any[]) {
  const header = `<?xml version="1.0" encoding="UTF-8"?>
<tmx version="1.4">
  <header creationtool="LinguaFlow" o-tmf="unknown" adminlang="en" srclang="*all*" datatype="unknown">
  </header>
  <body>`;
  
  let body = '';
  for (const entry of tmEntries) {
    body += `
    <tu tuid="${entry.id}">
      <tuv xml:lang="${entry.sourceLanguage}">
        <seg>${escapeXml(entry.sourceSegment)}</seg>
      </tuv>
      <tuv xml:lang="${entry.targetLanguage}">
        <seg>${escapeXml(entry.targetSegment)}</seg>
      </tuv>
    </tu>`;
  }
  
  const footer = `
  </body>
</tmx>`;
  return header + body + footer;
}

function generateXLIFF(tmEntries: any[]) {
  const header = `<?xml version="1.0" encoding="UTF-8"?>
<xliff version="1.2">
  <file original="translation-memory" source-language="en" target-language="tr" datatype="plaintext">
    <body>`;
  
  let body = '';
  for (let i = 0; i < tmEntries.length; i++) {
    const entry = tmEntries[i];
    body += `
      <trans-unit id="${i + 1}">
        <source>${escapeXml(entry.sourceSegment)}</source>
        <target>${escapeXml(entry.targetSegment)}</target>
      </trans-unit>`;
  }
  
  const footer = `
    </body>
  </file>
</xliff>`;
  return header + body + footer;
}

function generateTBX(glossaryEntries: any[]) {
  const header = `<?xml version="1.0" encoding="UTF-8"?>
<martif type="TBX" xml:lang="en">
  <martifHeader>
    <fileDesc>
      <titleStmt>
        <title>LinguaFlow Glossary</title>
      </titleStmt>
    </fileDesc>
  </martifHeader>
  <text>
    <body>`;
  
  let body = '';
  for (const entry of glossaryEntries) {
    body += `
      <conceptEntry id="${entry.id}">
        <langSet xml:lang="${entry.sourceLanguage}">
          <tig>
            <term>${escapeXml(entry.sourceTerm)}</term>
          </tig>
        </langSet>
        <langSet xml:lang="${entry.targetLanguage}">
          <tig>
            <term>${escapeXml(entry.targetTerm)}</term>
          </tig>
        </langSet>
      </conceptEntry>`;
  }
  
  const footer = `
    </body>
  </text>
</martif>`;
  return header + body + footer;
}

function escapeXml(text: string): string {
  return text
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&apos;');
}
