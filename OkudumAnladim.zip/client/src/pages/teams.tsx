import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Label } from "@/components/ui/label";
import { Users, Plus, Settings, UserPlus, Trash2, Crown, Shield, User, Mail } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { useI18n } from "@/lib/i18n/context";

interface Team {
  id: string;
  name: string;
  description?: string;
  ownerId: string;
  createdAt: string;
  memberCount: number;
}

interface TeamMember {
  id: string;
  teamId: string;
  userId: string;
  role: 'owner' | 'admin' | 'member';
  joinedAt: string;
  user: {
    id: string;
    username: string;
    email: string;
    fullName?: string;
  };
}

export default function Teams() {
  const [teamName, setTeamName] = useState("");
  const [teamDescription, setTeamDescription] = useState("");
  const [isCreateDialogOpen, setIsCreateDialogOpen] = useState(false);
  const [selectedTeam, setSelectedTeam] = useState<Team | null>(null);
  const [isMembersDialogOpen, setIsMembersDialogOpen] = useState(false);
  const [isInviteDialogOpen, setIsInviteDialogOpen] = useState(false);
  const [inviteEmail, setInviteEmail] = useState("");
  
  const { t } = useI18n();
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const { data: teams = [], isLoading } = useQuery<Team[]>({
    queryKey: ["/api/teams"],
  });

  const { data: teamMembers = [] } = useQuery<TeamMember[]>({
    queryKey: ["/api/teams", selectedTeam?.id, "members"],
    enabled: !!selectedTeam?.id,
  });

  const createTeamMutation = useMutation({
    mutationFn: async (data: { name: string; description?: string }) => {
      const response = await apiRequest("POST", "/api/teams", data);
      return response.json();
    },
    onSuccess: () => {
      setTeamName("");
      setTeamDescription("");
      setIsCreateDialogOpen(false);
      queryClient.invalidateQueries({ queryKey: ["/api/teams"] });
      toast({
        title: t('teams.teamCreatedSuccess'),
        description: t('teams.teamCreatedDescription'),
      });
    },
    onError: (error) => {
      toast({
        title: t('teams.failedToCreateTeam'),
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const handleCreateTeam = () => {
    if (!teamName.trim()) {
      toast({
        title: t('teams.pleaseEnterTeamName'),
        variant: "destructive",
      });
      return;
    }

    createTeamMutation.mutate({
      name: teamName.trim(),
      description: teamDescription.trim() || undefined,
    });
  };

  const handleViewMembers = (team: Team) => {
    setSelectedTeam(team);
    setIsMembersDialogOpen(true);
  };

  const inviteTeamMemberMutation = useMutation({
    mutationFn: async (data: { teamId: string; email: string }) => {
      const response = await apiRequest("POST", `/api/teams/${data.teamId}/invite`, { email: data.email });
      return response.json();
    },
    onSuccess: () => {
      setInviteEmail("");
      setIsInviteDialogOpen(false);
      queryClient.invalidateQueries({ queryKey: ["/api/teams", selectedTeam?.id, "members"] });
      toast({
        title: "Davet gönderildi!",
        description: "Kullanıcıya email ile davet gönderildi.",
      });
    },
    onError: (error) => {
      toast({
        title: "Davet gönderilemedi",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const handleInviteMember = () => {
    if (!inviteEmail.trim() || !selectedTeam) {
      toast({
        title: "Hata",
        description: "Lütfen geçerli bir email adresi girin",
        variant: "destructive",
      });
      return;
    }

    inviteTeamMemberMutation.mutate({
      teamId: selectedTeam.id,
      email: inviteEmail,
    });
  };

  const getRoleIcon = (role: string) => {
    switch (role) {
      case 'owner':
        return <Crown className="h-4 w-4 text-yellow-500" />;
      case 'admin':
        return <Shield className="h-4 w-4 text-blue-500" />;
      default:
        return <User className="h-4 w-4 text-gray-500" />;
    }
  };

  const getRoleBadgeColor = (role: string) => {
    switch (role) {
      case 'owner':
        return 'bg-yellow-100 text-yellow-800 dark:bg-yellow-900/50 dark:text-yellow-200';
      case 'admin':
        return 'bg-blue-100 text-blue-800 dark:bg-blue-900/50 dark:text-blue-200';
      default:
        return 'bg-gray-100 text-gray-800 dark:bg-gray-800 dark:text-gray-200';
    }
  };

  return (
    <div className="max-w-6xl mx-auto space-y-6">
      {/* Header with Create Team Button */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-gray-900 dark:text-white" data-testid="teams-page-title">
            {t('teams.title')}
          </h1>
          <p className="text-gray-500 dark:text-gray-400 mt-1">
            {t('teams.subtitle')}
          </p>
        </div>
        <Dialog open={isCreateDialogOpen} onOpenChange={setIsCreateDialogOpen}>
          <DialogTrigger asChild>
            <Button className="bg-blue-600 hover:bg-blue-700" data-testid="button-create-team">
              <Plus className="h-4 w-4 mr-2" />
              {t('teams.createTeam')}
            </Button>
          </DialogTrigger>
          <DialogContent>
            <DialogHeader>
              <DialogTitle data-testid="create-team-dialog-title">{t('teams.createNewTeam')}</DialogTitle>
            </DialogHeader>
            <div className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                  {t('teams.teamName')}
                </label>
                <Input
                  value={teamName}
                  onChange={(e) => setTeamName(e.target.value)}
                  placeholder={t('teams.enterTeamName')}
                  data-testid="input-team-name"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                  {t('teams.description')}
                </label>
                <Textarea
                  value={teamDescription}
                  onChange={(e) => setTeamDescription(e.target.value)}
                  placeholder={t('teams.descriptionPlaceholder')}
                  className="h-20 resize-none"
                  data-testid="textarea-team-description"
                />
              </div>
              <div className="flex justify-end space-x-2">
                <Button
                  variant="outline"
                  onClick={() => setIsCreateDialogOpen(false)}
                  data-testid="button-cancel-create"
                >
                  {t('common.cancel')}
                </Button>
                <Button
                  onClick={handleCreateTeam}
                  disabled={createTeamMutation.isPending}
                  data-testid="button-confirm-create"
                >
                  {createTeamMutation.isPending ? t('teams.creating') : t('teams.createTeam')}
                </Button>
              </div>
            </div>
          </DialogContent>
        </Dialog>
      </div>

      {/* Teams Grid */}
      {isLoading ? (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {[1, 2, 3].map((i) => (
            <div key={i} className="animate-pulse">
              <div className="h-40 bg-gray-200 dark:bg-gray-700 rounded-lg" />
            </div>
          ))}
        </div>
      ) : teams.length === 0 ? (
        <Card>
          <CardContent className="text-center py-12">
            <Users className="h-16 w-16 mx-auto mb-4 text-gray-400" />
            <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-2">
              {t('teams.noTeamsYet')}
            </h3>
            <p className="text-gray-500 dark:text-gray-400 mb-4" data-testid="no-teams-message">
              {t('teams.createFirstTeam')}
            </p>
            <Button
              onClick={() => setIsCreateDialogOpen(true)}
              className="bg-blue-600 hover:bg-blue-700"
              data-testid="button-create-first-team"
            >
              <Plus className="h-4 w-4 mr-2" />
              {t('teams.createYourFirstTeam')}
            </Button>
          </CardContent>
        </Card>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {teams.map((team: any) => (
            <Card key={team.id} className="hover:shadow-lg transition-shadow" data-testid={`team-card-${team.id}`}>
              <CardHeader className="pb-3">
                <div className="flex items-start justify-between">
                  <div className="flex items-center space-x-3">
                    <div className="w-10 h-10 bg-gradient-to-br from-blue-500 to-purple-600 rounded-lg flex items-center justify-center">
                      <Users className="h-5 w-5 text-white" />
                    </div>
                    <div>
                      <CardTitle className="text-lg" data-testid={`team-name-${team.id}`}>
                        {team.name}
                      </CardTitle>
                      <Badge variant="secondary" className="mt-1" data-testid={`team-owner-badge-${team.id}`}>
                        {t('teams.owner')}
                      </Badge>
                    </div>
                  </div>
                  <Button
                    variant="ghost"
                    size="icon"
                    className="text-gray-400 hover:text-gray-600"
                    data-testid={`button-team-settings-${team.id}`}
                  >
                    <Settings className="h-4 w-4" />
                  </Button>
                </div>
              </CardHeader>
              <CardContent className="space-y-4">
                {team.description && (
                  <p className="text-sm text-gray-600 dark:text-gray-400" data-testid={`team-description-${team.id}`}>
                    {team.description}
                  </p>
                )}
                
                <div className="flex items-center justify-between text-sm text-gray-500 dark:text-gray-400">
                  <span data-testid={`team-created-date-${team.id}`}>
                    {t('teams.created')} {new Date(team.createdAt).toLocaleDateString()}
                  </span>
                </div>
                
                <div className="flex space-x-2">
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => handleViewMembers(team)}
                    className="flex-1"
                    data-testid={`button-view-members-${team.id}`}
                  >
                    <Users className="h-4 w-4 mr-2" />
                    {t('teams.members')}
                  </Button>
                  <Button
                    variant="outline"
                    size="sm"
                    className="flex-1"
                    onClick={() => {
                      setSelectedTeam(team);
                      setIsInviteDialogOpen(true);
                    }}
                    data-testid={`button-add-member-${team.id}`}
                  >
                    <UserPlus className="h-4 w-4 mr-2" />
                    {t('teams.invite')}
                  </Button>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      )}

      {/* Team Members Dialog */}
      <Dialog open={isMembersDialogOpen} onOpenChange={setIsMembersDialogOpen}>
        <DialogContent className="max-w-2xl">
          <DialogHeader>
            <DialogTitle data-testid="team-members-dialog-title">
{t('teams.teamMembers')} - {selectedTeam?.name}
            </DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            {teamMembers.length === 0 ? (
              <div className="text-center py-8 text-gray-500 dark:text-gray-400">
                <Users className="h-12 w-12 mx-auto mb-4 opacity-50" />
                <p data-testid="no-members-message">{t('teams.noMembersFound')}</p>
              </div>
            ) : (
              <div className="overflow-x-auto">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>{t('teams.member')}</TableHead>
                      <TableHead>{t('teams.role')}</TableHead>
                      <TableHead>{t('teams.joined')}</TableHead>
                      <TableHead className="w-20">{t('teams.actions')}</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {teamMembers.map((member: any) => (
                      <TableRow key={member.id} data-testid={`member-row-${member.id}`}>
                        <TableCell>
                          <div className="flex items-center space-x-3">
                            <div className="w-8 h-8 bg-gradient-to-br from-gray-400 to-gray-600 rounded-full flex items-center justify-center">
                              <span className="text-white text-sm font-medium">
                                {member.user.fullName?.charAt(0) || member.user.username.charAt(0).toUpperCase()}
                              </span>
                            </div>
                            <div>
                              <p className="font-medium text-gray-900 dark:text-white" data-testid={`member-name-${member.id}`}>
                                {member.user.fullName || member.user.username}
                              </p>
                              <p className="text-sm text-gray-500 dark:text-gray-400" data-testid={`member-email-${member.id}`}>
                                {member.user.email}
                              </p>
                            </div>
                          </div>
                        </TableCell>
                        <TableCell>
                          <div className="flex items-center space-x-2">
                            {getRoleIcon(member.role)}
                            <Badge 
                              variant="secondary" 
                              className={getRoleBadgeColor(member.role)}
                              data-testid={`member-role-${member.id}`}
                            >
                              {member.role}
                            </Badge>
                          </div>
                        </TableCell>
                        <TableCell className="text-sm text-gray-500 dark:text-gray-400" data-testid={`member-joined-${member.id}`}>
                          {new Date(member.joinedAt).toLocaleDateString()}
                        </TableCell>
                        <TableCell>
                          {member.role !== 'owner' && (
                            <Button
                              variant="ghost"
                              size="sm"
                              className="text-red-600 hover:text-red-700 hover:bg-red-50 dark:hover:bg-red-900/20"
                              data-testid={`button-remove-member-${member.id}`}
                            >
                              <Trash2 className="h-4 w-4" />
                            </Button>
                          )}
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </div>
            )}
          </div>
        </DialogContent>
      </Dialog>

      {/* Invite Member Dialog */}
      <Dialog open={isInviteDialogOpen} onOpenChange={setIsInviteDialogOpen}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle className="flex items-center">
              <Mail className="h-5 w-5 mr-2" />
              Takım Üyesi Davet Et - {selectedTeam?.name}
            </DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="invite-email">Email Adresi</Label>
              <Input
                id="invite-email"
                type="email"
                value={inviteEmail}
                onChange={(e) => setInviteEmail(e.target.value)}
                placeholder="kullanici@ornek.com"
                data-testid="input-invite-email"
              />
              <p className="text-xs text-gray-500">
                Davet edilecek kişinin email adresini girin. Email ile davet bağlantısı gönderilecek.
              </p>
            </div>
            <div className="flex justify-end space-x-2">
              <Button
                variant="outline"
                onClick={() => {
                  setIsInviteDialogOpen(false);
                  setInviteEmail("");
                }}
                data-testid="button-cancel-invite"
              >
                İptal
              </Button>
              <Button
                onClick={handleInviteMember}
                disabled={inviteTeamMemberMutation.isPending || !inviteEmail.trim()}
                className="bg-blue-600 hover:bg-blue-700"
                data-testid="button-send-invite"
              >
                {inviteTeamMemberMutation.isPending ? (
                  <>
                    <span className="animate-spin rounded-full h-4 w-4 border-b-2 border-white mr-2"></span>
                    Gönderiliyor...
                  </>
                ) : (
                  <>
                    <Mail className="h-4 w-4 mr-2" />
                    Davet Gönder
                  </>
                )}
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}
