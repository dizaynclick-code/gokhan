import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { useToast } from "@/hooks/use-toast";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { useAuth } from "@/lib/auth/context";
import { 
  Check, 
  Zap, 
  Users, 
  Building, 
  Crown,
  TrendingUp,
  Globe,
  Shield
} from "lucide-react";

const plans = [
  {
    id: "free",
    name: "Ücretsiz Deneme",
    price: "₺0",
    period: "30 gün",
    characters: "10.000",
    description: "Başlamak için mükemmel",
    features: [
      "10.000 karakter/ay",
      "15+ dil desteği",
      "Temel çeviri",
      "Web arayüzü",
      "Community support"
    ],
    icon: Zap,
    color: "bg-gray-500",
    current: true
  },
  {
    id: "personal",
    name: "Kişisel",
    price: "₺49",
    period: "aylık",
    characters: "100.000",
    description: "Bireysel kullanıcılar için",
    features: [
      "100.000 karakter/ay",
      "15+ dil desteği",
      "Gelişmiş çeviri",
      "Döküman çevirisi",
      "Sözlük yönetimi",
      "Çeviri belleği",
      "Email support"
    ],
    icon: Users,
    color: "bg-blue-500",
    popular: true
  },
  {
    id: "professional",
    name: "Profesyonel",
    price: "₺149",
    period: "aylık",
    characters: "500.000",
    description: "Profesyoneller ve küçük takımlar",
    features: [
      "500.000 karakter/ay",
      "15+ dil desteği",
      "Profesyonel çeviri",
      "Toplu döküman işleme",
      "Takım yönetimi",
      "Proje organizasyonu",
      "CAT Tools entegrasyonu",
      "Öncelikli support"
    ],
    icon: Building,
    color: "bg-purple-500"
  },
  {
    id: "agency",
    name: "Ajans",
    price: "₺399",
    period: "aylık",
    characters: "2.000.000",
    description: "Ajanslar ve büyük organizasyonlar",
    features: [
      "2.000.000 karakter/ay",
      "15+ dil desteği",
      "Enterprise çeviri",
      "Sınırsız döküman",
      "Gelişmiş takım yönetimi",
      "API erişimi",
      "Özel entegrasyonlar",
      "Dedicated account manager",
      "SLA garantisi"
    ],
    icon: Crown,
    color: "bg-amber-500"
  }
];

export default function Pricing() {
  const { user } = useAuth();
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [isLoading, setIsLoading] = useState<string | null>(null);

  const upgradePlanMutation = useMutation({
    mutationFn: async (planId: string) => {
      await apiRequest("POST", "/api/upgrade-plan", { planId });
    },
    onSuccess: () => {
      toast({
        title: "Plan Yükseltildi!",
        description: "Planınız başarıyla yükseltildi.",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/auth/me"] });
      setIsLoading(null);
    },
    onError: (error: any) => {
      toast({
        title: "Yükseltme Hatası",
        description: error.message || "Plan yükseltilemedi.",
        variant: "destructive",
      });
      setIsLoading(null);
    },
  });

  const handleUpgrade = (planId: string) => {
    setIsLoading(planId);
    upgradePlanMutation.mutate(planId);
  };

  const getPlanProgress = () => {
    if (!user) return 0;
    const used = (user as any).usedCharactersThisMonth || 0;
    const limit = (user as any).monthlyCharacterLimit || 10000;
    return (used / limit) * 100;
  };

  const formatNumber = (num: number) => {
    return new Intl.NumberFormat('tr-TR').format(num);
  };

  return (
    <div className="max-w-7xl mx-auto space-y-8">
      {/* Header */}
      <div className="text-center space-y-4">
        <h1 className="text-4xl font-bold text-gray-900 dark:text-white">
          Fiyatlandırma
        </h1>
        <p className="text-xl text-gray-600 dark:text-gray-400 max-w-2xl mx-auto">
          İhtiyacınıza uygun planı seçin. OpenAI'ın en son teknolojisi ile güçlendirilmiş profesyonel çeviri hizmeti.
        </p>
      </div>

      {/* Current Usage */}
      {user && (
        <Card className="max-w-2xl mx-auto">
          <CardHeader>
            <CardTitle className="flex items-center">
              <TrendingUp className="h-5 w-5 mr-2" />
              Bu Ayıki Kullanımınız
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              <div className="flex justify-between items-center">
                <span className="text-sm text-gray-600">Kullanılan Karakter:</span>
                <span className="font-semibold">
                  {formatNumber((user as any).usedCharactersThisMonth || 0)} / {formatNumber((user as any).monthlyCharacterLimit || 10000)}
                </span>
              </div>
              <div className="w-full bg-gray-200 rounded-full h-3">
                <div 
                  className="bg-blue-600 h-3 rounded-full transition-all duration-300"
                  style={{ width: `${Math.min(getPlanProgress(), 100)}%` }}
                ></div>
              </div>
              <div className="text-sm text-gray-500">
                Plan: <span className="font-medium capitalize">{(user as any).plan || 'free'}</span>
              </div>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Pricing Plans */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {plans.map((plan) => {
          const Icon = plan.icon;
          const isCurrentPlan = user && (user as any).plan === plan.id;
          
          return (
            <Card 
              key={plan.id} 
              className={`relative overflow-hidden ${plan.popular ? 'ring-2 ring-blue-500 ring-offset-2' : ''} ${isCurrentPlan ? 'bg-blue-50 dark:bg-blue-900/20' : ''}`}
            >
              {plan.popular && (
                <div className="absolute top-0 left-1/2 transform -translate-x-1/2 -translate-y-1/2">
                  <Badge className="bg-blue-500 text-white">En Popüler</Badge>
                </div>
              )}
              
              <CardHeader className="text-center pb-4">
                <div className={`w-12 h-12 ${plan.color} rounded-full flex items-center justify-center mx-auto mb-4`}>
                  <Icon className="h-6 w-6 text-white" />
                </div>
                <CardTitle className="text-xl">{plan.name}</CardTitle>
                <div className="space-y-1">
                  <div className="text-3xl font-bold">
                    {plan.price}
                    <span className="text-sm font-normal text-gray-500">/{plan.period}</span>
                  </div>
                  <p className="text-sm text-gray-600">{plan.description}</p>
                </div>
                <div className="bg-gray-100 dark:bg-gray-800 rounded-lg p-3">
                  <div className="text-2xl font-bold text-blue-600">{plan.characters}</div>
                  <div className="text-xs text-gray-500">karakter/ay</div>
                </div>
              </CardHeader>

              <CardContent className="space-y-4">
                <ul className="space-y-3">
                  {plan.features.map((feature, index) => (
                    <li key={index} className="flex items-start space-x-3">
                      <Check className="h-4 w-4 text-green-500 mt-0.5 flex-shrink-0" />
                      <span className="text-sm text-gray-700 dark:text-gray-300">{feature}</span>
                    </li>
                  ))}
                </ul>

                <div className="pt-4">
                  {isCurrentPlan ? (
                    <Button disabled className="w-full" variant="outline">
                      Mevcut Planınız
                    </Button>
                  ) : plan.id === 'free' ? (
                    <Button disabled className="w-full" variant="outline">
                      30 Gün Ücretsiz
                    </Button>
                  ) : (
                    <Button 
                      onClick={() => handleUpgrade(plan.id)}
                      disabled={isLoading === plan.id}
                      className="w-full bg-blue-600 hover:bg-blue-700 text-white"
                      data-testid={`button-upgrade-${plan.id}`}
                    >
                      {isLoading === plan.id ? (
                        <div className="animate-pulse">Yükseltiliyor...</div>
                      ) : (
                        "Planı Seç"
                      )}
                    </Button>
                  )}
                </div>
              </CardContent>
            </Card>
          );
        })}
      </div>

      {/* Features Comparison */}
      <div className="bg-white dark:bg-gray-800 rounded-lg p-6">
        <h2 className="text-2xl font-bold text-center mb-6">Tüm Planlar Şunları İçerir</h2>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <div className="text-center">
            <Globe className="h-12 w-12 text-blue-600 mx-auto mb-4" />
            <h3 className="font-semibold mb-2">15+ Dil Desteği</h3>
            <p className="text-sm text-gray-600">Türkçe, İngilizce, Almanca, Fransızca ve daha fazlası</p>
          </div>
          <div className="text-center">
            <Zap className="h-12 w-12 text-blue-600 mx-auto mb-4" />
            <h3 className="font-semibold mb-2">OpenAI GPT-4o</h3>
            <p className="text-sm text-gray-600">En gelişmiş AI teknolojisi ile doğal çeviriler</p>
          </div>
          <div className="text-center">
            <Shield className="h-12 w-12 text-blue-600 mx-auto mb-4" />
            <h3 className="font-semibold mb-2">Güvenli & Gizli</h3>
            <p className="text-sm text-gray-600">Verileriniz güvende, gizlilik garantisi</p>
          </div>
        </div>
      </div>

      {/* FAQ or Additional Info */}
      <Card>
        <CardHeader>
          <CardTitle>Sıkça Sorulan Sorular</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div>
            <h4 className="font-medium mb-2">Karakter limiti nasıl hesaplanır?</h4>
            <p className="text-sm text-gray-600">Her çevrilen metin karakteri kullanım limitinizden düşer. Boşluklar ve noktalama işaretleri de dahildir.</p>
          </div>
          <div>
            <h4 className="font-medium mb-2">Planımı istediğim zaman değiştirebilir miyim?</h4>
            <p className="text-sm text-gray-600">Evet, planınızı istediğiniz zaman yükseltebilir veya düşürebilirsiniz. Değişiklik hemen geçerli olur.</p>
          </div>
          <div>
            <h4 className="font-medium mb-2">Ücretsiz deneme süresi dolduğunda ne olur?</h4>
            <p className="text-sm text-gray-600">30 günlük ücretsiz deneme sonunda otomatik olarak ücretli plana geçiş yapmaz. Hizmeti kullanmaya devam etmek için bir plan seçmelisiniz.</p>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}