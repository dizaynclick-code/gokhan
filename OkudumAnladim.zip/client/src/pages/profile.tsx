import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Separator } from "@/components/ui/separator";
import { useToast } from "@/hooks/use-toast";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { useAuth } from "@/lib/auth/context";
import { User, Phone, Mail, Lock, Save } from "lucide-react";

interface UserProfile extends Record<string, any> {
  id: string;
  username: string;
  email: string;
  fullName: string;
  phone?: string;
  plan: string;
}

interface UpdateProfileData {
  fullName?: string;
  phone?: string;
  email?: string;
}

interface ChangePasswordData {
  currentPassword: string;
  newPassword: string;
  confirmPassword: string;
}

export default function Profile() {
  const { user } = useAuth();
  const { toast } = useToast();
  const queryClient = useQueryClient();
  
  const [profileData, setProfileData] = useState({
    fullName: user?.fullName || '',
    email: user?.email || '',
    phone: (user as any)?.phone || '',
  });

  const [passwordData, setPasswordData] = useState({
    currentPassword: '',
    newPassword: '',
    confirmPassword: '',
  });

  const updateProfileMutation = useMutation({
    mutationFn: async (data: UpdateProfileData) => {
      await apiRequest("PATCH", "/api/auth/profile", data);
    },
    onSuccess: () => {
      toast({
        title: "Profil Güncellendi",
        description: "Profil bilgileriniz başarıyla güncellendi.",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/auth/me"] });
    },
    onError: (error: any) => {
      toast({
        title: "Güncelleme Hatası",
        description: error.message || "Profil güncellenemedi.",
        variant: "destructive",
      });
    },
  });

  const changePasswordMutation = useMutation({
    mutationFn: async (data: ChangePasswordData) => {
      if (data.newPassword !== data.confirmPassword) {
        throw new Error("Yeni şifreler eşleşmiyor");
      }
      if (data.newPassword.length < 6) {
        throw new Error("Şifre en az 6 karakter olmalıdır");
      }
      await apiRequest("PATCH", "/api/auth/change-password", {
        currentPassword: data.currentPassword,
        newPassword: data.newPassword,
      });
    },
    onSuccess: () => {
      toast({
        title: "Şifre Değiştirildi",
        description: "Şifreniz başarıyla değiştirildi.",
      });
      setPasswordData({
        currentPassword: '',
        newPassword: '',
        confirmPassword: '',
      });
    },
    onError: (error: any) => {
      toast({
        title: "Şifre Değiştirme Hatası",
        description: error.message || "Şifre değiştirilemedi.",
        variant: "destructive",
      });
    },
  });

  const handleProfileUpdate = () => {
    updateProfileMutation.mutate(profileData);
  };

  const handlePasswordChange = () => {
    changePasswordMutation.mutate(passwordData);
  };

  if (!user) {
    return <div>Kullanıcı bilgileri yükleniyor...</div>;
  }

  return (
    <div className="max-w-4xl mx-auto space-y-6">
      <div className="flex items-center space-x-3">
        <div className="w-12 h-12 bg-blue-600 rounded-full flex items-center justify-center">
          <User className="h-6 w-6 text-white" />
        </div>
        <div>
          <h1 className="text-2xl font-bold text-gray-900 dark:text-white">
            Profil Ayarları
          </h1>
          <p className="text-gray-500 dark:text-gray-400">
            Hesap bilgilerinizi yönetin
          </p>
        </div>
      </div>

      {/* Profil Bilgileri */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center space-x-2">
            <User className="h-5 w-5" />
            <span>Kişisel Bilgiler</span>
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="username">Kullanıcı Adı</Label>
              <Input
                id="username"
                value={user.username}
                disabled
                className="bg-gray-50 dark:bg-gray-800"
                data-testid="input-username"
              />
              <p className="text-xs text-gray-500">Kullanıcı adı değiştirilemez</p>
            </div>
            
            <div className="space-y-2">
              <Label htmlFor="fullName">Ad Soyad</Label>
              <Input
                id="fullName"
                value={profileData.fullName}
                onChange={(e) => setProfileData(prev => ({ ...prev, fullName: e.target.value }))}
                placeholder="Ad ve soyadınızı girin"
                data-testid="input-fullname"
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="email" className="flex items-center space-x-1">
                <Mail className="h-4 w-4" />
                <span>E-posta</span>
              </Label>
              <Input
                id="email"
                type="email"
                value={profileData.email}
                onChange={(e) => setProfileData(prev => ({ ...prev, email: e.target.value }))}
                placeholder="email@example.com"
                data-testid="input-email"
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="phone" className="flex items-center space-x-1">
                <Phone className="h-4 w-4" />
                <span>Telefon Numarası</span>
              </Label>
              <Input
                id="phone"
                value={profileData.phone}
                onChange={(e) => setProfileData(prev => ({ ...prev, phone: e.target.value }))}
                placeholder="+90 5XX XXX XX XX"
                data-testid="input-phone"
              />
            </div>
          </div>

          <div className="flex justify-end pt-4">
            <Button
              onClick={handleProfileUpdate}
              disabled={updateProfileMutation.isPending}
              className="bg-blue-600 hover:bg-blue-700"
              data-testid="button-update-profile"
            >
              {updateProfileMutation.isPending ? (
                <div className="animate-pulse">Güncelleniyor...</div>
              ) : (
                <>
                  <Save className="h-4 w-4 mr-2" />
                  Profili Güncelle
                </>
              )}
            </Button>
          </div>
        </CardContent>
      </Card>

      {/* Şifre Değiştirme */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center space-x-2">
            <Lock className="h-5 w-5" />
            <span>Şifre Değiştir</span>
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="space-y-2">
              <Label htmlFor="currentPassword">Mevcut Şifre</Label>
              <Input
                id="currentPassword"
                type="password"
                value={passwordData.currentPassword}
                onChange={(e) => setPasswordData(prev => ({ ...prev, currentPassword: e.target.value }))}
                placeholder="Mevcut şifreniz"
                data-testid="input-current-password"
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="newPassword">Yeni Şifre</Label>
              <Input
                id="newPassword"
                type="password"
                value={passwordData.newPassword}
                onChange={(e) => setPasswordData(prev => ({ ...prev, newPassword: e.target.value }))}
                placeholder="En az 6 karakter"
                data-testid="input-new-password"
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="confirmPassword">Yeni Şifre (Tekrar)</Label>
              <Input
                id="confirmPassword"
                type="password"
                value={passwordData.confirmPassword}
                onChange={(e) => setPasswordData(prev => ({ ...prev, confirmPassword: e.target.value }))}
                placeholder="Yeni şifreyi tekrar girin"
                data-testid="input-confirm-password"
              />
            </div>
          </div>

          <div className="flex justify-end pt-4">
            <Button
              onClick={handlePasswordChange}
              disabled={changePasswordMutation.isPending || !passwordData.currentPassword || !passwordData.newPassword || !passwordData.confirmPassword}
              variant="outline"
              data-testid="button-change-password"
            >
              {changePasswordMutation.isPending ? (
                <div className="animate-pulse">Değiştiriliyor...</div>
              ) : (
                <>
                  <Lock className="h-4 w-4 mr-2" />
                  Şifreyi Değiştir
                </>
              )}
            </Button>
          </div>
        </CardContent>
      </Card>

      {/* Hesap Bilgileri */}
      <Card>
        <CardHeader>
          <CardTitle>Hesap Bilgileri</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <Label className="text-sm font-medium text-gray-500">Plan</Label>
              <p className="text-lg font-semibold text-gray-900 dark:text-white capitalize">
                {user.plan || 'Free'}
              </p>
            </div>
            <div>
              <Label className="text-sm font-medium text-gray-500">Hesap Durumu</Label>
              <div className="flex items-center space-x-2">
                <div className="w-2 h-2 bg-green-500 rounded-full"></div>
                <span className="text-sm text-green-600 dark:text-green-400">Aktif</span>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}