import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { FileText, Upload, Download, Trash2 } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { LANGUAGES } from "@/lib/constants";
import { useI18n } from "@/lib/i18n/context";

export default function DocumentTranslate() {
  const [sourceLang, setSourceLang] = useState("en");
  const [targetLang, setTargetLang] = useState("tr");
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const [translatedContent, setTranslatedContent] = useState("");
  const [currentDocumentId, setCurrentDocumentId] = useState<string | null>(null);
  
  const { t } = useI18n();
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const { data: documents = [], isLoading } = useQuery({
    queryKey: ["/api/documents"],
  });

  const translateMutation = useMutation({
    mutationFn: async (data: { fileName: string; content: string; sourceLang: string; targetLang: string }) => {
      const response = await apiRequest("POST", "/api/document-translate", data);
      return response.json();
    },
    onSuccess: (data) => {
      setTranslatedContent(data.translatedContent);
      setCurrentDocumentId(data.id);
      queryClient.invalidateQueries({ queryKey: ["/api/documents"] });
      toast({
        title: t('document.documentTranslatedSuccess'),
        description: t('document.downloadDescription'),
      });
    },
    onError: (error) => {
      toast({
        title: t('document.translationFailed'),
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const handleFileSelect = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      // Only accept text files for now
      if (file.type.startsWith('text/') || file.name.endsWith('.txt')) {
        setSelectedFile(file);
        toast({
          title: t('document.fileSelected'),
          description: file.name,
        });
      } else {
        toast({
          title: t('document.unsupportedFileType'),
          description: t('document.selectTextFile'),
          variant: "destructive",
        });
      }
    }
  };

  const handleTranslate = async () => {
    if (!selectedFile) {
      toast({
        title: t('document.pleaseSelectFile'),
        variant: "destructive",
      });
      return;
    }

    try {
      const content = await selectedFile.text();
      translateMutation.mutate({
        fileName: selectedFile.name,
        content,
        sourceLang,
        targetLang,
      });
    } catch (error) {
      toast({
        title: t('document.errorReadingFile'),
        description: t('document.couldNotReadFile'),
        variant: "destructive",
      });
    }
  };

  const handleDownload = () => {
    if (translatedContent && selectedFile) {
      const blob = new Blob([translatedContent], { type: 'text/plain' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `translated_${selectedFile.name}`;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      URL.revokeObjectURL(url);
      
      toast({
        title: t('document.downloadStarted'),
        description: t('document.documentDownloading'),
      });
    }
  };

  const handleSwapLanguages = () => {
    const temp = sourceLang;
    setSourceLang(targetLang);
    setTargetLang(temp);
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'completed':
        return 'bg-emerald-100 text-emerald-800 dark:bg-emerald-900/50 dark:text-emerald-200';
      case 'pending':
        return 'bg-yellow-100 text-yellow-800 dark:bg-yellow-900/50 dark:text-yellow-200';
      case 'failed':
        return 'bg-red-100 text-red-800 dark:bg-red-900/50 dark:text-red-200';
      default:
        return 'bg-gray-100 text-gray-800 dark:bg-gray-800 dark:text-gray-200';
    }
  };

  return (
    <div className="max-w-6xl mx-auto space-y-6">
      {/* Language Selection */}
      <Card>
        <CardHeader>
          <CardTitle data-testid="language-selection-title">{t('document.languageSelection')}</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 items-center">
            <div>
              <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                {t('document.from')}
              </label>
              <Select value={sourceLang} onValueChange={setSourceLang}>
                <SelectTrigger data-testid="select-source-language">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {LANGUAGES.map((lang) => (
                    <SelectItem key={lang.code} value={lang.code}>
                      {lang.flag} {lang.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            
            <div className="flex justify-center">
              <Button
                variant="outline"
                size="icon"
                onClick={handleSwapLanguages}
                className="rounded-full"
                data-testid="button-swap-languages"
              >
                ⇄
              </Button>
            </div>
            
            <div>
              <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                {t('document.to')}
              </label>
              <Select value={targetLang} onValueChange={setTargetLang}>
                <SelectTrigger data-testid="select-target-language">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {LANGUAGES.map((lang) => (
                    <SelectItem key={lang.code} value={lang.code}>
                      {lang.flag} {lang.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* File Upload and Translation */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* File Upload */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center" data-testid="file-upload-title">
              <Upload className="h-5 w-5 mr-2" />
              {t('document.uploadDocument')}
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div>
              <Input
                type="file"
                accept=".txt,text/*"
                onChange={handleFileSelect}
                className="cursor-pointer"
                data-testid="input-file-upload"
              />
              <p className="text-sm text-gray-500 dark:text-gray-400 mt-2">
                {t('document.supportedFormats')}
              </p>
            </div>
            
            {selectedFile && (
              <div className="p-3 bg-gray-50 dark:bg-gray-800 rounded-lg">
                <div className="flex items-center space-x-2">
                  <FileText className="h-4 w-4 text-gray-500" />
                  <span className="text-sm font-medium" data-testid="selected-file-name">
                    {selectedFile.name}
                  </span>
                  <span className="text-sm text-gray-500" data-testid="selected-file-size">
                    ({(selectedFile.size / 1024).toFixed(1)} KB)
                  </span>
                </div>
              </div>
            )}
            
            <Button
              onClick={handleTranslate}
              disabled={!selectedFile || translateMutation.isPending}
              className="w-full"
              data-testid="button-translate-document"
            >
              {translateMutation.isPending ? (
                <div className="animate-pulse">{t('document.translating')}</div>
              ) : (
                <>
                  <FileText className="h-4 w-4 mr-2" />
                  {t('document.translateDocument')}
                </>
              )}
            </Button>
          </CardContent>
        </Card>

        {/* Translation Result */}
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0">
            <CardTitle data-testid="translation-result-title">{t('document.translationResult')}</CardTitle>
            {translatedContent && (
              <Button
                variant="outline"
                size="sm"
                onClick={handleDownload}
                data-testid="button-download"
              >
                <Download className="h-4 w-4 mr-2" />
                {t('document.download')}
              </Button>
            )}
          </CardHeader>
          <CardContent>
            <Textarea
              value={translatedContent}
              readOnly
              placeholder={t('document.translatedContent')}
              className="min-h-64 resize-none"
              data-testid="textarea-translated-content"
            />
          </CardContent>
        </Card>
      </div>

      {/* Document History */}
      <Card>
        <CardHeader>
          <CardTitle data-testid="document-history-title">{t('document.documentHistory')}</CardTitle>
        </CardHeader>
        <CardContent>
          {isLoading ? (
            <div className="animate-pulse space-y-4">
              {[1, 2, 3].map((i) => (
                <div key={i} className="h-16 bg-gray-200 dark:bg-gray-700 rounded-lg" />
              ))}
            </div>
          ) : documents.length === 0 ? (
            <div className="text-center py-8 text-gray-500 dark:text-gray-400">
              <FileText className="h-12 w-12 mx-auto mb-4 opacity-50" />
              <p data-testid="no-documents-message">{t('document.noDocuments')}</p>
            </div>
          ) : (
            <div className="space-y-4">
              {documents.map((doc: any) => (
                <div
                  key={doc.id}
                  className="flex items-center justify-between p-4 border border-gray-200 dark:border-gray-700 rounded-lg"
                  data-testid={`document-item-${doc.id}`}
                >
                  <div className="flex-1">
                    <div className="flex items-center space-x-3">
                      <FileText className="h-5 w-5 text-gray-400" />
                      <div>
                        <p className="font-medium text-gray-900 dark:text-white" data-testid={`document-name-${doc.id}`}>
                          {doc.fileName}
                        </p>
                        <p className="text-sm text-gray-500 dark:text-gray-400" data-testid={`document-langs-${doc.id}`}>
                          {doc.sourceLang.toUpperCase()} → {doc.targetLang.toUpperCase()}
                        </p>
                      </div>
                    </div>
                  </div>
                  <div className="flex items-center space-x-3">
                    <Badge 
                      variant="secondary" 
                      className={getStatusColor(doc.status)}
                      data-testid={`document-status-${doc.id}`}
                    >
                      {t(`document.${doc.status}`)}
                    </Badge>
                    <span className="text-sm text-gray-500 dark:text-gray-400" data-testid={`document-date-${doc.id}`}>
                      {new Date(doc.createdAt).toLocaleDateString()}
                    </span>
                  </div>
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
