import { useState } from "react";
import { useMutation } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { Minimize2, Copy, Download, FileText, Wand2 } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { LANGUAGES } from "@/lib/constants";
import { useI18n } from "@/lib/i18n/context";

export default function Summarize() {
  const [inputText, setInputText] = useState("");
  const [summary, setSummary] = useState("");
  const [language, setLanguage] = useState("en");
  
  const { t } = useI18n();
  const { toast } = useToast();

  const summarizeMutation = useMutation({
    mutationFn: async (data: { text: string; language: string }) => {
      const response = await apiRequest("POST", "/api/summarize", data);
      return response.json();
    },
    onSuccess: (data) => {
      setSummary(data.summary);
      toast({
        title: t('summarize.textSummarizedSuccess'),
        description: t('summarize.summaryReady'),
      });
    },
    onError: (error) => {
      toast({
        title: t('summarize.summarizationFailed'),
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const handleSummarize = () => {
    if (!inputText.trim()) {
      toast({
        title: t('summarize.pleaseEnterText'),
        variant: "destructive",
      });
      return;
    }

    if (inputText.trim().length < 100) {
      toast({
        title: t('summarize.textTooShort'),
        description: t('summarize.minimumCharacters'),
        variant: "destructive",
      });
      return;
    }

    summarizeMutation.mutate({
      text: inputText,
      language,
    });
  };

  const handleCopy = async () => {
    if (summary) {
      await navigator.clipboard.writeText(summary);
      toast({
        title: t('summarize.summaryCopied'),
      });
    }
  };

  const handleDownload = () => {
    if (summary) {
      const blob = new Blob([summary], { type: 'text/plain' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `summary_${Date.now()}.txt`;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      URL.revokeObjectURL(url);
      
      toast({
        title: t('summarize.downloadStarted'),
        description: t('summarize.summaryDownloading'),
      });
    }
  };

  const handleClear = () => {
    setInputText("");
    setSummary("");
  };

  const calculateCompressionRatio = () => {
    if (!inputText || !summary) return 0;
    return Math.round((1 - summary.length / inputText.length) * 100);
  };

  const getWordCount = (text: string) => {
    return text.split(/\s+/).filter(word => word.length > 0).length;
  };

  return (
    <div className="max-w-6xl mx-auto space-y-6">
      {/* Language Selection */}
      <Card>
        <CardHeader>
          <CardTitle data-testid="language-selection-title">{t('summarize.summaryLanguage')}</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="max-w-md">
            <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
              {t('summarize.selectSummaryLanguage')}
            </label>
            <Select value={language} onValueChange={setLanguage}>
              <SelectTrigger data-testid="select-summary-language">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                {LANGUAGES.map((lang) => (
                  <SelectItem key={lang.code} value={lang.code}>
                    {lang.flag} {lang.name}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
        </CardContent>
      </Card>

      {/* Text Input and Summary */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Input Text */}
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-4">
            <CardTitle className="text-lg font-semibold" data-testid="input-text-title">
              {t('summarize.inputText')}
            </CardTitle>
            <div className="flex items-center space-x-2">
              <Button
                variant="ghost"
                size="sm"
                onClick={handleClear}
                data-testid="button-clear-input"
              >
{t('summarize.clear')}
              </Button>
            </div>
          </CardHeader>
          <CardContent>
            <Textarea
              placeholder={t('summarize.inputTextPlaceholder')}
              value={inputText}
              onChange={(e) => setInputText(e.target.value)}
              className="min-h-80 resize-none"
              data-testid="textarea-input-text"
            />
            <div className="flex items-center justify-between mt-3 text-sm text-gray-500 dark:text-gray-400">
              <div className="space-x-4">
                <span data-testid="input-character-count">{inputText.length} {t('summarize.characters')}</span>
                <span data-testid="input-word-count">{getWordCount(inputText)} {t('summarize.words')}</span>
              </div>
              <Button
                onClick={handleSummarize}
                disabled={summarizeMutation.isPending || inputText.trim().length < 100}
                className="bg-blue-600 hover:bg-blue-700"
                data-testid="button-summarize"
              >
                {summarizeMutation.isPending ? (
                  <div className="animate-pulse">{t('summarize.summarizing')}</div>
                ) : (
                  <>
                    <Wand2 className="h-4 w-4 mr-2" />
                    {t('summarize.summarize')}
                  </>
                )}
              </Button>
            </div>
          </CardContent>
        </Card>

        {/* Summary Result */}
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-4">
            <CardTitle className="text-lg font-semibold" data-testid="summary-title">
              {t('summarize.summary')}
            </CardTitle>
            <div className="flex items-center space-x-2">
              <Button
                variant="ghost"
                size="sm"
                onClick={handleCopy}
                disabled={!summary}
                data-testid="button-copy-summary"
              >
                <Copy className="h-4 w-4" />
              </Button>
              <Button
                variant="ghost"
                size="sm"
                onClick={handleDownload}
                disabled={!summary}
                data-testid="button-download-summary"
              >
                <Download className="h-4 w-4" />
              </Button>
            </div>
          </CardHeader>
          <CardContent>
            <div className="relative">
              <div className="min-h-80 p-4 bg-gray-50 dark:bg-gray-900 border border-gray-200 dark:border-gray-700 rounded-lg overflow-y-auto">
                {summary ? (
                  <div className="text-gray-900 dark:text-white leading-relaxed" data-testid="text-summary">
                    {summary}
                  </div>
                ) : (
                  <div className="text-gray-500 dark:text-gray-400 italic" data-testid="text-summary-placeholder">
                    {t('summarize.summaryPlaceholder')}
                  </div>
                )}
              </div>
              {summary && (
                <div className="absolute top-2 right-2">
                  <Badge variant="secondary" className="bg-emerald-100 text-emerald-800 dark:bg-emerald-900 dark:text-emerald-200">
                    <div className="flex items-center space-x-1">
                      <Minimize2 className="w-3 h-3" />
                      <span data-testid="badge-summarized">{t('summarize.summarized')}</span>
                    </div>
                  </Badge>
                </div>
              )}
            </div>

            {/* Summary Statistics */}
            {summary && (
              <div className="mt-4 pt-4 border-t border-gray-100 dark:border-gray-700">
                <div className="grid grid-cols-2 gap-4 text-sm">
                  <div className="space-y-2">
                    <div className="flex justify-between">
                      <span className="text-gray-600 dark:text-gray-400">{t('summarize.characters')}:</span>
                      <span className="font-medium" data-testid="summary-character-count">
                        {summary.length}
                      </span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-600 dark:text-gray-400">{t('summarize.words')}:</span>
                      <span className="font-medium" data-testid="summary-word-count">
                        {getWordCount(summary)}
                      </span>
                    </div>
                  </div>
                  <div className="space-y-2">
                    <div className="flex justify-between">
                      <span className="text-gray-600 dark:text-gray-400">{t('summarize.compression')}:</span>
                      <span className="font-medium text-emerald-600" data-testid="compression-ratio">
                        {calculateCompressionRatio()}%
                      </span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-600 dark:text-gray-400">{t('summarize.language')}:</span>
                      <span className="font-medium" data-testid="summary-language">
                        {LANGUAGES.find(l => l.code === language)?.name}
                      </span>
                    </div>
                  </div>
                </div>
              </div>
            )}
          </CardContent>
        </Card>
      </div>

      {/* Features and Tips */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {/* Summarization Features */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center" data-testid="features-title">
              <FileText className="h-5 w-5 mr-2" />
              {t('summarize.summarizationFeatures')}
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-3 text-sm text-gray-600 dark:text-gray-400">
              <div className="flex items-start space-x-3">
                <div className="w-2 h-2 bg-blue-500 rounded-full mt-2"></div>
                <p>{t('summarize.featureKeyPoints')}</p>
              </div>
              <div className="flex items-start space-x-3">
                <div className="w-2 h-2 bg-blue-500 rounded-full mt-2"></div>
                <p>{t('summarize.featureMaintainsMeaning')}</p>
              </div>
              <div className="flex items-start space-x-3">
                <div className="w-2 h-2 bg-blue-500 rounded-full mt-2"></div>
                <p>{t('summarize.featureMultiLanguage')}</p>
              </div>
              <div className="flex items-start space-x-3">
                <div className="w-2 h-2 bg-blue-500 rounded-full mt-2"></div>
                <p>{t('summarize.featureCompression')}</p>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Best Practices */}
        <Card>
          <CardHeader>
            <CardTitle data-testid="best-practices-title">{t('summarize.bestPractices')}</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-3 text-sm text-gray-600 dark:text-gray-400">
              <div className="flex items-start space-x-3">
                <div className="w-2 h-2 bg-emerald-500 rounded-full mt-2"></div>
                <p>{t('summarize.practiceWellStructured')}</p>
              </div>
              <div className="flex items-start space-x-3">
                <div className="w-2 h-2 bg-emerald-500 rounded-full mt-2"></div>
                <p>{t('summarize.practiceMinimumLength')}</p>
              </div>
              <div className="flex items-start space-x-3">
                <div className="w-2 h-2 bg-emerald-500 rounded-full mt-2"></div>
                <p>{t('summarize.practiceMainPoints')}</p>
              </div>
              <div className="flex items-start space-x-3">
                <div className="w-2 h-2 bg-emerald-500 rounded-full mt-2"></div>
                <p>{t('summarize.practiceLanguageChoice')}</p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
