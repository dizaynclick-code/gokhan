import { useState, useRef } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { Mic, Upload, Download, Play, Pause, Square } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { LANGUAGES } from "@/lib/constants";
import { useI18n } from "@/lib/i18n/context";

export default function AudioTranscribe() {
  const [language, setLanguage] = useState("en");
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const [transcription, setTranscription] = useState("");
  const [currentTranscriptionId, setCurrentTranscriptionId] = useState<string | null>(null);
  const [isRecording, setIsRecording] = useState(false);
  const [mediaRecorder, setMediaRecorder] = useState<MediaRecorder | null>(null);
  const [audioChunks, setAudioChunks] = useState<Blob[]>([]);
  
  const { t } = useI18n();
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const fileInputRef = useRef<HTMLInputElement>(null);

  const { data: transcriptions = [], isLoading } = useQuery({
    queryKey: ["/api/audio-transcriptions"],
  });

  const transcribeMutation = useMutation({
    mutationFn: async (data: { fileName: string; language: string }) => {
      const response = await apiRequest("POST", "/api/audio-transcribe", data);
      return response.json();
    },
    onSuccess: (data) => {
      setTranscription(data.transcription);
      setCurrentTranscriptionId(data.id);
      queryClient.invalidateQueries({ queryKey: ["/api/audio-transcriptions"] });
      toast({
        title: t('audio.transcribedSuccess'),
        description: t('audio.transcriptionReady'),
      });
    },
    onError: (error) => {
      toast({
        title: t('audio.transcriptionFailed'),
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const handleFileSelect = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      if (file.type.startsWith('audio/')) {
        setSelectedFile(file);
        toast({
          title: t('audio.audioFileSelected'),
          description: file.name,
        });
      } else {
        toast({
          title: t('audio.unsupportedFileType'),
          description: t('audio.selectAudioFile'),
          variant: "destructive",
        });
      }
    }
  };

  const handleTranscribe = () => {
    if (!selectedFile) {
      toast({
        title: t('audio.pleaseSelectAudio'),
        variant: "destructive",
      });
      return;
    }

    transcribeMutation.mutate({
      fileName: selectedFile.name,
      language,
    });
  };

  const startRecording = async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      const recorder = new MediaRecorder(stream);
      
      recorder.ondataavailable = (event) => {
        if (event.data.size > 0) {
          setAudioChunks(prev => [...prev, event.data]);
        }
      };

      recorder.onstop = () => {
        const audioBlob = new Blob(audioChunks, { type: 'audio/wav' });
        const audioFile = new File([audioBlob], `recording_${Date.now()}.wav`, { type: 'audio/wav' });
        setSelectedFile(audioFile);
        setAudioChunks([]);
        stream.getTracks().forEach(track => track.stop());
      };

      setMediaRecorder(recorder);
      recorder.start();
      setIsRecording(true);
      
      toast({
        title: t('audio.recordingStarted'),
        description: t('audio.speakIntoMic'),
      });
    } catch (error) {
      toast({
        title: t('audio.recordingFailed'),
        description: t('audio.couldNotAccessMic'),
        variant: "destructive",
      });
    }
  };

  const stopRecording = () => {
    if (mediaRecorder && isRecording) {
      mediaRecorder.stop();
      setIsRecording(false);
      toast({
        title: t('audio.recordingStopped'),
        description: t('audio.audioSaved'),
      });
    }
  };

  const handleDownload = () => {
    if (transcription) {
      const blob = new Blob([transcription], { type: 'text/plain' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `transcription_${Date.now()}.txt`;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      URL.revokeObjectURL(url);
      
      toast({
        title: t('audio.downloadStarted'),
        description: t('audio.transcriptionDownloading'),
      });
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'completed':
        return 'bg-emerald-100 text-emerald-800 dark:bg-emerald-900/50 dark:text-emerald-200';
      case 'pending':
        return 'bg-yellow-100 text-yellow-800 dark:bg-yellow-900/50 dark:text-yellow-200';
      case 'failed':
        return 'bg-red-100 text-red-800 dark:bg-red-900/50 dark:text-red-200';
      default:
        return 'bg-gray-100 text-gray-800 dark:bg-gray-800 dark:text-gray-200';
    }
  };

  return (
    <div className="max-w-6xl mx-auto space-y-6">
      {/* Language Selection */}
      <Card>
        <CardHeader>
          <CardTitle data-testid="language-selection-title">{t('audio.audioLanguage')}</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="max-w-md">
            <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
              {t('audio.selectAudioLanguage')}
            </label>
            <Select value={language} onValueChange={setLanguage}>
              <SelectTrigger data-testid="select-audio-language">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                {LANGUAGES.map((lang) => (
                  <SelectItem key={lang.code} value={lang.code}>
                    {lang.flag} {lang.name}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
        </CardContent>
      </Card>

      {/* Audio Input and Transcription */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Audio Input */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center" data-testid="audio-input-title">
              <Mic className="h-5 w-5 mr-2" />
              {t('audio.audioInput')}
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            {/* Recording Controls */}
            <div className="space-y-4">
              <h4 className="font-medium text-gray-900 dark:text-white">{t('audio.recordAudio')}</h4>
              <div className="flex items-center space-x-4">
                {!isRecording ? (
                  <Button
                    onClick={startRecording}
                    className="bg-red-600 hover:bg-red-700 text-white"
                    data-testid="button-start-recording"
                  >
                    <Mic className="h-4 w-4 mr-2" />
                    {t('audio.startRecording')}
                  </Button>
                ) : (
                  <Button
                    onClick={stopRecording}
                    variant="outline"
                    className="border-red-600 text-red-600 hover:bg-red-50 dark:hover:bg-red-900/20"
                    data-testid="button-stop-recording"
                  >
                    <Square className="h-4 w-4 mr-2" />
                    {t('audio.stopRecording')}
                  </Button>
                )}
                {isRecording && (
                  <div className="flex items-center space-x-2 text-red-600">
                    <div className="w-3 h-3 bg-red-600 rounded-full animate-pulse"></div>
                    <span className="text-sm font-medium" data-testid="recording-indicator">{t('audio.recording')}</span>
                  </div>
                )}
              </div>
            </div>

            <div className="relative">
              <div className="absolute inset-0 flex items-center">
                <div className="w-full border-t border-gray-300 dark:border-gray-600" />
              </div>
              <div className="relative flex justify-center text-sm">
                <span className="px-2 bg-white dark:bg-gray-800 text-gray-500 dark:text-gray-400">{t('common.or')}</span>
              </div>
            </div>

            {/* File Upload */}
            <div className="space-y-4">
              <h4 className="font-medium text-gray-900 dark:text-white">{t('audio.uploadAudioFile')}</h4>
              <div>
                <Input
                  ref={fileInputRef}
                  type="file"
                  accept="audio/*"
                  onChange={handleFileSelect}
                  className="cursor-pointer"
                  data-testid="input-audio-upload"
                />
                <p className="text-sm text-gray-500 dark:text-gray-400 mt-2">
                  {t('audio.supportedFormats')}
                </p>
              </div>
            </div>
            
            {selectedFile && (
              <div className="p-3 bg-gray-50 dark:bg-gray-800 rounded-lg">
                <div className="flex items-center space-x-2">
                  <Mic className="h-4 w-4 text-gray-500" />
                  <span className="text-sm font-medium" data-testid="selected-audio-name">
                    {selectedFile.name}
                  </span>
                  <span className="text-sm text-gray-500" data-testid="selected-audio-size">
                    ({(selectedFile.size / 1024 / 1024).toFixed(1)} MB)
                  </span>
                </div>
              </div>
            )}
            
            <Button
              onClick={handleTranscribe}
              disabled={!selectedFile || transcribeMutation.isPending}
              className="w-full"
              data-testid="button-transcribe-audio"
            >
              {transcribeMutation.isPending ? (
                <div className="animate-pulse">{t('audio.transcribing')}</div>
              ) : (
                <>
                  <Mic className="h-4 w-4 mr-2" />
                  {t('audio.transcribeAudio')}
                </>
              )}
            </Button>
          </CardContent>
        </Card>

        {/* Transcription Result */}
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0">
            <CardTitle data-testid="transcription-result-title">{t('audio.transcriptionResult')}</CardTitle>
            {transcription && (
              <Button
                variant="outline"
                size="sm"
                onClick={handleDownload}
                data-testid="button-download-transcription"
              >
                <Download className="h-4 w-4 mr-2" />
                {t('audio.download')}
              </Button>
            )}
          </CardHeader>
          <CardContent>
            <Textarea
              value={transcription}
              readOnly
              placeholder={t('audio.transcribedText')}
              className="min-h-64 resize-none"
              data-testid="textarea-transcription"
            />
          </CardContent>
        </Card>
      </div>

      {/* Transcription History */}
      <Card>
        <CardHeader>
          <CardTitle data-testid="transcription-history-title">{t('audio.transcriptionHistory')}</CardTitle>
        </CardHeader>
        <CardContent>
          {isLoading ? (
            <div className="animate-pulse space-y-4">
              {[1, 2, 3].map((i) => (
                <div key={i} className="h-16 bg-gray-200 dark:bg-gray-700 rounded-lg" />
              ))}
            </div>
          ) : transcriptions.length === 0 ? (
            <div className="text-center py-8 text-gray-500 dark:text-gray-400">
              <Mic className="h-12 w-12 mx-auto mb-4 opacity-50" />
              <p data-testid="no-transcriptions-message">{t('audio.noTranscriptions')}</p>
            </div>
          ) : (
            <div className="space-y-4">
              {transcriptions.map((item: any) => (
                <div
                  key={item.id}
                  className="flex items-center justify-between p-4 border border-gray-200 dark:border-gray-700 rounded-lg"
                  data-testid={`transcription-item-${item.id}`}
                >
                  <div className="flex-1">
                    <div className="flex items-center space-x-3">
                      <Mic className="h-5 w-5 text-gray-400" />
                      <div>
                        <p className="font-medium text-gray-900 dark:text-white" data-testid={`transcription-name-${item.id}`}>
                          {item.fileName}
                        </p>
                        <p className="text-sm text-gray-500 dark:text-gray-400" data-testid={`transcription-lang-${item.id}`}>
                          {item.language.toUpperCase()} • {item.duration ? `${item.duration}s` : t('audio.durationUnknown')}
                        </p>
                      </div>
                    </div>
                  </div>
                  <div className="flex items-center space-x-3">
                    <Badge 
                      variant="secondary" 
                      className={getStatusColor(item.status)}
                      data-testid={`transcription-status-${item.id}`}
                    >
                      {item.status}
                    </Badge>
                    <span className="text-sm text-gray-500 dark:text-gray-400" data-testid={`transcription-date-${item.id}`}>
                      {new Date(item.createdAt).toLocaleDateString()}
                    </span>
                  </div>
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
