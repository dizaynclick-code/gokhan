import { useState, useRef, useEffect } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { Mic, Square, Copy, Download, Volume2 } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { LANGUAGES } from "@/lib/constants";
import { useI18n } from "@/lib/i18n/context";

export default function SpeechToText() {
  const [language, setLanguage] = useState("en");
  const [isListening, setIsListening] = useState(false);
  const [transcript, setTranscript] = useState("");
  const [interimTranscript, setInterimTranscript] = useState("");
  const [recognition, setRecognition] = useState<SpeechRecognition | null>(null);
  const [isSupported, setIsSupported] = useState(true);
  
  const { t } = useI18n();
  const { toast } = useToast();

  useEffect(() => {
    // Check if speech recognition is supported
    const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
    
    if (!SpeechRecognition) {
      setIsSupported(false);
      return;
    }

    const recognitionInstance = new SpeechRecognition();
    recognitionInstance.continuous = true;
    recognitionInstance.interimResults = true;
    recognitionInstance.lang = language;

    recognitionInstance.onresult = (event) => {
      let interimTranscript = '';
      let finalTranscript = '';

      for (let i = event.resultIndex; i < event.results.length; i++) {
        const transcript = event.results[i][0].transcript;
        if (event.results[i].isFinal) {
          finalTranscript += transcript;
        } else {
          interimTranscript += transcript;
        }
      }

      setTranscript(prev => prev + finalTranscript);
      setInterimTranscript(interimTranscript);
    };

    recognitionInstance.onerror = (event) => {
      console.error('Speech recognition error:', event.error);
      setIsListening(false);
      toast({
        title: t('speech.speechRecognitionError'),
        description: `Error: ${event.error}`,
        variant: "destructive",
      });
    };

    recognitionInstance.onend = () => {
      setIsListening(false);
      setInterimTranscript('');
    };

    setRecognition(recognitionInstance);
  }, [language, toast]);

  const startListening = () => {
    if (!recognition) return;

    try {
      recognition.start();
      setIsListening(true);
      toast({
        title: t('speech.speechRecognitionStarted'),
        description: t('speech.speakIntoMicrophone'),
      });
    } catch (error) {
      toast({
        title: t('speech.failedToStartSpeechRecognition'),
        description: t('speech.checkMicrophonePermissions'),
        variant: "destructive",
      });
    }
  };

  const stopListening = () => {
    if (recognition) {
      recognition.stop();
      setIsListening(false);
      toast({
        title: t('speech.speechRecognitionStopped'),
      });
    }
  };

  const handleClear = () => {
    setTranscript("");
    setInterimTranscript("");
  };

  const handleCopy = async () => {
    if (transcript) {
      await navigator.clipboard.writeText(transcript);
      toast({
        title: t('speech.textCopiedToClipboard'),
      });
    }
  };

  const handleDownload = () => {
    if (transcript) {
      const blob = new Blob([transcript], { type: 'text/plain' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `speech-to-text_${Date.now()}.txt`;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      URL.revokeObjectURL(url);
      
      toast({
        title: t('speech.downloadStarted'),
        description: t('speech.speechToTextDownloading'),
      });
    }
  };

  const playText = () => {
    if ('speechSynthesis' in window && transcript) {
      const utterance = new SpeechSynthesisUtterance(transcript);
      utterance.lang = language;
      speechSynthesis.speak(utterance);
      toast({
        title: t('speech.playingText'),
      });
    }
  };

  if (!isSupported) {
    return (
      <div className="max-w-4xl mx-auto">
        <Card>
          <CardContent className="text-center py-12">
            <Mic className="h-16 w-16 mx-auto mb-4 text-gray-400" />
            <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-2">
              {t('speech.speechRecognitionNotSupported')}
            </h3>
            <p className="text-gray-500 dark:text-gray-400">
              {t('speech.browserNotSupported')}
            </p>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="max-w-4xl mx-auto space-y-6">
      {/* Language Selection */}
      <Card>
        <CardHeader>
          <CardTitle data-testid="language-selection-title">{t('speech.speechLanguage')}</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="max-w-md">
            <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
              {t('speech.selectSpeechLanguage')}
            </label>
            <Select value={language} onValueChange={setLanguage}>
              <SelectTrigger data-testid="select-speech-language">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                {LANGUAGES.map((lang) => (
                  <SelectItem key={lang.code} value={lang.code}>
                    {lang.flag} {lang.name}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
        </CardContent>
      </Card>

      {/* Speech Recognition Controls */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center" data-testid="speech-controls-title">
            <Mic className="h-5 w-5 mr-2" />
            {t('speech.speechRecognition')}
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-6">
          {/* Controls */}
          <div className="flex items-center justify-center space-x-4">
            {!isListening ? (
              <Button
                onClick={startListening}
                size="lg"
                className="bg-blue-600 hover:bg-blue-700 text-white px-8 py-4"
                data-testid="button-start-listening"
              >
                <Mic className="h-5 w-5 mr-2" />
                {t('speech.startListening')}
              </Button>
            ) : (
              <Button
                onClick={stopListening}
                size="lg"
                variant="outline"
                className="border-red-600 text-red-600 hover:bg-red-50 dark:hover:bg-red-900/20 px-8 py-4"
                data-testid="button-stop-listening"
              >
                <Square className="h-5 w-5 mr-2" />
                {t('speech.stopListening')}
              </Button>
            )}
          </div>

          {/* Status Indicator */}
          {isListening && (
            <div className="flex items-center justify-center space-x-3">
              <div className="flex items-center space-x-2">
                <div className="w-3 h-3 bg-red-600 rounded-full animate-pulse"></div>
                <span className="text-red-600 font-medium" data-testid="listening-indicator">
                  {t('speech.listening')}
                </span>
              </div>
              <Badge variant="secondary" className="bg-blue-100 text-blue-800 dark:bg-blue-900/50 dark:text-blue-200">
                {language.toUpperCase()}
              </Badge>
            </div>
          )}

          {/* Real-time Transcript Display */}
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <h4 className="font-medium text-gray-900 dark:text-white">{t('speech.transcript')}</h4>
              <div className="flex items-center space-x-2">
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={playText}
                  disabled={!transcript}
                  data-testid="button-play-text"
                >
                  <Volume2 className="h-4 w-4" />
                </Button>
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={handleCopy}
                  disabled={!transcript}
                  data-testid="button-copy-text"
                >
                  <Copy className="h-4 w-4" />
                </Button>
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={handleDownload}
                  disabled={!transcript}
                  data-testid="button-download-text"
                >
                  <Download className="h-4 w-4" />
                </Button>
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={handleClear}
                  disabled={!transcript && !interimTranscript}
                  data-testid="button-clear-text"
                >
{t('speech.clear')}
                </Button>
              </div>
            </div>

            <div className="relative">
              <Textarea
                value={transcript + interimTranscript}
                readOnly
                placeholder={t('speech.startSpeakingPlaceholder')}
                className="min-h-64 resize-none"
                data-testid="textarea-transcript"
              />
              {interimTranscript && (
                <div className="absolute bottom-2 right-2">
                  <Badge variant="secondary" className="bg-yellow-100 text-yellow-800 dark:bg-yellow-900/50 dark:text-yellow-200">
{t('speech.processing')}
                  </Badge>
                </div>
              )}
              {transcript && !interimTranscript && !isListening && (
                <div className="absolute bottom-2 right-2">
                  <Badge variant="secondary" className="bg-emerald-100 text-emerald-800 dark:bg-emerald-900/50 dark:text-emerald-200">
{t('speech.complete')}
                  </Badge>
                </div>
              )}
            </div>

            {/* Character Count */}
            <div className="flex justify-between text-sm text-gray-500 dark:text-gray-400">
              <span data-testid="character-count">{(transcript + interimTranscript).length} {t('speech.characters')}</span>
              <span data-testid="word-count">
                {(transcript + interimTranscript).split(/\s+/).filter(word => word.length > 0).length} {t('speech.words')}
              </span>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Tips Card */}
      <Card>
        <CardHeader>
          <CardTitle data-testid="tips-title">{t('speech.tips')}</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-sm text-gray-600 dark:text-gray-400">
            <div className="space-y-2">
              <p>• {t('speech.tipClearSpeech')}</p>
              <p>• {t('speech.tipQuietEnvironment')}</p>
              <p>• {t('speech.tipMicrophoneDistance')}</p>
            </div>
            <div className="space-y-2">
              <p>• {t('speech.tipPauseBetweenSentences')}</p>
              <p>• {t('speech.tipMicrophonePermissions')}</p>
              <p>• {t('speech.tipSelectCorrectLanguage')}</p>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
