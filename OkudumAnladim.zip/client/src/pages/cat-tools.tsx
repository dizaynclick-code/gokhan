import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Badge } from "@/components/ui/badge";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { useI18n } from "@/lib/i18n/context";
import { 
  Upload, 
  Download, 
  FileText, 
  Database, 
  Settings,
  RefreshCw,
  CheckCircle,
  AlertCircle,
  Folder,
  ArrowUpDown
} from "lucide-react";

interface CatProject {
  id: string;
  name: string;
  sourceLanguage: string;
  targetLanguage: string;
  fileFormat: 'xliff' | 'tmx' | 'tbx' | 'sdlxliff';
  status: 'importing' | 'ready' | 'processing' | 'completed' | 'error';
  createdAt: string;
  segmentCount?: number;
  translatedCount?: number;
}

export default function CatTools() {
  const { t } = useI18n();
  const { toast } = useToast();
  const queryClient = useQueryClient();
  
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const [isImporting, setIsImporting] = useState(false);
  const [activeTab, setActiveTab] = useState("import");

  const { data: catProjects = [], isLoading } = useQuery<CatProject[]>({
    queryKey: ["/api/cat-tools/projects"],
  });

  const importFileMutation = useMutation({
    mutationFn: async (file: File) => {
      const formData = new FormData();
      formData.append('file', file);
      const response = await fetch('/api/cat-tools/import', {
        method: 'POST',
        body: formData,
      });
      if (!response.ok) throw new Error('Import failed');
      return response.json();
    },
    onSuccess: () => {
      setSelectedFile(null);
      setIsImporting(false);
      queryClient.invalidateQueries({ queryKey: ["/api/cat-tools/projects"] });
      toast({
        title: "Dosya başarıyla import edildi!",
        description: "CAT tool dosyanız sisteme aktarıldı ve işleme alındı.",
      });
    },
    onError: (error) => {
      setIsImporting(false);
      toast({
        title: "Import hatası",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const exportTmMutation = useMutation({
    mutationFn: async (format: string) => {
      const response = await apiRequest("POST", "/api/cat-tools/export-tm", { format });
      return response.blob();
    },
    onSuccess: (blob, format) => {
      const url = window.URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `translation-memory.${format}`;
      document.body.appendChild(a);
      a.click();
      window.URL.revokeObjectURL(url);
      document.body.removeChild(a);
      
      toast({
        title: "Çeviri belleği dışa aktarıldı!",
        description: `${format.toUpperCase()} formatında dosya indirildi.`,
      });
    },
  });

  const handleFileSelect = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      const allowedTypes = ['.xliff', '.xlf', '.tmx', '.tbx', '.sdlxliff'];
      const fileExtension = '.' + file.name.split('.').pop()?.toLowerCase();
      
      if (!allowedTypes.includes(fileExtension)) {
        toast({
          title: "Desteklenmeyen dosya formatı",
          description: "Lütfen XLIFF, TMX, TBX veya SDLXLIFF dosyası seçin.",
          variant: "destructive",
        });
        return;
      }
      
      setSelectedFile(file);
    }
  };

  const handleImport = () => {
    if (!selectedFile) return;
    
    setIsImporting(true);
    importFileMutation.mutate(selectedFile);
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'ready':
      case 'completed':
        return <CheckCircle className="h-4 w-4 text-green-500" />;
      case 'importing':
      case 'processing':
        return <RefreshCw className="h-4 w-4 text-blue-500 animate-spin" />;
      case 'error':
        return <AlertCircle className="h-4 w-4 text-red-500" />;
      default:
        return <FileText className="h-4 w-4 text-gray-500" />;
    }
  };

  const getStatusText = (status: string) => {
    switch (status) {
      case 'ready': return 'Hazır';
      case 'completed': return 'Tamamlandı';
      case 'importing': return 'İçe aktarılıyor';
      case 'processing': return 'İşleniyor';
      case 'error': return 'Hata';
      default: return status;
    }
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-gray-900 dark:text-white">
            CAT Tools Entegrasyonu
          </h1>
          <p className="text-gray-600 dark:text-gray-400 mt-2">
            Profesyonel çeviri araçları ile çalışın - XLIFF, TMX, TBX format desteği
          </p>
        </div>
      </div>

      <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-6">
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="import" className="flex items-center space-x-2">
            <Upload className="h-4 w-4" />
            <span>İçe Aktar</span>
          </TabsTrigger>
          <TabsTrigger value="export" className="flex items-center space-x-2">
            <Download className="h-4 w-4" />
            <span>Dışa Aktar</span>
          </TabsTrigger>
          <TabsTrigger value="projects" className="flex items-center space-x-2">
            <Folder className="h-4 w-4" />
            <span>Projeler</span>
          </TabsTrigger>
          <TabsTrigger value="settings" className="flex items-center space-x-2">
            <Settings className="h-4 w-4" />
            <span>Ayarlar</span>
          </TabsTrigger>
        </TabsList>

        {/* Import Tab */}
        <TabsContent value="import" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center">
                <Upload className="h-5 w-5 mr-2" />
                CAT Tool Dosyası İçe Aktar
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                {/* Supported Formats */}
                <div className="space-y-4">
                  <h3 className="font-medium text-gray-900 dark:text-white">
                    Desteklenen Formatlar
                  </h3>
                  <div className="space-y-2">
                    {[
                      { format: 'XLIFF', extension: '.xliff, .xlf', description: 'XML Localization Interchange File Format' },
                      { format: 'TMX', extension: '.tmx', description: 'Translation Memory eXchange' },
                      { format: 'TBX', extension: '.tbx', description: 'TermBase eXchange' },
                      { format: 'SDLXLIFF', extension: '.sdlxliff', description: 'SDL Trados Studio Format' }
                    ].map((item) => (
                      <div key={item.format} className="flex items-center space-x-3 p-3 border rounded-lg">
                        <FileText className="h-5 w-5 text-blue-500" />
                        <div>
                          <div className="font-medium">{item.format}</div>
                          <div className="text-sm text-gray-500">{item.extension}</div>
                          <div className="text-xs text-gray-400">{item.description}</div>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>

                {/* File Upload */}
                <div className="space-y-4">
                  <h3 className="font-medium text-gray-900 dark:text-white">
                    Dosya Seç
                  </h3>
                  <div className="border-2 border-dashed border-gray-300 dark:border-gray-600 rounded-lg p-6 text-center">
                    <input
                      type="file"
                      id="cat-file-upload"
                      className="hidden"
                      accept=".xliff,.xlf,.tmx,.tbx,.sdlxliff"
                      onChange={handleFileSelect}
                      data-testid="input-cat-file"
                    />
                    <label
                      htmlFor="cat-file-upload"
                      className="cursor-pointer flex flex-col items-center space-y-2"
                    >
                      <Upload className="h-8 w-8 text-gray-400" />
                      <span className="text-sm text-gray-600 dark:text-gray-400">
                        Dosya seçmek için tıklayın
                      </span>
                      <span className="text-xs text-gray-500">
                        XLIFF, TMX, TBX, SDLXLIFF
                      </span>
                    </label>
                  </div>

                  {selectedFile && (
                    <div className="bg-blue-50 dark:bg-blue-900/20 p-4 rounded-lg">
                      <div className="flex items-center justify-between">
                        <div className="flex items-center space-x-3">
                          <FileText className="h-5 w-5 text-blue-500" />
                          <div>
                            <div className="font-medium">{selectedFile.name}</div>
                            <div className="text-sm text-gray-500">
                              {(selectedFile.size / 1024 / 1024).toFixed(2)} MB
                            </div>
                          </div>
                        </div>
                        <Button
                          onClick={handleImport}
                          disabled={isImporting}
                          className="bg-blue-600 hover:bg-blue-700"
                          data-testid="button-import-file"
                        >
                          {isImporting ? (
                            <>
                              <RefreshCw className="h-4 w-4 mr-2 animate-spin" />
                              İçe Aktarılıyor...
                            </>
                          ) : (
                            <>
                              <Upload className="h-4 w-4 mr-2" />
                              İçe Aktar
                            </>
                          )}
                        </Button>
                      </div>
                    </div>
                  )}
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Export Tab */}
        <TabsContent value="export" className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {/* Translation Memory Export */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center">
                  <Database className="h-5 w-5 mr-2" />
                  Çeviri Belleği Dışa Aktarım
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <p className="text-sm text-gray-600 dark:text-gray-400">
                  Çeviri belleğinizi CAT araçlarında kullanmak için dışa aktarın.
                </p>
                <div className="space-y-2">
                  <Button
                    onClick={() => exportTmMutation.mutate('tmx')}
                    disabled={exportTmMutation.isPending}
                    className="w-full"
                    variant="outline"
                    data-testid="button-export-tmx"
                  >
                    <Download className="h-4 w-4 mr-2" />
                    TMX Formatında Dışa Aktar
                  </Button>
                  <Button
                    onClick={() => exportTmMutation.mutate('xliff')}
                    disabled={exportTmMutation.isPending}
                    className="w-full"
                    variant="outline"
                    data-testid="button-export-xliff"
                  >
                    <Download className="h-4 w-4 mr-2" />
                    XLIFF Formatında Dışa Aktar
                  </Button>
                </div>
              </CardContent>
            </Card>

            {/* Glossary Export */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center">
                  <FileText className="h-5 w-5 mr-2" />
                  Sözlük Dışa Aktarım
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <p className="text-sm text-gray-600 dark:text-gray-400">
                  Sözlük terimlerinizi TBX formatında dışa aktarın.
                </p>
                <Button
                  onClick={() => exportTmMutation.mutate('tbx')}
                  disabled={exportTmMutation.isPending}
                  className="w-full"
                  variant="outline"
                  data-testid="button-export-tbx"
                >
                  <Download className="h-4 w-4 mr-2" />
                  TBX Formatında Dışa Aktar
                </Button>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        {/* Projects Tab */}
        <TabsContent value="projects" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>CAT Tool Projeleri</CardTitle>
            </CardHeader>
            <CardContent>
              {isLoading ? (
                <div className="space-y-4">
                  {[1, 2, 3].map((i) => (
                    <div key={i} className="animate-pulse">
                      <div className="h-16 bg-gray-200 dark:bg-gray-700 rounded-lg" />
                    </div>
                  ))}
                </div>
              ) : catProjects.length === 0 ? (
                <div className="text-center py-12">
                  <Folder className="h-12 w-12 mx-auto mb-4 text-gray-400" />
                  <h3 className="text-lg font-medium text-gray-900 dark:text-white mb-2">
                    Henüz proje yok
                  </h3>
                  <p className="text-gray-600 dark:text-gray-400">
                    CAT tool dosyalarını içe aktararak başlayın.
                  </p>
                </div>
              ) : (
                <div className="space-y-4">
                  {catProjects.map((project) => (
                    <div key={project.id} className="border rounded-lg p-4 hover:shadow-md transition-shadow">
                      <div className="flex items-center justify-between">
                        <div className="flex items-center space-x-4">
                          {getStatusIcon(project.status)}
                          <div>
                            <h3 className="font-medium text-gray-900 dark:text-white">
                              {project.name}
                            </h3>
                            <div className="flex items-center space-x-4 text-sm text-gray-500">
                              <span>{project.sourceLanguage} → {project.targetLanguage}</span>
                              <Badge variant="secondary">{project.fileFormat.toUpperCase()}</Badge>
                              <span>
                                {project.translatedCount || 0} / {project.segmentCount || 0} segment
                              </span>
                            </div>
                          </div>
                        </div>
                        <div className="flex items-center space-x-2">
                          <Badge variant={project.status === 'completed' ? 'default' : 'secondary'}>
                            {getStatusText(project.status)}
                          </Badge>
                          <Button variant="ghost" size="sm">
                            <ArrowUpDown className="h-4 w-4" />
                          </Button>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        {/* Settings Tab */}
        <TabsContent value="settings" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center">
                <Settings className="h-5 w-5 mr-2" />
                CAT Tools Ayarları
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="space-y-4">
                <div className="flex items-center justify-between p-4 border rounded-lg">
                  <div>
                    <h3 className="font-medium">Otomatik Segment Eşleştirme</h3>
                    <p className="text-sm text-gray-500">
                      İçe aktarılan segmentleri mevcut çeviri belleği ile otomatik eşleştir
                    </p>
                  </div>
                  <Button variant="outline" size="sm">
                    Aktif
                  </Button>
                </div>
                
                <div className="flex items-center justify-between p-4 border rounded-lg">
                  <div>
                    <h3 className="font-medium">Fuzzy Match Eşiği</h3>
                    <p className="text-sm text-gray-500">
                      Benzerlik eşleştirmeleri için minimum yüzde (örn: %75)
                    </p>
                  </div>
                  <Input
                    type="number"
                    defaultValue="75"
                    className="w-20"
                    min="50"
                    max="100"
                  />
                </div>

                <div className="flex items-center justify-between p-4 border rounded-lg">
                  <div>
                    <h3 className="font-medium">Kalite Kontrol</h3>
                    <p className="text-sm text-gray-500">
                      İçe aktarılan çevirilerde kalite kontrolleri yap
                    </p>
                  </div>
                  <Button variant="outline" size="sm">
                    Aktif
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}