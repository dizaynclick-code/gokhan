import { useState, useEffect } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { useLocation } from "wouter";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Folder, Plus, Users, Calendar, Globe, Archive, CheckCircle, Clock } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { LANGUAGES } from "@/lib/constants";
import { useI18n } from "@/lib/i18n/context";

export default function Projects() {
  const [projectName, setProjectName] = useState("");
  const [projectDescription, setProjectDescription] = useState("");
  const [sourceLang, setSourceLang] = useState("en");
  const [targetLang, setTargetLang] = useState("tr");
  const [selectedTeam, setSelectedTeam] = useState("");
  const [isCreateDialogOpen, setIsCreateDialogOpen] = useState(false);
  const [statusFilter, setStatusFilter] = useState("all");
  
  const { t } = useI18n();
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [location] = useLocation();
  
  // Auto-open create dialog if coming from header button
  useEffect(() => {
    const urlParams = new URLSearchParams(window.location.search);
    if (urlParams.get('create') === 'true') {
      setIsCreateDialogOpen(true);
      // Clean up URL
      window.history.replaceState({}, '', '/projects');
    }
  }, []);

  const { data: projects = [], isLoading } = useQuery({
    queryKey: ["/api/projects"],
  });

  const { data: teams = [] } = useQuery({
    queryKey: ["/api/teams"],
  });

  const createProjectMutation = useMutation({
    mutationFn: async (data: { name: string; description?: string; sourceLang: string; targetLang: string; teamId?: string }) => {
      const response = await apiRequest("POST", "/api/projects", data);
      return response.json();
    },
    onSuccess: () => {
      setProjectName("");
      setProjectDescription("");
      setSelectedTeam("");
      setIsCreateDialogOpen(false);
      queryClient.invalidateQueries({ queryKey: ["/api/projects"] });
      toast({
        title: t('projects.projectCreatedSuccess'),
        description: t('projects.projectCreatedDescription'),
      });
    },
    onError: (error) => {
      toast({
        title: t('projects.failedToCreateProject'),
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const handleCreateProject = () => {
    if (!projectName.trim()) {
      toast({
        title: t('projects.pleaseEnterProjectName'),
        variant: "destructive",
      });
      return;
    }

    createProjectMutation.mutate({
      name: projectName.trim(),
      description: projectDescription.trim() || undefined,
      sourceLang,
      targetLang,
      teamId: selectedTeam || undefined,
    });
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'completed':
        return <CheckCircle className="h-4 w-4 text-emerald-500" />;
      case 'archived':
        return <Archive className="h-4 w-4 text-gray-500" />;
      default:
        return <Clock className="h-4 w-4 text-blue-500" />;
    }
  };

  const getStatusBadgeColor = (status: string) => {
    switch (status) {
      case 'completed':
        return 'bg-emerald-100 text-emerald-800 dark:bg-emerald-900/50 dark:text-emerald-200';
      case 'archived':
        return 'bg-gray-100 text-gray-800 dark:bg-gray-800 dark:text-gray-200';
      default:
        return 'bg-blue-100 text-blue-800 dark:bg-blue-900/50 dark:text-blue-200';
    }
  };

  const filteredProjects = (projects as any[]).filter((project: any) => {
    if (statusFilter === "all") return true;
    return project.status === statusFilter;
  });

  return (
    <div className="max-w-6xl mx-auto space-y-6">
      {/* Header with Create Project Button */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-gray-900 dark:text-white" data-testid="projects-page-title">
            {t('projects.title')}
          </h1>
          <p className="text-gray-500 dark:text-gray-400 mt-1">
            {t('projects.subtitle')}
          </p>
        </div>
        <Dialog open={isCreateDialogOpen} onOpenChange={setIsCreateDialogOpen}>
          <DialogTrigger asChild>
            <Button className="bg-blue-600 hover:bg-blue-700" data-testid="button-create-project">
              <Plus className="h-4 w-4 mr-2" />
              {t('projects.createProject')}
            </Button>
          </DialogTrigger>
          <DialogContent className="max-w-md">
            <DialogHeader>
              <DialogTitle data-testid="create-project-dialog-title">{t('projects.createNewProject')}</DialogTitle>
            </DialogHeader>
            <div className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                  {t('projects.projectName')}
                </label>
                <Input
                  value={projectName}
                  onChange={(e) => setProjectName(e.target.value)}
                  placeholder={t('projects.enterProjectName')}
                  data-testid="input-project-name"
                />
              </div>
              
              <div>
                <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                  {t('projects.description')}
                </label>
                <Textarea
                  value={projectDescription}
                  onChange={(e) => setProjectDescription(e.target.value)}
                  placeholder={t('projects.describeProject')}
                  className="h-20 resize-none"
                  data-testid="textarea-project-description"
                />
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                    {t('projects.sourceLanguage')}
                  </label>
                  <Select value={sourceLang} onValueChange={setSourceLang}>
                    <SelectTrigger data-testid="select-source-language">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      {LANGUAGES.map((lang) => (
                        <SelectItem key={lang.code} value={lang.code}>
                          {lang.flag} {lang.name}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                
                <div>
                  <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                    {t('projects.targetLanguage')}
                  </label>
                  <Select value={targetLang} onValueChange={setTargetLang}>
                    <SelectTrigger data-testid="select-target-language">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      {LANGUAGES.map((lang) => (
                        <SelectItem key={lang.code} value={lang.code}>
                          {lang.flag} {lang.name}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                  {t('projects.team')}
                </label>
                <Select value={selectedTeam} onValueChange={setSelectedTeam}>
                  <SelectTrigger data-testid="select-project-team">
                    <SelectValue placeholder={t('projects.selectTeam')} />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="">{t('projects.noTeam')}</SelectItem>
                    {(teams as any[]).map((team: any) => (
                      <SelectItem key={team.id} value={team.id}>
                        {team.name}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <div className="flex justify-end space-x-2">
                <Button
                  variant="outline"
                  onClick={() => setIsCreateDialogOpen(false)}
                  data-testid="button-cancel-create"
                >
                  {t('common.cancel')}
                </Button>
                <Button
                  onClick={handleCreateProject}
                  disabled={createProjectMutation.isPending}
                  data-testid="button-confirm-create"
                >
                  {createProjectMutation.isPending ? t('projects.creating') : t('projects.createProject')}
                </Button>
              </div>
            </div>
          </DialogContent>
        </Dialog>
      </div>

      {/* Filters */}
      <Card>
        <CardContent className="pt-6">
          <div className="flex items-center space-x-4">
            <span className="text-sm font-medium text-gray-700 dark:text-gray-300">{t('projects.filterByStatus')}</span>
            <Select value={statusFilter} onValueChange={setStatusFilter}>
              <SelectTrigger className="w-40" data-testid="select-status-filter">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">{t('projects.allProjects')}</SelectItem>
                <SelectItem value="active">{t('projects.active')}</SelectItem>
                <SelectItem value="completed">{t('projects.completed')}</SelectItem>
                <SelectItem value="archived">{t('projects.archived')}</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </CardContent>
      </Card>

      {/* Projects Grid */}
      {isLoading ? (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {[1, 2, 3].map((i) => (
            <div key={i} className="animate-pulse">
              <div className="h-48 bg-gray-200 dark:bg-gray-700 rounded-lg" />
            </div>
          ))}
        </div>
      ) : filteredProjects.length === 0 ? (
        <Card>
          <CardContent className="text-center py-12">
            <Folder className="h-16 w-16 mx-auto mb-4 text-gray-400" />
            <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-2">
              {statusFilter === "all" ? "No projects yet" : `No ${statusFilter} projects`}
            </h3>
            <p className="text-gray-500 dark:text-gray-400 mb-4" data-testid="no-projects-message">
              {statusFilter === "all" 
                ? "Create your first project to start organizing your translation work."
                : `No projects with status "${statusFilter}" found.`
              }
            </p>
            {statusFilter === "all" && (
              <Button
                onClick={() => setIsCreateDialogOpen(true)}
                className="bg-blue-600 hover:bg-blue-700"
                data-testid="button-create-first-project"
              >
                <Plus className="h-4 w-4 mr-2" />
                Create Your First Project
              </Button>
            )}
          </CardContent>
        </Card>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredProjects.map((project: any) => (
            <Card key={project.id} className="hover:shadow-lg transition-shadow cursor-pointer" data-testid={`project-card-${project.id}`}>
              <CardHeader className="pb-3">
                <div className="flex items-start justify-between">
                  <div className="flex items-center space-x-3">
                    <div className="w-10 h-10 bg-gradient-to-br from-emerald-500 to-blue-600 rounded-lg flex items-center justify-center">
                      <Folder className="h-5 w-5 text-white" />
                    </div>
                    <div>
                      <CardTitle className="text-lg" data-testid={`project-name-${project.id}`}>
                        {project.name}
                      </CardTitle>
                      <div className="flex items-center space-x-1 mt-1">
                        {getStatusIcon(project.status)}
                        <Badge variant="secondary" className={getStatusBadgeColor(project.status)} data-testid={`project-status-${project.id}`}>
                          {project.status}
                        </Badge>
                      </div>
                    </div>
                  </div>
                </div>
              </CardHeader>
              <CardContent className="space-y-4">
                {project.description && (
                  <p className="text-sm text-gray-600 dark:text-gray-400" data-testid={`project-description-${project.id}`}>
                    {project.description}
                  </p>
                )}
                
                <div className="space-y-2">
                  <div className="flex items-center space-x-2 text-sm">
                    <Globe className="h-4 w-4 text-gray-400" />
                    <span className="text-gray-600 dark:text-gray-400" data-testid={`project-languages-${project.id}`}>
                      {LANGUAGES.find(l => l.code === project.sourceLang)?.flag} {project.sourceLang.toUpperCase()} → {LANGUAGES.find(l => l.code === project.targetLang)?.flag} {project.targetLang.toUpperCase()}
                    </span>
                  </div>
                  
                  <div className="flex items-center space-x-2 text-sm">
                    <Calendar className="h-4 w-4 text-gray-400" />
                    <span className="text-gray-600 dark:text-gray-400" data-testid={`project-created-date-${project.id}`}>
                      Created {new Date(project.createdAt).toLocaleDateString()}
                    </span>
                  </div>

                  {project.teamId && (
                    <div className="flex items-center space-x-2 text-sm">
                      <Users className="h-4 w-4 text-gray-400" />
                      <span className="text-gray-600 dark:text-gray-400" data-testid={`project-team-${project.id}`}>
                        Team Project
                      </span>
                    </div>
                  )}
                </div>
                
                <div className="flex space-x-2 pt-2">
                  <Button
                    variant="outline"
                    size="sm"
                    className="flex-1"
                    data-testid={`button-open-project-${project.id}`}
                  >
                    Open Project
                  </Button>
                  <Button
                    variant="outline"
                    size="sm"
                    data-testid={`button-project-settings-${project.id}`}
                  >
                    Settings
                  </Button>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      )}
    </div>
  );
}
