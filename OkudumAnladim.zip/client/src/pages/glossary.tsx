import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Book, Plus, Trash2, Search } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { LANGUAGES } from "@/lib/constants";
import { useI18n } from "@/lib/i18n/context";

export default function Glossary() {
  const [sourceTerm, setSourceTerm] = useState("");
  const [targetTerm, setTargetTerm] = useState("");
  const [context, setContext] = useState("");
  const [sourceLang, setSourceLang] = useState("en");
  const [targetLang, setTargetLang] = useState("tr");
  const [searchTerm, setSearchTerm] = useState("");
  const [filterSourceLang, setFilterSourceLang] = useState("all");
  const [filterTargetLang, setFilterTargetLang] = useState("all");
  
  const { t } = useI18n();
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const { data: glossaryEntries = [], isLoading } = useQuery({
    queryKey: ["/api/glossary", { 
      sourceLang: filterSourceLang === "all" ? undefined : filterSourceLang,
      targetLang: filterTargetLang === "all" ? undefined : filterTargetLang
    }],
  });

  const addGlossaryMutation = useMutation({
    mutationFn: async (data: { sourceTerm: string; targetTerm: string; sourceLang: string; targetLang: string; context?: string }) => {
      const response = await apiRequest("POST", "/api/glossary", data);
      return response.json();
    },
    onSuccess: () => {
      setSourceTerm("");
      setTargetTerm("");
      setContext("");
      queryClient.invalidateQueries({ queryKey: ["/api/glossary"] });
      toast({
        title: t('glossary.entryAddedSuccess'),
        description: t('glossary.entryAddedDescription'),
      });
    },
    onError: (error) => {
      toast({
        title: t('glossary.failedToAdd'),
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const deleteGlossaryMutation = useMutation({
    mutationFn: async (id: string) => {
      await apiRequest("DELETE", `/api/glossary/${id}`, {});
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/glossary"] });
      toast({
        title: t('glossary.entryDeleted'),
        description: t('glossary.entryDeletedDescription'),
      });
    },
    onError: (error) => {
      toast({
        title: t('glossary.failedToDelete'),
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const handleAddEntry = () => {
    if (!sourceTerm.trim() || !targetTerm.trim()) {
      toast({
        title: t('glossary.pleaseEnterBothTerms'),
        variant: "destructive",
      });
      return;
    }

    addGlossaryMutation.mutate({
      sourceTerm: sourceTerm.trim(),
      targetTerm: targetTerm.trim(),
      sourceLang,
      targetLang,
      context: context.trim() || undefined,
    });
  };

  const handleDeleteEntry = (id: string) => {
    deleteGlossaryMutation.mutate(id);
  };

  const handleSwapLanguages = () => {
    const tempLang = sourceLang;
    setSourceLang(targetLang);
    setTargetLang(tempLang);
    
    const tempTerm = sourceTerm;
    setSourceTerm(targetTerm);
    setTargetTerm(tempTerm);
  };

  const filteredEntries = glossaryEntries.filter((entry: any) => {
    const matchesSearch = searchTerm === "" || 
      entry.sourceTerm.toLowerCase().includes(searchTerm.toLowerCase()) ||
      entry.targetTerm.toLowerCase().includes(searchTerm.toLowerCase()) ||
      (entry.context && entry.context.toLowerCase().includes(searchTerm.toLowerCase()));
    
    return matchesSearch;
  });

  return (
    <div className="max-w-6xl mx-auto space-y-6">
      {/* Add New Entry */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center" data-testid="add-entry-title">
            <Plus className="h-5 w-5 mr-2" />
            {t('glossary.addNewEntry')}
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          {/* Language Selection */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 items-center">
            <div>
              <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                {t('glossary.sourceLanguage')}
              </label>
              <Select value={sourceLang} onValueChange={setSourceLang}>
                <SelectTrigger data-testid="select-source-language">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {LANGUAGES.map((lang) => (
                    <SelectItem key={lang.code} value={lang.code}>
                      {lang.flag} {lang.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            
            <div className="flex justify-center">
              <Button
                variant="outline"
                size="icon"
                onClick={handleSwapLanguages}
                className="rounded-full"
                data-testid="button-swap-languages"
              >
                ⇄
              </Button>
            </div>
            
            <div>
              <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                {t('glossary.targetLanguage')}
              </label>
              <Select value={targetLang} onValueChange={setTargetLang}>
                <SelectTrigger data-testid="select-target-language">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {LANGUAGES.map((lang) => (
                    <SelectItem key={lang.code} value={lang.code}>
                      {lang.flag} {lang.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>

          {/* Term Input */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                {t('glossary.sourceTerm')}
              </label>
              <Input
                value={sourceTerm}
                onChange={(e) => setSourceTerm(e.target.value)}
                placeholder={t('glossary.enterSourceTerm')}
                data-testid="input-source-term"
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                {t('glossary.targetTerm')}
              </label>
              <Input
                value={targetTerm}
                onChange={(e) => setTargetTerm(e.target.value)}
                placeholder={t('glossary.enterTargetTerm')}
                data-testid="input-target-term"
              />
            </div>
          </div>

          {/* Context */}
          <div>
            <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
              {t('glossary.context')}
            </label>
            <Textarea
              value={context}
              onChange={(e) => setContext(e.target.value)}
              placeholder={t('glossary.contextPlaceholder')}
              className="h-20 resize-none"
              data-testid="textarea-context"
            />
          </div>

          {/* Add Button */}
          <div className="flex justify-end">
            <Button
              onClick={handleAddEntry}
              disabled={addGlossaryMutation.isPending || !sourceTerm.trim() || !targetTerm.trim()}
              className="bg-blue-600 hover:bg-blue-700"
              data-testid="button-add-entry"
            >
              {addGlossaryMutation.isPending ? (
                <div className="animate-pulse">{t('glossary.adding')}</div>
              ) : (
                <>
                  <Plus className="h-4 w-4 mr-2" />
                  {t('glossary.addEntry')}
                </>
              )}
            </Button>
          </div>
        </CardContent>
      </Card>

      {/* Search and Filter */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center" data-testid="search-filter-title">
            <Search className="h-5 w-5 mr-2" />
            {t('glossary.searchFilter')}
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
            <div className="md:col-span-2">
              <Input
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                placeholder={t('glossary.searchPlaceholder')}
                className="w-full"
                data-testid="input-search"
              />
            </div>
            <div>
              <Select value={filterSourceLang} onValueChange={setFilterSourceLang}>
                <SelectTrigger data-testid="select-filter-source">
                  <SelectValue placeholder={t('glossary.sourceLanguage')} />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">{t('glossary.allSourceLanguages')}</SelectItem>
                  {LANGUAGES.map((lang) => (
                    <SelectItem key={lang.code} value={lang.code}>
                      {lang.flag} {lang.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div>
              <Select value={filterTargetLang} onValueChange={setFilterTargetLang}>
                <SelectTrigger data-testid="select-filter-target">
                  <SelectValue placeholder={t('glossary.targetLanguage')} />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">{t('glossary.allTargetLanguages')}</SelectItem>
                  {LANGUAGES.map((lang) => (
                    <SelectItem key={lang.code} value={lang.code}>
                      {lang.flag} {lang.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Glossary Entries */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center justify-between" data-testid="glossary-entries-title">
            <div className="flex items-center">
              <Book className="h-5 w-5 mr-2" />
{t('glossary.glossaryEntries')}
            </div>
            <Badge variant="secondary" data-testid="entries-count">
{filteredEntries.length} {t('glossary.entries')}
            </Badge>
          </CardTitle>
        </CardHeader>
        <CardContent>
          {isLoading ? (
            <div className="animate-pulse space-y-4">
              {[1, 2, 3].map((i) => (
                <div key={i} className="h-16 bg-gray-200 dark:bg-gray-700 rounded-lg" />
              ))}
            </div>
          ) : filteredEntries.length === 0 ? (
            <div className="text-center py-12 text-gray-500 dark:text-gray-400">
              <Book className="h-16 w-16 mx-auto mb-4 opacity-50" />
              <h3 className="text-lg font-semibold mb-2">No glossary entries found</h3>
              <p data-testid="no-entries-message">
                {searchTerm ? "Try adjusting your search terms or filters" : "Add your first glossary entry to get started"}
              </p>
            </div>
          ) : (
            <div className="overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Source Term</TableHead>
                    <TableHead>Target Term</TableHead>
                    <TableHead>Languages</TableHead>
                    <TableHead>Context</TableHead>
                    <TableHead>Created</TableHead>
                    <TableHead className="w-20">Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {filteredEntries.map((entry: any) => (
                    <TableRow key={entry.id} data-testid={`glossary-row-${entry.id}`}>
                      <TableCell className="font-medium" data-testid={`source-term-${entry.id}`}>
                        {entry.sourceTerm}
                      </TableCell>
                      <TableCell data-testid={`target-term-${entry.id}`}>
                        {entry.targetTerm}
                      </TableCell>
                      <TableCell>
                        <div className="flex items-center space-x-2">
                          <Badge variant="outline" className="text-xs" data-testid={`lang-pair-${entry.id}`}>
                            {entry.sourceLang.toUpperCase()} → {entry.targetLang.toUpperCase()}
                          </Badge>
                        </div>
                      </TableCell>
                      <TableCell data-testid={`context-${entry.id}`}>
                        {entry.context ? (
                          <span className="text-sm text-gray-600 dark:text-gray-400">
                            {entry.context.length > 50 ? `${entry.context.substring(0, 50)}...` : entry.context}
                          </span>
                        ) : (
                          <span className="text-sm text-gray-400 italic">No context</span>
                        )}
                      </TableCell>
                      <TableCell className="text-sm text-gray-500 dark:text-gray-400" data-testid={`created-date-${entry.id}`}>
                        {new Date(entry.createdAt).toLocaleDateString()}
                      </TableCell>
                      <TableCell>
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => handleDeleteEntry(entry.id)}
                          disabled={deleteGlossaryMutation.isPending}
                          className="text-red-600 hover:text-red-700 hover:bg-red-50 dark:hover:bg-red-900/20"
                          data-testid={`button-delete-${entry.id}`}
                        >
                          <Trash2 className="h-4 w-4" />
                        </Button>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
