import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Database, Plus, Trash2, Search, ArrowRight } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { LANGUAGES } from "@/lib/constants";
import { useI18n } from "@/lib/i18n/context";

export default function TranslationMemory() {
  const [sourceSegment, setSourceSegment] = useState("");
  const [targetSegment, setTargetSegment] = useState("");
  const [context, setContext] = useState("");
  const [sourceLang, setSourceLang] = useState("en");
  const [targetLang, setTargetLang] = useState("tr");
  const [searchTerm, setSearchTerm] = useState("");
  const [filterSourceLang, setFilterSourceLang] = useState("all");
  const [filterTargetLang, setFilterTargetLang] = useState("all");
  
  const { t } = useI18n();
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const { data: memoryEntries = [], isLoading } = useQuery({
    queryKey: ["/api/translation-memory", { 
      sourceLang: filterSourceLang === "all" ? undefined : filterSourceLang,
      targetLang: filterTargetLang === "all" ? undefined : filterTargetLang,
      search: searchTerm || undefined
    }],
  });

  const addMemoryMutation = useMutation({
    mutationFn: async (data: { sourceSegment: string; targetSegment: string; sourceLang: string; targetLang: string; context?: string; matchScore: number }) => {
      const response = await apiRequest("POST", "/api/translation-memory", data);
      return response.json();
    },
    onSuccess: () => {
      setSourceSegment("");
      setTargetSegment("");
      setContext("");
      queryClient.invalidateQueries({ queryKey: ["/api/translation-memory"] });
      toast({
        title: t('memory.entryAddedSuccess'),
        description: t('memory.entryAddedDescription'),
      });
    },
    onError: (error) => {
      toast({
        title: t('memory.failedToAdd'),
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const deleteMemoryMutation = useMutation({
    mutationFn: async (id: string) => {
      await apiRequest("DELETE", `/api/translation-memory/${id}`, {});
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/translation-memory"] });
      toast({
        title: t('memory.entryDeleted'),
        description: t('memory.entryDeletedDescription'),
      });
    },
    onError: (error) => {
      toast({
        title: t('memory.failedToDelete'),
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const handleAddEntry = () => {
    if (!sourceSegment.trim() || !targetSegment.trim()) {
      toast({
        title: t('memory.pleaseEnterBothSegments'),
        variant: "destructive",
      });
      return;
    }

    addMemoryMutation.mutate({
      sourceSegment: sourceSegment.trim(),
      targetSegment: targetSegment.trim(),
      sourceLang,
      targetLang,
      context: context.trim() || undefined,
      matchScore: 100, // New entries default to 100% match
    });
  };

  const handleDeleteEntry = (id: string) => {
    deleteMemoryMutation.mutate(id);
  };

  const handleSwapLanguages = () => {
    const tempLang = sourceLang;
    setSourceLang(targetLang);
    setTargetLang(tempLang);
    
    const tempSegment = sourceSegment;
    setSourceSegment(targetSegment);
    setTargetSegment(tempSegment);
  };

  const getMatchScoreColor = (score: number) => {
    if (score >= 95) return "bg-emerald-100 text-emerald-800 dark:bg-emerald-900/50 dark:text-emerald-200";
    if (score >= 80) return "bg-yellow-100 text-yellow-800 dark:bg-yellow-900/50 dark:text-yellow-200";
    if (score >= 60) return "bg-orange-100 text-orange-800 dark:bg-orange-900/50 dark:text-orange-200";
    return "bg-red-100 text-red-800 dark:bg-red-900/50 dark:text-red-200";
  };

  return (
    <div className="max-w-6xl mx-auto space-y-6">
      {/* Add New Entry */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center" data-testid="add-entry-title">
            <Plus className="h-5 w-5 mr-2" />
            {t('memory.addNewEntry')}
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          {/* Language Selection */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 items-center">
            <div>
              <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                {t('memory.sourceLanguage')}
              </label>
              <Select value={sourceLang} onValueChange={setSourceLang}>
                <SelectTrigger data-testid="select-source-language">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {LANGUAGES.map((lang) => (
                    <SelectItem key={lang.code} value={lang.code}>
                      {lang.flag} {lang.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            
            <div className="flex justify-center">
              <Button
                variant="outline"
                size="icon"
                onClick={handleSwapLanguages}
                className="rounded-full"
                data-testid="button-swap-languages"
              >
                ⇄
              </Button>
            </div>
            
            <div>
              <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                {t('memory.targetLanguage')}
              </label>
              <Select value={targetLang} onValueChange={setTargetLang}>
                <SelectTrigger data-testid="select-target-language">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {LANGUAGES.map((lang) => (
                    <SelectItem key={lang.code} value={lang.code}>
                      {lang.flag} {lang.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>

          {/* Segment Input */}
          <div className="space-y-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                {t('memory.sourceSegment')}
              </label>
              <Textarea
                value={sourceSegment}
                onChange={(e) => setSourceSegment(e.target.value)}
                placeholder={t('memory.enterSourceSegment')}
                className="h-24 resize-none"
                data-testid="textarea-source-segment"
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                {t('memory.targetSegment')}
              </label>
              <Textarea
                value={targetSegment}
                onChange={(e) => setTargetSegment(e.target.value)}
                placeholder={t('memory.enterTargetSegment')}
                className="h-24 resize-none"
                data-testid="textarea-target-segment"
              />
            </div>
          </div>

          {/* Context */}
          <div>
            <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
              {t('memory.context')}
            </label>
            <Textarea
              value={context}
              onChange={(e) => setContext(e.target.value)}
              placeholder={t('memory.contextPlaceholder')}
              className="h-20 resize-none"
              data-testid="textarea-context"
            />
          </div>

          {/* Add Button */}
          <div className="flex justify-end">
            <Button
              onClick={handleAddEntry}
              disabled={addMemoryMutation.isPending || !sourceSegment.trim() || !targetSegment.trim()}
              className="bg-blue-600 hover:bg-blue-700"
              data-testid="button-add-entry"
            >
              {addMemoryMutation.isPending ? (
                <div className="animate-pulse">{t('memory.adding')}</div>
              ) : (
                <>
                  <Plus className="h-4 w-4 mr-2" />
                  {t('memory.addEntry')}
                </>
              )}
            </Button>
          </div>
        </CardContent>
      </Card>

      {/* Search and Filter */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center" data-testid="search-filter-title">
            <Search className="h-5 w-5 mr-2" />
            {t('memory.searchFilter')}
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
            <div className="md:col-span-2">
              <Input
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                placeholder={t('memory.searchPlaceholder')}
                className="w-full"
                data-testid="input-search"
              />
            </div>
            <div>
              <Select value={filterSourceLang} onValueChange={setFilterSourceLang}>
                <SelectTrigger data-testid="select-filter-source">
                  <SelectValue placeholder={t('memory.sourceLanguage')} />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">{t('memory.allSourceLanguages')}</SelectItem>
                  {LANGUAGES.map((lang) => (
                    <SelectItem key={lang.code} value={lang.code}>
                      {lang.flag} {lang.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div>
              <Select value={filterTargetLang} onValueChange={setFilterTargetLang}>
                <SelectTrigger data-testid="select-filter-target">
                  <SelectValue placeholder={t('memory.targetLanguage')} />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">{t('memory.allTargetLanguages')}</SelectItem>
                  {LANGUAGES.map((lang) => (
                    <SelectItem key={lang.code} value={lang.code}>
                      {lang.flag} {lang.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Translation Memory Entries */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center justify-between" data-testid="memory-entries-title">
            <div className="flex items-center">
              <Database className="h-5 w-5 mr-2" />
{t('memory.translationMemory')}
            </div>
            <Badge variant="secondary" data-testid="entries-count">
{memoryEntries.length} {t('memory.segments')}
            </Badge>
          </CardTitle>
        </CardHeader>
        <CardContent>
          {isLoading ? (
            <div className="animate-pulse space-y-4">
              {[1, 2, 3].map((i) => (
                <div key={i} className="h-20 bg-gray-200 dark:bg-gray-700 rounded-lg" />
              ))}
            </div>
          ) : memoryEntries.length === 0 ? (
            <div className="text-center py-12 text-gray-500 dark:text-gray-400">
              <Database className="h-16 w-16 mx-auto mb-4 opacity-50" />
              <h3 className="text-lg font-semibold mb-2">{t('memory.noEntriesFound')}</h3>
              <p data-testid="no-entries-message">
                {searchTerm ? t('memory.adjustSearch') : t('memory.addFirstEntry')}
              </p>
            </div>
          ) : (
            <div className="space-y-4">
              {memoryEntries.map((entry: any) => (
                <div
                  key={entry.id}
                  className="p-4 border border-gray-200 dark:border-gray-700 rounded-lg hover:bg-gray-50 dark:hover:bg-gray-800 transition-colors"
                  data-testid={`memory-entry-${entry.id}`}
                >
                  <div className="flex items-start justify-between mb-3">
                    <div className="flex items-center space-x-3">
                      <Badge 
                        variant="secondary" 
                        className={getMatchScoreColor(entry.matchScore)}
                        data-testid={`match-score-${entry.id}`}
                      >
{entry.matchScore}% {t('memory.match')}
                      </Badge>
                      <Badge variant="outline" className="text-xs" data-testid={`lang-pair-${entry.id}`}>
                        {entry.sourceLang.toUpperCase()} → {entry.targetLang.toUpperCase()}
                      </Badge>
                      <span className="text-xs text-gray-500 dark:text-gray-400" data-testid={`updated-date-${entry.id}`}>
{t('memory.updated')} {new Date(entry.updatedAt).toLocaleDateString()}
                      </span>
                    </div>
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => handleDeleteEntry(entry.id)}
                      disabled={deleteMemoryMutation.isPending}
                      className="text-red-600 hover:text-red-700 hover:bg-red-50 dark:hover:bg-red-900/20"
                      data-testid={`button-delete-${entry.id}`}
                    >
                      <Trash2 className="h-4 w-4" />
                    </Button>
                  </div>
                  
                  <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
                    <div>
                      <h4 className="text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">{t('memory.sourceSegment')}</h4>
                      <p className="text-sm text-gray-900 dark:text-white bg-gray-50 dark:bg-gray-900 p-3 rounded border" data-testid={`source-segment-${entry.id}`}>
                        {entry.sourceSegment}
                      </p>
                    </div>
                    <div>
                      <h4 className="text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">{t('memory.targetSegment')}</h4>
                      <p className="text-sm text-gray-900 dark:text-white bg-gray-50 dark:bg-gray-900 p-3 rounded border" data-testid={`target-segment-${entry.id}`}>
                        {entry.targetSegment}
                      </p>
                    </div>
                  </div>
                  
                  {entry.context && (
                    <div className="mt-3">
                      <h4 className="text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">{t('memory.context')}</h4>
                      <p className="text-sm text-gray-600 dark:text-gray-400 italic" data-testid={`context-${entry.id}`}>
                        {entry.context}
                      </p>
                    </div>
                  )}
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
