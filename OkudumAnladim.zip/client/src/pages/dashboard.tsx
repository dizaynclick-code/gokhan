import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { useI18n } from "@/lib/i18n/context";
import { LanguageSelector } from "@/components/translation/language-selector";
import { TranslationInterface } from "@/components/translation/translation-interface";
import { MemoryMatches } from "@/components/translation/memory-matches";
import { GlossaryTerms } from "@/components/translation/glossary-terms";
import { QuickAccess } from "@/components/translation/quick-access";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Languages, Clock, TrendingUp, Globe } from "lucide-react";

export default function Dashboard() {
  const { t } = useI18n();
  const [sourceLang, setSourceLang] = useState("en");
  const [targetLang, setTargetLang] = useState("tr");
  const [model, setModel] = useState("gpt-4o");

  const { data: recentTranslations = [] } = useQuery({
    queryKey: ["/api/translations", { limit: 10 }],
  });

  const handleSwapLanguages = () => {
    const temp = sourceLang;
    setSourceLang(targetLang);
    setTargetLang(temp);
  };

  const formatTimeAgo = (date: string) => {
    const now = new Date();
    const past = new Date(date);
    const diffInHours = Math.floor((now.getTime() - past.getTime()) / (1000 * 60 * 60));
    
    if (diffInHours < 1) return t('dashboard.justNow');
    if (diffInHours < 24) return `${diffInHours} ${t('dashboard.hoursAgo')}`;
    return `${Math.floor(diffInHours / 24)} ${t('dashboard.daysAgo')}`;
  };

  const stats = [
    {
      title: t('dashboard.totalTranslations'),
      value: "1,247",
      icon: Languages,
      color: "bg-blue-100 text-blue-600 dark:bg-blue-900/50 dark:text-blue-400",
    },
    {
      title: t('dashboard.timeSaved'),
      value: "24.6h",
      icon: Clock,
      color: "bg-purple-100 text-purple-600 dark:bg-purple-900/50 dark:text-purple-400",
    },
    {
      title: t('dashboard.accuracyRate'),
      value: "98.4%",
      icon: TrendingUp,
      color: "bg-emerald-100 text-emerald-600 dark:bg-emerald-900/50 dark:text-emerald-400",
    },
    {
      title: t('dashboard.languages'),
      value: "15",
      icon: Globe,
      color: "bg-yellow-100 text-yellow-600 dark:bg-yellow-900/50 dark:text-yellow-400",
    },
  ];

  return (
    <div className="max-w-6xl mx-auto space-y-6">
      {/* Language Selection */}
      <LanguageSelector
        sourceLang={sourceLang}
        targetLang={targetLang}
        model={model}
        onSourceLangChange={setSourceLang}
        onTargetLangChange={setTargetLang}
        onModelChange={setModel}
        onSwapLanguages={handleSwapLanguages}
      />

      {/* Translation Interface */}
      <TranslationInterface
        sourceLang={sourceLang}
        targetLang={targetLang}
        model={model}
      />

      {/* Additional Features Panel */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <MemoryMatches sourceLang={sourceLang} targetLang={targetLang} />
        <GlossaryTerms sourceLang={sourceLang} targetLang={targetLang} />
        
        {/* Translation History */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center" data-testid="translation-history-title">
              <Clock className="h-5 w-5 text-gray-600 mr-2" />
              {t('dashboard.recentHistory')}
            </CardTitle>
          </CardHeader>
          <CardContent>
            {(recentTranslations as any[]).length === 0 ? (
              <div className="text-center py-8 text-gray-500 dark:text-gray-400">
                <Clock className="h-12 w-12 mx-auto mb-4 opacity-50" />
                <p data-testid="no-history-message">No translation history yet</p>
              </div>
            ) : (
              <div className="space-y-3">
                {(recentTranslations as any[]).slice(0, 3).map((translation: any) => (
                  <div
                    key={translation.id}
                    className="p-3 hover:bg-gray-50 dark:hover:bg-gray-800 border border-gray-200 dark:border-gray-700 rounded-lg cursor-pointer transition-colors"
                    data-testid={`history-item-${translation.id}`}
                  >
                    <div className="flex items-center justify-between mb-1">
                      <span className="text-xs text-gray-500 dark:text-gray-400" data-testid={`history-time-${translation.id}`}>
                        {formatTimeAgo(translation.createdAt)}
                      </span>
                      <Badge variant="secondary" className="text-xs" data-testid={`history-langs-${translation.id}`}>
                        {translation.sourceLang.toUpperCase()} → {translation.targetLang.toUpperCase()}
                      </Badge>
                    </div>
                    <p className="text-sm text-gray-900 dark:text-white truncate" data-testid={`history-text-${translation.id}`}>
                      {translation.sourceText}
                    </p>
                  </div>
                ))}
              </div>
            )}
          </CardContent>
        </Card>
      </div>

      {/* Quick Access Features */}
      <QuickAccess />

      {/* Stats Overview */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        {stats.map((stat) => {
          const Icon = stat.icon;
          return (
            <Card key={stat.title}>
              <CardContent className="p-6">
                <div className="flex items-center">
                  <div className="flex-shrink-0">
                    <div className={`w-12 h-12 ${stat.color} rounded-lg flex items-center justify-center`}>
                      <Icon className="h-6 w-6" />
                    </div>
                  </div>
                  <div className="ml-4">
                    <p className="text-2xl font-bold text-gray-900 dark:text-white" data-testid={`stat-value-${stat.title.toLowerCase().replace(/\s+/g, '-')}`}>
                      {stat.value}
                    </p>
                    <p className="text-sm text-gray-600 dark:text-gray-400" data-testid={`stat-title-${stat.title.toLowerCase().replace(/\s+/g, '-')}`}>
                      {stat.title}
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>
          );
        })}
      </div>
    </div>
  );
}
