import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { 
  ArrowRight, 
  Languages, 
  FileText, 
  Mic, 
  Zap, 
  Globe, 
  Users, 
  BookOpen,
  Star,
  CheckCircle,
  Sparkles,
  LogOut,
  User
} from "lucide-react";
import { useI18n } from "@/lib/i18n/context";
import { useAuth } from "@/lib/auth/context";
import { LanguageSelector } from "@/components/LanguageSelector";
import { LoginModal } from "@/components/auth/LoginModal";
import { RegisterModal } from "@/components/auth/RegisterModal";
import { ForgotPasswordModal } from "@/components/auth/ForgotPasswordModal";

export default function Landing() {
  const { t } = useI18n();
  const { user, isAuthenticated, logout, isLoading } = useAuth();
  const [loginModalOpen, setLoginModalOpen] = useState(false);
  const [registerModalOpen, setRegisterModalOpen] = useState(false);
  const [forgotPasswordModalOpen, setForgotPasswordModalOpen] = useState(false);

  const handleLogout = async () => {
    await logout();
  };

  const features = [
    {
      icon: Languages,
      title: t('landing.featureAiTitle'),
      description: t('landing.featureAiDescription'),
      color: "bg-blue-500"
    },
    {
      icon: FileText,
      title: t('landing.featureDocumentTitle'),
      description: t('landing.featureDocumentDescription'),
      color: "bg-purple-500"
    },
    {
      icon: Mic,
      title: t('landing.featureAudioTitle'),
      description: t('landing.featureAudioDescription'),
      color: "bg-emerald-500"
    },
    {
      icon: Globe,
      title: t('landing.featureLanguagesTitle'),
      description: t('landing.featureLanguagesDescription'),
      color: "bg-orange-500"
    },
    {
      icon: Users,
      title: t('landing.featureTeamTitle'),
      description: t('landing.featureTeamDescription'),
      color: "bg-pink-500"
    },
    {
      icon: BookOpen,
      title: t('landing.featureLearningTitle'),
      description: t('landing.featureLearningDescription'),
      color: "bg-teal-500"
    }
  ];

  const stats = [
    { value: "1M+", label: t('landing.statsTranslations') },
    { value: "15+", label: t('landing.statsLanguages') },
    { value: "10K+", label: t('landing.statsUsers') },
    { value: "99.9%", label: t('landing.statsUptime') }
  ];

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 via-blue-50 to-indigo-100 dark:from-gray-900 dark:via-blue-900/20 dark:to-indigo-900/20">
      {/* Header */}
      <header className="relative z-10 bg-white/80 dark:bg-gray-900/80 backdrop-blur-md border-b border-gray-200 dark:border-gray-700">
        <div className="max-w-7xl mx-auto px-6 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-3">
              <div className="w-10 h-10 gradient-primary rounded-xl flex items-center justify-center">
                <Languages className="text-white text-lg" />
              </div>
              <div>
                <h1 className="text-2xl font-bold bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent">
                  LinguaFlow
                </h1>
                <p className="text-xs text-gray-500 dark:text-gray-400">
                  {t('landing.platformSubtitle')}
                </p>
              </div>
            </div>
            
            <div className="flex items-center space-x-4">
              <LanguageSelector />
              {isLoading ? (
                <div className="w-24 h-10 bg-gray-200 animate-pulse rounded"></div>
              ) : isAuthenticated && user ? (
                <div className="flex items-center space-x-3">
                  <div className="flex items-center space-x-2 px-3 py-2 bg-white/10 rounded-lg backdrop-blur-sm">
                    <User className="h-4 w-4 text-gray-600" />
                    <span className="text-sm text-gray-700">{user.username}</span>
                  </div>
                  <Button 
                    onClick={() => window.location.href = '/dashboard'} 
                    className="bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700 text-white"
                    data-testid="button-dashboard"
                  >
                    Dashboard
                    <ArrowRight className="ml-2 h-4 w-4" />
                  </Button>
                  <Button 
                    onClick={handleLogout}
                    variant="outline"
                    className="border-gray-300 hover:bg-gray-50"
                    data-testid="button-logout"
                  >
                    <LogOut className="h-4 w-4" />
                  </Button>
                </div>
              ) : (
                <div className="flex items-center space-x-2">
                  <Button 
                    onClick={() => setLoginModalOpen(true)}
                    variant="outline"
                    className="border-gray-300 hover:bg-gray-50"
                    data-testid="button-login"
                  >
                    {t('auth.login')}
                  </Button>
                  <Button 
                    onClick={() => setRegisterModalOpen(true)}
                    className="bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700 text-white"
                    data-testid="button-register"
                  >
                    {t('auth.register')}
                    <ArrowRight className="ml-2 h-4 w-4" />
                  </Button>
                </div>
              )}
            </div>
          </div>
        </div>
      </header>

      {/* Hero Section */}
      <section className="relative py-20 px-6">
        <div className="max-w-7xl mx-auto text-center">
          <div className="relative">
            <div className="absolute inset-0 bg-gradient-to-r from-blue-600/20 to-purple-600/20 blur-3xl rounded-full transform -rotate-12"></div>
            <div className="relative">
              <Badge className="mb-6 bg-blue-100 text-blue-800 dark:bg-blue-900/50 dark:text-blue-200" variant="secondary">
                <Sparkles className="w-3 h-3 mr-1" />
                {t('landing.aiPlatformBadge')}
              </Badge>
              
              <h1 className="text-5xl md:text-7xl font-bold mb-6 bg-gradient-to-r from-gray-900 via-blue-800 to-purple-800 dark:from-white dark:via-blue-200 dark:to-purple-200 bg-clip-text text-transparent leading-tight">
                {t('landing.heroTitle')}
                <br />
                <span className="bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent">
                  {t('landing.heroTitleAccent')}
                </span>
              </h1>
              
              <p className="text-xl md:text-2xl text-gray-600 dark:text-gray-300 mb-8 max-w-3xl mx-auto leading-relaxed">
                {t('landing.heroDescription')}
              </p>
              
              <div className="flex flex-col sm:flex-row gap-4 justify-center items-center mb-12">
                {isAuthenticated ? (
                  <>
                    <Button 
                      size="lg" 
                      className="bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700 text-white px-8 py-4 text-lg"
                      onClick={() => window.location.href = '/dashboard'}
                      data-testid="button-start-translating"
                    >
                      {t('landing.startTranslating')}
                      <ArrowRight className="ml-2 h-5 w-5" />
                    </Button>
                    <Button 
                      size="lg" 
                      variant="outline" 
                      className="px-8 py-4 text-lg border-2"
                      onClick={() => window.location.href = '/projects'}
                      data-testid="button-view-projects"
                    >
                      {t('landing.myProjects')}
                    </Button>
                  </>
                ) : (
                  <>
                    <Button 
                      size="lg" 
                      className="bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700 text-white px-8 py-4 text-lg"
                      onClick={() => setRegisterModalOpen(true)}
                      data-testid="button-get-started"
                    >
                      {t('landing.getStarted')}
                      <ArrowRight className="ml-2 h-5 w-5" />
                    </Button>
                    <Button 
                      size="lg" 
                      variant="outline" 
                      className="px-8 py-4 text-lg border-2"
                      onClick={() => setLoginModalOpen(true)}
                      data-testid="button-demo"
                    >
                      {t('landing.viewDemo')}
                    </Button>
                  </>
                )}
              </div>
            </div>
          </div>

          {/* Stats */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-8 max-w-2xl mx-auto">
            {stats.map((stat, index) => (
              <div key={index} className="text-center">
                <div className="text-3xl md:text-4xl font-bold bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent">
                  {stat.value}
                </div>
                <div className="text-gray-600 dark:text-gray-400 text-sm mt-1">
                  {stat.label}
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="py-20 px-6 bg-white/50 dark:bg-gray-800/50">
        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-16">
            <Badge className="mb-4 bg-purple-100 text-purple-800 dark:bg-purple-900/50 dark:text-purple-200" variant="secondary">
              {t('landing.featuresBadge')}
            </Badge>
            <h2 className="text-4xl md:text-5xl font-bold mb-6 bg-gradient-to-r from-gray-900 to-gray-700 dark:from-white dark:to-gray-200 bg-clip-text text-transparent">
              {t('landing.featuresTitle')}
            </h2>
            <p className="text-xl text-gray-600 dark:text-gray-300 max-w-2xl mx-auto">
              {t('landing.featuresDescription')}
            </p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            {features.map((feature, index) => {
              const Icon = feature.icon;
              return (
                <Card key={index} className="group hover:shadow-xl transition-all duration-300 border-0 bg-white/80 dark:bg-gray-800/80 backdrop-blur-sm hover:scale-105">
                  <CardContent className="p-8">
                    <div className={`w-14 h-14 ${feature.color} rounded-2xl flex items-center justify-center mb-6 group-hover:scale-110 transition-transform duration-300`}>
                      <Icon className="h-7 w-7 text-white" />
                    </div>
                    <h3 className="text-xl font-semibold mb-3 text-gray-900 dark:text-white">
                      {feature.title}
                    </h3>
                    <p className="text-gray-600 dark:text-gray-300 leading-relaxed">
                      {feature.description}
                    </p>
                  </CardContent>
                </Card>
              );
            })}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 px-6">
        <div className="max-w-4xl mx-auto text-center">
          <div className="relative">
            <div className="absolute inset-0 bg-gradient-to-r from-blue-600/10 to-purple-600/10 blur-3xl rounded-full"></div>
            <Card className="relative border-0 bg-gradient-to-r from-blue-600 to-purple-600 text-white overflow-hidden">
              <CardContent className="p-12">
                <div className="absolute top-0 right-0 w-32 h-32 bg-white/10 rounded-full -mr-16 -mt-16"></div>
                <div className="absolute bottom-0 left-0 w-24 h-24 bg-white/10 rounded-full -ml-12 -mb-12"></div>
                <div className="relative z-10">
                  <h2 className="text-3xl md:text-4xl font-bold mb-4">
                    {t('landing.ctaTitle')}
                  </h2>
                  <p className="text-xl mb-8 text-blue-100">
                    {t('landing.ctaDescription')}
                  </p>
                  <div className="flex flex-col sm:flex-row gap-4 justify-center">
                    {isAuthenticated ? (
                      <>
                        <Button 
                          size="lg" 
                          className="bg-white text-blue-600 hover:bg-gray-100 px-8 py-4 text-lg font-semibold"
                          onClick={() => window.location.href = '/dashboard'}
                          data-testid="button-dashboard-cta"
                        >
                          {t('landing.goToDashboard')}
                          <Zap className="ml-2 h-5 w-5" />
                        </Button>
                        <Button 
                          size="lg" 
                          variant="outline" 
                          className="border-white text-white hover:bg-white/10 px-8 py-4 text-lg"
                          onClick={() => window.location.href = '/learn'}
                          data-testid="button-learn-more"
                        >
                          {t('landing.learnMore')}
                        </Button>
                      </>
                    ) : (
                      <>
                        <Button 
                          size="lg" 
                          className="bg-white text-blue-600 hover:bg-gray-100 px-8 py-4 text-lg font-semibold"
                          onClick={() => setRegisterModalOpen(true)}
                          data-testid="button-free-trial"
                        >
                          {t('landing.freeTrial')}
                          <Zap className="ml-2 h-5 w-5" />
                        </Button>
                        <Button 
                          size="lg" 
                          variant="outline" 
                          className="border-white bg-white/10 text-white hover:bg-white hover:text-blue-600 px-8 py-4 text-lg backdrop-blur-sm"
                          onClick={() => setLoginModalOpen(true)}
                          data-testid="button-learn-more-cta"
                        >
                          {t('landing.learnMore')}
                        </Button>
                      </>
                    )}
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="py-12 px-6 bg-gray-900 dark:bg-gray-950 text-white">
        <div className="max-w-7xl mx-auto">
          <div className="flex flex-col md:flex-row items-center justify-between">
            <div className="flex items-center space-x-3 mb-4 md:mb-0">
              <div className="w-8 h-8 gradient-primary rounded-lg flex items-center justify-center">
                <Languages className="text-white text-sm" />
              </div>
              <span className="text-lg font-bold">LinguaFlow</span>
            </div>
            
            <div className="flex items-center space-x-6 text-sm text-gray-400">
              <span>{t('landing.copyright')}</span>
              <div className="flex items-center space-x-2">
                <CheckCircle className="h-4 w-4 text-emerald-500" />
                <span>{t('landing.enterpriseReady')}</span>
              </div>
            </div>
          </div>
        </div>
      </footer>

      {/* Authentication Modals */}
      <LoginModal 
        open={loginModalOpen} 
        onOpenChange={setLoginModalOpen}
        onSwitchToRegister={() => {
          setLoginModalOpen(false);
          setRegisterModalOpen(true);
        }}
        onForgotPassword={() => {
          setLoginModalOpen(false);
          setForgotPasswordModalOpen(true);
        }}
      />
      <RegisterModal 
        open={registerModalOpen} 
        onOpenChange={setRegisterModalOpen}
        onSwitchToLogin={() => {
          setRegisterModalOpen(false);
          setLoginModalOpen(true);
        }}
      />
      <ForgotPasswordModal 
        open={forgotPasswordModalOpen} 
        onOpenChange={setForgotPasswordModalOpen}
        onBackToLogin={() => {
          setForgotPasswordModalOpen(false);
          setLoginModalOpen(true);
        }}
      />
    </div>
  );
}