import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useI18n } from "@/lib/i18n/context";
import { Globe } from "lucide-react";

export function LanguageSelector() {
  const { currentLanguage, setLanguage, availableLanguages, t } = useI18n();

  return (
    <div className="flex items-center space-x-2">
      <Globe className="h-4 w-4 text-gray-500 dark:text-gray-400" />
      <Select value={currentLanguage} onValueChange={setLanguage}>
        <SelectTrigger className="w-40" data-testid="language-selector">
          <SelectValue placeholder={t('common.language')} />
        </SelectTrigger>
        <SelectContent>
          {availableLanguages.map((lang) => (
            <SelectItem key={lang.code} value={lang.code}>
              <div className="flex items-center space-x-2">
                <span>{lang.flag}</span>
                <span>{lang.name}</span>
              </div>
            </SelectItem>
          ))}
        </SelectContent>
      </Select>
    </div>
  );
}