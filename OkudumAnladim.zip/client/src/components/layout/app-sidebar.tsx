import { Link, useLocation } from "wouter";
import { cn } from "@/lib/utils";
import { useI18n } from "@/lib/i18n/context";
import { 
  ArrowRightLeft, 
  FileText, 
  Mic, 
  Volume2, 
  Minimize2, 
  Book, 
  Database, 
  Users, 
  Folder, 
  Languages,
  Settings,
  Key,
  Workflow,
  User
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Separator } from "@/components/ui/separator";

const getNavigation = (t: (key: string) => string) => [
  {
    title: t('nav.mainFunctions'),
    items: [
      { title: t('nav.textTranslation'), href: "/dashboard", icon: ArrowRightLeft },
      { title: t('nav.documentTranslation'), href: "/document-translate", icon: FileText },
      { title: t('nav.audioTranscription'), href: "/audio-transcribe", icon: Mic },
      { title: t('nav.speechToText'), href: "/speech-to-text", icon: Volume2 },
      { title: t('nav.textSummarization'), href: "/summarize", icon: Minimize2 },
    ],
  },
  {
    title: t('nav.languageResources'),
    items: [
      { title: t('nav.glossary'), href: "/glossary", icon: Book },
      { title: t('nav.translationMemory'), href: "/translation-memory", icon: Database },
      { title: "CAT Tools", href: "/cat-tools", icon: Workflow },
    ],
  },
  {
    title: t('nav.collaboration'),
    items: [
      { title: t('nav.teams'), href: "/teams", icon: Users },
      { title: t('nav.projects'), href: "/projects", icon: Folder },
    ],
  },
  {
    title: "Hesap",
    items: [
      { title: "Profil", href: "/profile", icon: User },
      { title: "Fiyatlandırma", href: "/pricing", icon: Key },
    ],
  },
];

export function AppSidebar() {
  const [location] = useLocation();
  const { t } = useI18n();
  const navigation = getNavigation(t);

  return (
    <aside className="w-64 bg-white dark:bg-gray-800 border-r border-gray-200 dark:border-gray-700 flex flex-col">
      {/* Header */}
      <div className="p-6 border-b border-gray-100 dark:border-gray-700">
        <div className="flex items-center space-x-3">
          <div className="w-8 h-8 gradient-primary rounded-lg flex items-center justify-center">
            <Languages className="text-white text-sm" data-testid="logo-icon" />
          </div>
          <div>
            <h1 className="text-xl font-bold text-gray-900 dark:text-white" data-testid="app-title">
              LinguaFlow
            </h1>
            <p className="text-xs text-gray-500 dark:text-gray-400" data-testid="app-subtitle">
              {t('app.subtitle')}
            </p>
          </div>
        </div>
      </div>

      {/* Navigation */}
      <ScrollArea className="flex-1 px-4 py-6">
        <nav className="space-y-6">
          {navigation.map((section) => (
            <div key={section.title}>
              <h3 
                className="px-3 text-xs font-semibold text-gray-500 dark:text-gray-400 uppercase tracking-wider mb-3"
                data-testid={`nav-section-${section.title.toLowerCase().replace(/\s+/g, '-')}`}
              >
                {section.title}
              </h3>
              <div className="space-y-1">
                {section.items.map((item) => {
                  const Icon = item.icon;
                  const isActive = location === item.href;
                  
                  return (
                    <Link key={item.href} href={item.href}>
                      <Button
                        variant={isActive ? "secondary" : "ghost"}
                        className={cn(
                          "w-full justify-start",
                          isActive 
                            ? "bg-blue-50 text-blue-700 dark:bg-blue-900/50 dark:text-blue-300" 
                            : "text-gray-700 dark:text-gray-300 hover:bg-gray-50 dark:hover:bg-gray-700"
                        )}
                        data-testid={`nav-link-${item.title.toLowerCase().replace(/\s+/g, '-')}`}
                      >
                        <Icon className={cn(
                          "mr-3 h-4 w-4",
                          isActive 
                            ? "text-blue-500 dark:text-blue-400" 
                            : "text-gray-400 dark:text-gray-500"
                        )} />
                        {item.title}
                      </Button>
                    </Link>
                  );
                })}
              </div>
            </div>
          ))}
        </nav>
      </ScrollArea>

    </aside>
  );
}
