import { useLocation, useRoute } from "wouter";
import { Button } from "@/components/ui/button";
import { Plus, LogOut, User, Settings, Key, Phone, Mail, Lock } from "lucide-react";
import { Breadcrumb, BreadcrumbItem, BreadcrumbLink, BreadcrumbList, BreadcrumbPage, BreadcrumbSeparator } from "@/components/ui/breadcrumb";
import { useI18n } from "@/lib/i18n/context";
import { useAuth } from "@/lib/auth/context";
import { LanguageSelector } from "@/components/LanguageSelector";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";

const getPageTitles = (t: (key: string) => string): Record<string, string> => ({
  "/dashboard": t('nav.textTranslation'),
  "/": "LinguaFlow",
  "/document-translate": t('nav.documentTranslation'),
  "/audio-transcribe": t('nav.audioTranscription'),
  "/speech-to-text": t('nav.speechToText'),
  "/summarize": t('nav.textSummarization'),
  "/glossary": t('nav.glossary'),
  "/translation-memory": t('nav.translationMemory'),
  "/teams": t('nav.teams'),
  "/projects": t('nav.projects'),
  "/learn": t('nav.languageLearning'),
  "/profile": "Profil",
  "/api-keys": "API Anahtarları",
  "/cat-tools": "CAT Araçları",
});

const getPageSections = (t: (key: string) => string): Record<string, string> => ({
  "/dashboard": t('nav.mainFunctions'),
  "/": "Home",
  "/document-translate": t('nav.mainFunctions'),
  "/audio-transcribe": t('nav.mainFunctions'),
  "/speech-to-text": t('nav.mainFunctions'),
  "/summarize": t('nav.mainFunctions'),
  "/glossary": t('nav.languageResources'),
  "/translation-memory": t('nav.languageResources'),
  "/teams": t('nav.collaboration'),
  "/projects": t('nav.collaboration'),
  "/learn": t('nav.learning'),
  "/profile": "Hesap",
  "/api-keys": "Ayarlar",
  "/cat-tools": t('nav.languageResources'),
});

export function Header() {
  const [location] = useLocation();
  const { t } = useI18n();
  const { user, logout } = useAuth();
  const navigate = (url: string) => window.location.href = url;
  
  const handleLogout = async () => {
    try {
      await logout();
      navigate('/');
    } catch (error) {
      console.error('Logout failed:', error);
    }
  };
  
  const pageTitles = getPageTitles(t);
  const pageSections = getPageSections(t);
  
  const pageTitle = pageTitles[location] || "LinguaFlow";
  const pageSection = pageSections[location] || "Dashboard";

  return (
    <header className="bg-white dark:bg-gray-800 border-b border-gray-200 dark:border-gray-700 px-6 py-4">
      <div className="flex items-center justify-between">
        <div className="flex items-center space-x-4">
          <h2 className="text-2xl font-bold text-gray-900 dark:text-white" data-testid="page-title">
            {pageTitle}
          </h2>
          <Breadcrumb>
            <BreadcrumbList>
              <BreadcrumbItem>
                <BreadcrumbLink 
                  href="/" 
                  className="text-gray-500 dark:text-gray-400"
                  data-testid="breadcrumb-section"
                >
                  {pageSection}
                </BreadcrumbLink>
              </BreadcrumbItem>
              <BreadcrumbSeparator />
              <BreadcrumbItem>
                <BreadcrumbPage 
                  className="text-gray-900 dark:text-white"
                  data-testid="breadcrumb-page"
                >
                  {pageTitle}
                </BreadcrumbPage>
              </BreadcrumbItem>
            </BreadcrumbList>
          </Breadcrumb>
        </div>
        
        <div className="flex items-center space-x-4">
          {/* Language Selector */}
          <LanguageSelector />
          
          <Button 
            onClick={() => navigate('/projects?create=true')}
            className="bg-blue-600 hover:bg-blue-700 text-white"
            data-testid="button-new-project"
          >
            <Plus className="h-4 w-4 mr-2" />
            {t('common.create')} {t('nav.projects').slice(0, -1)}
          </Button>
          
          <div className="flex items-center space-x-2 text-sm text-gray-600 dark:text-gray-400">
            <div className="w-2 h-2 bg-emerald-500 rounded-full" data-testid="status-indicator"></div>
            <span data-testid="status-text">{t('app.apiConnected')}</span>
          </div>
          
          {/* User Menu */}
          {user && (
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button 
                  variant="ghost" 
                  size="sm" 
                  className="flex items-center space-x-2"
                  data-testid="button-user-menu"
                >
                  <User className="h-4 w-4" />
                  <span className="hidden md:block">{user.username}</span>
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end" className="w-56">
                <DropdownMenuLabel className="font-normal">
                  <div className="flex flex-col space-y-1">
                    <p className="text-sm font-medium leading-none">{user.fullName || user.username}</p>
                    <p className="text-xs leading-none text-muted-foreground">{user.email}</p>
                  </div>
                </DropdownMenuLabel>
                <DropdownMenuSeparator />
                <DropdownMenuItem onClick={() => navigate('/profile')}>
                  <User className="mr-2 h-4 w-4" />
                  <span>Profil</span>
                </DropdownMenuItem>
                <DropdownMenuItem onClick={() => navigate('/api-keys')}>
                  <Key className="mr-2 h-4 w-4" />
                  <span>API Anahtarları</span>
                </DropdownMenuItem>
                <DropdownMenuSeparator />
                <DropdownMenuItem 
                  onClick={handleLogout}
                  className="text-red-600 dark:text-red-400"
                  data-testid="button-logout"
                >
                  <LogOut className="mr-2 h-4 w-4" />
                  <span>{t('auth.logout')}</span>
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
          )}
        </div>
      </div>
    </header>
  );
}
