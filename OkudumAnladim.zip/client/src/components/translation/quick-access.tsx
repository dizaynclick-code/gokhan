import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { FileText, Mic, Minimize2, Users } from "lucide-react";
import { Link } from "wouter";

const quickAccessItems = [
  {
    title: "Document",
    description: "Upload & translate files",
    href: "/document-translate",
    icon: FileText,
    color: "hover:border-blue-300 hover:bg-blue-50 dark:hover:bg-blue-900/20",
  },
  {
    title: "Audio",
    description: "Record & transcribe",
    href: "/audio-transcribe",
    icon: Mic,
    color: "hover:border-purple-300 hover:bg-purple-50 dark:hover:bg-purple-900/20",
  },
  {
    title: "Summarize",
    description: "Condense text content",
    href: "/summarize",
    icon: Minimize2,
    color: "hover:border-emerald-300 hover:bg-emerald-50 dark:hover:bg-emerald-900/20",
  },
  {
    title: "Collaborate",
    description: "Share & manage projects",
    href: "/teams",
    icon: Users,
    color: "hover:border-yellow-300 hover:bg-yellow-50 dark:hover:bg-yellow-900/20",
  },
];

export function QuickAccess() {
  return (
    <Card>
      <CardHeader>
        <CardTitle data-testid="quick-access-title">Quick Access</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          {quickAccessItems.map((item) => {
            const Icon = item.icon;
            return (
              <Link key={item.href} href={item.href}>
                <Button
                  variant="outline"
                  className={`h-auto p-4 flex flex-col items-center text-center border-gray-200 dark:border-gray-700 transition-colors ${item.color}`}
                  data-testid={`quick-access-${item.title.toLowerCase()}`}
                >
                  <Icon className="h-8 w-8 text-gray-400 mb-3" />
                  <h4 className="font-medium text-gray-900 dark:text-white mb-1">
                    {item.title}
                  </h4>
                  <p className="text-xs text-gray-500 dark:text-gray-400">
                    {item.description}
                  </p>
                </Button>
              </Link>
            );
          })}
        </div>
      </CardContent>
    </Card>
  );
}
