import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Database, ArrowRight } from "lucide-react";
import { useQuery } from "@tanstack/react-query";
import { useI18n } from "@/lib/i18n/context";

interface MemoryMatch {
  id: string;
  sourceSegment: string;
  targetSegment: string;
  matchScore: number;
}

interface MemoryMatchesProps {
  sourceLang: string;
  targetLang: string;
  searchText?: string;
}

export function MemoryMatches({ sourceLang, targetLang, searchText }: MemoryMatchesProps) {
  const { t } = useI18n();
  const { data: matches = [], isLoading } = useQuery<MemoryMatch[]>({
    queryKey: ["/api/translation-memory", { sourceLang, targetLang, search: searchText }],
    enabled: !!sourceLang && !!targetLang,
  });

  if (isLoading) {
    return (
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center">
            <Database className="h-5 w-5 text-purple-600 mr-2" />
            {t('components.memoryMatches.title')}
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="animate-pulse space-y-3">
            {[1, 2].map((i) => (
              <div key={i} className="h-16 bg-gray-200 dark:bg-gray-700 rounded-lg"></div>
            ))}
          </div>
        </CardContent>
      </Card>
    );
  }

  const getMatchColor = (score: number) => {
    if (score >= 95) return "bg-emerald-50 border-emerald-200 text-emerald-800 dark:bg-emerald-900/20 dark:border-emerald-800 dark:text-emerald-200";
    if (score >= 80) return "bg-yellow-50 border-yellow-200 text-yellow-800 dark:bg-yellow-900/20 dark:border-yellow-800 dark:text-yellow-200";
    return "bg-gray-50 border-gray-200 text-gray-800 dark:bg-gray-800 dark:border-gray-700 dark:text-gray-200";
  };

  const getMatchBadgeColor = (score: number) => {
    if (score >= 95) return "bg-emerald-100 text-emerald-800 dark:bg-emerald-900/50 dark:text-emerald-200";
    if (score >= 80) return "bg-yellow-100 text-yellow-800 dark:bg-yellow-900/50 dark:text-yellow-200";
    return "bg-gray-100 text-gray-800 dark:bg-gray-800 dark:text-gray-200";
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center" data-testid="memory-matches-title">
          <Database className="h-5 w-5 text-purple-600 mr-2" />
          {t('components.memoryMatches.title')}
        </CardTitle>
      </CardHeader>
      <CardContent>
        {matches.length === 0 ? (
          <div className="text-center py-8 text-gray-500 dark:text-gray-400">
            <Database className="h-12 w-12 mx-auto mb-4 opacity-50" />
            <p data-testid="no-matches-message">{t('components.memoryMatches.noMatches')}</p>
          </div>
        ) : (
          <div className="space-y-3">
            {matches.slice(0, 3).map((match) => (
              <div
                key={match.id}
                className={`p-3 border rounded-lg ${getMatchColor(match.matchScore)}`}
                data-testid={`memory-match-${match.id}`}
              >
                <div className="flex items-center justify-between mb-2">
                  <Badge
                    variant="secondary"
                    className={getMatchBadgeColor(match.matchScore)}
                    data-testid={`match-score-${match.id}`}
                  >
                    {match.matchScore}% {t('components.memoryMatches.match')}
                  </Badge>
                  <Button
                    variant="ghost"
                    size="sm"
                    className="h-6 w-6 p-0"
                    data-testid={`button-use-match-${match.id}`}
                  >
                    <ArrowRight className="h-3 w-3" />
                  </Button>
                </div>
                <p className="text-sm" data-testid={`match-text-${match.id}`}>
                  {match.sourceSegment} → {match.targetSegment}
                </p>
              </div>
            ))}
          </div>
        )}
      </CardContent>
    </Card>
  );
}
