import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { LANGUAGES, AI_MODELS } from "@/lib/constants";
import { ArrowRightLeft } from "lucide-react";
import { useI18n } from "@/lib/i18n/context";

interface LanguageSelectorProps {
  sourceLang: string;
  targetLang: string;
  model: string;
  onSourceLangChange: (lang: string) => void;
  onTargetLangChange: (lang: string) => void;
  onModelChange: (model: string) => void;
  onSwapLanguages: () => void;
}

export function LanguageSelector({
  sourceLang,
  targetLang,
  model,
  onSourceLangChange,
  onTargetLangChange,
  onModelChange,
  onSwapLanguages,
}: LanguageSelectorProps) {
  const { t } = useI18n();
  
  return (
    <div className="bg-white dark:bg-gray-800 rounded-xl border border-gray-200 dark:border-gray-700 p-6">
      <div className="flex items-center justify-between mb-4">
        <h3 className="text-lg font-semibold text-gray-900 dark:text-white" data-testid="language-selection-title">
          {t('document.languageSelection')}
        </h3>
        <div className="flex items-center space-x-2">
          <span className="text-sm text-gray-500 dark:text-gray-400">{t('common.model')}:</span>
          <Select value={model} onValueChange={onModelChange}>
            <SelectTrigger className="w-40" data-testid="select-ai-model">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              {AI_MODELS.map((modelOption) => (
                <SelectItem key={modelOption.id} value={modelOption.id}>
                  {modelOption.name}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
      </div>
      
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4 items-center">
        {/* Source Language */}
        <div>
          <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
            {t('document.from')}
          </label>
          <Select value={sourceLang} onValueChange={onSourceLangChange}>
            <SelectTrigger className="w-full" data-testid="select-source-language">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              {LANGUAGES.map((lang) => (
                <SelectItem key={lang.code} value={lang.code}>
                  {lang.flag} {lang.name}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
        
        {/* Swap Button */}
        <div className="flex justify-center">
          <Button
            variant="outline"
            size="icon"
            onClick={onSwapLanguages}
            className="rounded-full"
            data-testid="button-swap-languages"
          >
            <ArrowRightLeft className="h-4 w-4" />
          </Button>
        </div>
        
        {/* Target Language */}
        <div>
          <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
            {t('document.to')}
          </label>
          <Select value={targetLang} onValueChange={onTargetLangChange}>
            <SelectTrigger className="w-full" data-testid="select-target-language">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              {LANGUAGES.map((lang) => (
                <SelectItem key={lang.code} value={lang.code}>
                  {lang.flag} {lang.name}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
      </div>
    </div>
  );
}
