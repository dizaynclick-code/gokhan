import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Book, Check } from "lucide-react";
import { useQuery } from "@tanstack/react-query";
import { useI18n } from "@/lib/i18n/context";

interface GlossaryTerm {
  id: string;
  sourceTerm: string;
  targetTerm: string;
  context?: string;
}

interface GlossaryTermsProps {
  sourceLang: string;
  targetLang: string;
  searchText?: string;
}

export function GlossaryTerms({ sourceLang, targetLang }: GlossaryTermsProps) {
  const { t } = useI18n();
  const { data: terms = [], isLoading } = useQuery<GlossaryTerm[]>({
    queryKey: ["/api/glossary", { sourceLang, targetLang }],
    enabled: !!sourceLang && !!targetLang,
  });

  if (isLoading) {
    return (
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center">
            <Book className="h-5 w-5 text-blue-600 mr-2" />
            {t('components.glossaryTerms.title')}
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="animate-pulse space-y-3">
            {[1, 2].map((i) => (
              <div key={i} className="h-16 bg-gray-200 dark:bg-gray-700 rounded-lg"></div>
            ))}
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center" data-testid="glossary-terms-title">
          <Book className="h-5 w-5 text-blue-600 mr-2" />
          {t('components.glossaryTerms.title')}
        </CardTitle>
      </CardHeader>
      <CardContent>
        {terms.length === 0 ? (
          <div className="text-center py-8 text-gray-500 dark:text-gray-400">
            <Book className="h-12 w-12 mx-auto mb-4 opacity-50" />
            <p data-testid="no-terms-message">{t('components.glossaryTerms.noTerms')}</p>
          </div>
        ) : (
          <div className="space-y-3">
            {terms.slice(0, 3).map((term) => (
              <div
                key={term.id}
                className="p-3 bg-blue-50 dark:bg-blue-900/20 border border-blue-200 dark:border-blue-800 rounded-lg"
                data-testid={`glossary-term-${term.id}`}
              >
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm font-medium text-gray-900 dark:text-white" data-testid={`term-source-${term.id}`}>
                      {term.sourceTerm}
                    </p>
                    <p className="text-xs text-gray-600 dark:text-gray-400" data-testid={`term-target-${term.id}`}>
                      {term.targetTerm}
                    </p>
                  </div>
                  <Badge variant="secondary" className="bg-blue-100 text-blue-800 dark:bg-blue-900/50 dark:text-blue-200">
                    <Check className="h-3 w-3" />
                  </Badge>
                </div>
                {term.context && (
                  <p className="text-xs text-gray-500 dark:text-gray-400 mt-1" data-testid={`term-context-${term.id}`}>
                    {term.context}
                  </p>
                )}
              </div>
            ))}
          </div>
        )}
      </CardContent>
    </Card>
  );
}
