import { useState, useEffect, useRef } from "react";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Label } from "@/components/ui/label";
import { Volume2, Copy, Trash2, Wand2, ThumbsUp, ThumbsDown, Tag } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { useMutation, useQueryClient, useQuery } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { useI18n } from "@/lib/i18n/context";

interface TranslationInterfaceProps {
  sourceLang: string;
  targetLang: string;
  model: string;
}

interface Category {
  code: string;
  name: string;
  description: string;
  keywords: string[];
  tone: string;
}

interface TranslationResponse {
  id: string;
  translatedText: string;
  translationTime: number;
  memoryMatches: Array<{
    sourceSegment: string;
    targetSegment: string;
    matchScore: number;
  }>;
}

export function TranslationInterface({ sourceLang, targetLang, model }: TranslationInterfaceProps) {
  const [sourceText, setSourceText] = useState("");
  const [translatedText, setTranslatedText] = useState("");
  const [translationId, setTranslationId] = useState<string | null>(null);
  const [translationTime, setTranslationTime] = useState<number | null>(null);
  const [selectedCategory, setSelectedCategory] = useState("general");
  const textareaRef = useRef<HTMLTextAreaElement>(null);
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const { t } = useI18n();

  // Fetch categories
  const { data: categories = [], isLoading: categoriesLoading } = useQuery<Category[]>({
    queryKey: ["/api/categories"],
  });

  const translateMutation = useMutation({
    mutationFn: async (data: { text: string; sourceLang: string; targetLang: string; model: string; category: string }) => {
      const response = await apiRequest("POST", "/api/translate", data);
      return response.json() as Promise<TranslationResponse>;
    },
    onSuccess: (data) => {
      setTranslatedText(data.translatedText);
      setTranslationId(data.id);
      setTranslationTime(data.translationTime);
      queryClient.invalidateQueries({ queryKey: ["/api/translations"] });
      toast({
        title: t('dashboard.translationCompletedSuccess'),
        description: `${t('dashboard.completedIn')} ${(data.translationTime / 1000).toFixed(1)}s`,
      });
    },
    onError: (error) => {
      toast({
        title: t('dashboard.translationFailed'),
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const qualityMutation = useMutation({
    mutationFn: async (data: { id: string; quality: number }) => {
      await apiRequest("PATCH", `/api/translations/${data.id}/quality`, { quality: data.quality });
    },
    onSuccess: (_, variables) => {
      toast({
        title: variables.quality >= 4 ? t('dashboard.feedbackThankYou') : t('dashboard.feedbackRecorded'),
        description: t('dashboard.improveTranslations'),
      });
    },
  });

  const handleTranslate = () => {
    if (!sourceText.trim()) {
      toast({
        title: t('dashboard.pleaseEnterText'),
        variant: "destructive",
      });
      return;
    }

    translateMutation.mutate({
      text: sourceText,
      sourceLang,
      targetLang,
      model,
      category: selectedCategory,
    });
  };

  const handleCopy = async () => {
    if (translatedText) {
      await navigator.clipboard.writeText(translatedText);
      toast({
        title: t('dashboard.textCopiedToClipboard'),
      });
    }
  };

  const handleClear = () => {
    setSourceText("");
    setTranslatedText("");
    setTranslationId(null);
    setTranslationTime(null);
    setSelectedCategory("general");
  };

  const selectedCategoryInfo = categories.find(cat => cat.code === selectedCategory);

  const handleQuality = (quality: number) => {
    if (translationId) {
      qualityMutation.mutate({ id: translationId, quality });
    }
  };

  const playAudio = (text: string, lang: string) => {
    if ('speechSynthesis' in window && text) {
      const utterance = new SpeechSynthesisUtterance(text);
      utterance.lang = lang;
      speechSynthesis.speak(utterance);
      toast({
        title: t('dashboard.playingAudio'),
      });
    }
  };

  const handleSourceTextChange = (e: React.ChangeEvent<HTMLTextAreaElement>) => {
    setSourceText(e.target.value);
  };

  // Auto-adjust textarea height without affecting page scroll
  useEffect(() => {
    if (textareaRef.current && sourceText) {
      const textarea = textareaRef.current;
      // Calculate required height based on content
      const lineHeight = parseInt(getComputedStyle(textarea).lineHeight);
      const lines = sourceText.split('\n').length;
      const contentHeight = Math.max(256, lines * lineHeight + 40); // 40px for padding
      
      // Limit max height to prevent page layout issues
      const maxHeight = Math.min(contentHeight, window.innerHeight * 0.6);
      textarea.style.height = maxHeight + 'px';
    } else if (textareaRef.current) {
      textareaRef.current.style.height = '256px';
    }
  }, [sourceText]);

  return (
    <div className="space-y-6">
      {/* Category Selection */}
      <Card>
        <CardHeader className="pb-4">
          <CardTitle className="flex items-center text-lg font-semibold">
            <Tag className="h-5 w-5 mr-2 text-blue-600" />
            İçerik Kategorisi
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="space-y-2">
              <Label htmlFor="category-select">Çeviri kategorisini seçin</Label>
              <Select value={selectedCategory} onValueChange={setSelectedCategory}>
                <SelectTrigger id="category-select" data-testid="select-category">
                  <SelectValue placeholder="Kategori seçin" />
                </SelectTrigger>
                <SelectContent>
                  {categories.map((category) => (
                    <SelectItem key={category.code} value={category.code}>
                      {category.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            {selectedCategoryInfo && (
              <div className="space-y-2">
                <Label className="text-sm font-medium text-gray-500">Kategori Bilgisi</Label>
                <div className="p-3 bg-blue-50 dark:bg-blue-900/20 rounded-lg">
                  <p className="text-sm text-gray-700 dark:text-gray-300 mb-2">
                    {selectedCategoryInfo.description}
                  </p>
                  <div className="text-xs text-blue-600 dark:text-blue-400">
                    <strong>Ton:</strong> {selectedCategoryInfo.tone}
                  </div>
                  {selectedCategoryInfo.keywords.length > 0 && (
                    <div className="text-xs text-blue-600 dark:text-blue-400 mt-1">
                      <strong>Anahtar Kelimeler:</strong> {selectedCategoryInfo.keywords.join(", ")}
                    </div>
                  )}
                </div>
              </div>
            )}
          </div>
        </CardContent>
      </Card>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Source Text */}
        <Card>
        <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-4 sticky top-0 bg-white dark:bg-gray-800 z-10 border-b border-gray-100 dark:border-gray-700">
          <CardTitle className="text-lg font-semibold" data-testid="source-text-title">
            {t('dashboard.sourceText')}
          </CardTitle>
          <div className="flex items-center space-x-2">
            <Button
              onClick={handleTranslate}
              disabled={translateMutation.isPending || !sourceText.trim()}
              className="bg-blue-600 hover:bg-blue-700 text-white"
              data-testid="button-translate"
            >
              {translateMutation.isPending ? (
                <div className="animate-pulse">{t('dashboard.translating')}</div>
              ) : (
                <>
                  <Wand2 className="h-4 w-4 mr-2" />
                  {t('dashboard.translate')}
                </>
              )}
            </Button>
            <Button
              variant="ghost"
              size="sm"
              onClick={() => playAudio(sourceText, sourceLang)}
              disabled={!sourceText}
              data-testid="button-play-source"
            >
              <Volume2 className="h-4 w-4" />
            </Button>
            <Button
              variant="ghost"
              size="sm"
              onClick={handleClear}
              data-testid="button-clear"
            >
              <Trash2 className="h-4 w-4" />
            </Button>
          </div>
        </CardHeader>
        <CardContent>
          <Textarea
            ref={textareaRef}
            placeholder={t('dashboard.enterTextPlaceholder')}
            value={sourceText}
            onChange={handleSourceTextChange}
            className="min-h-64 max-h-96 resize-none overflow-y-auto"
            style={{ scrollBehavior: 'smooth' }}
            data-testid="textarea-source"
          />
          <div className="flex items-center justify-start mt-3 text-sm text-gray-500 dark:text-gray-400">
            <span data-testid="text-character-count">{sourceText.length} {t('dashboard.characters')}</span>
          </div>
        </CardContent>
      </Card>

      {/* Translated Text */}
      <Card>
        <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-4">
          <CardTitle className="text-lg font-semibold" data-testid="translation-title">
            {t('dashboard.translation')}
          </CardTitle>
          <div className="flex items-center space-x-2">
            <Button
              variant="ghost"
              size="sm"
              onClick={() => playAudio(translatedText, targetLang)}
              disabled={!translatedText}
              data-testid="button-play-translation"
            >
              <Volume2 className="h-4 w-4" />
            </Button>
            <Button
              variant="ghost"
              size="sm"
              onClick={handleCopy}
              disabled={!translatedText}
              data-testid="button-copy"
            >
              <Copy className="h-4 w-4" />
            </Button>
          </div>
        </CardHeader>
        <CardContent>
          <div className="relative">
            <div className="min-h-64 p-4 bg-gray-50 dark:bg-gray-900 border border-gray-200 dark:border-gray-700 rounded-lg overflow-y-auto">
              {translatedText ? (
                <div className="text-gray-900 dark:text-white leading-relaxed whitespace-pre-wrap" data-testid="text-translation">
                  {translatedText}
                </div>
              ) : (
                <div className="text-gray-500 dark:text-gray-400 italic" data-testid="text-translation-placeholder">
                  {t('dashboard.translationPlaceholder')}
                </div>
              )}
            </div>
            {translatedText && (
              <div className="absolute top-2 right-2">
                <Badge variant="secondary" className="bg-emerald-100 text-emerald-800 dark:bg-emerald-900 dark:text-emerald-200">
                  <div className="flex items-center space-x-1">
                    <div className="w-2 h-2 bg-emerald-500 rounded-full"></div>
                    <span data-testid="badge-completed">{t('dashboard.completed')}</span>
                  </div>
                </Badge>
              </div>
            )}
          </div>

          {/* Translation Quality Feedback */}
          {translatedText && (
            <div className="flex items-center justify-between mt-4 pt-4 border-t border-gray-100 dark:border-gray-700">
              <div className="flex items-center space-x-4">
                <span className="text-sm text-gray-600 dark:text-gray-400">{t('dashboard.quality')}:</span>
                <div className="flex items-center space-x-2">
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => handleQuality(5)}
                    disabled={qualityMutation.isPending}
                    className="text-emerald-600 hover:text-emerald-700 dark:text-emerald-400"
                    data-testid="button-thumbs-up"
                  >
                    <ThumbsUp className="h-4 w-4" />
                  </Button>
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => handleQuality(2)}
                    disabled={qualityMutation.isPending}
                    className="text-gray-400 hover:text-red-600 dark:hover:text-red-400"
                    data-testid="button-thumbs-down"
                  >
                    <ThumbsDown className="h-4 w-4" />
                  </Button>
                </div>
              </div>
              {translationTime && (
                <div className="text-sm text-gray-500 dark:text-gray-400" data-testid="text-translation-time">
                  {t('dashboard.translationTime')}: {(translationTime / 1000).toFixed(1)}s
                </div>
              )}
            </div>
          )}
        </CardContent>
      </Card>
      </div>
    </div>
  );
}
