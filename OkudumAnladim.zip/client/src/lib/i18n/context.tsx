import { createContext, useContext, useState, useEffect, ReactNode } from 'react';
import { translations, Language } from './translations';

interface I18nContextType {
  currentLanguage: Language;
  setLanguage: (language: Language) => void;
  t: (path: string) => string;
  availableLanguages: Array<{ code: Language; name: string; flag: string }>;
}

const I18nContext = createContext<I18nContextType | undefined>(undefined);

// UI languages (subset of all available languages)
const UI_LANGUAGES = [
  { code: 'en' as Language, name: 'English', flag: '🇺🇸' },
  { code: 'tr' as Language, name: 'Türkçe', flag: '🇹🇷' },
  { code: 'de' as Language, name: 'Deutsch', flag: '🇩🇪' },
  { code: 'ru' as Language, name: 'Русский', flag: '🇷🇺' },
];

export function I18nProvider({ children }: { children: ReactNode }) {
  const [currentLanguage, setCurrentLanguage] = useState<Language>('en');

  // Load saved language preference on mount
  useEffect(() => {
    const savedLanguage = localStorage.getItem('ui-language') as Language;
    if (savedLanguage && translations[savedLanguage]) {
      setCurrentLanguage(savedLanguage);
    } else {
      // Detect browser language
      const browserLang = navigator.language.split('-')[0] as Language;
      if (translations[browserLang]) {
        setCurrentLanguage(browserLang);
      }
    }
  }, []);

  const setLanguage = (language: Language) => {
    setCurrentLanguage(language);
    localStorage.setItem('ui-language', language);
  };

  // Translation function with nested key support
  const t = (path: string): string => {
    const keys = path.split('.');
    let value: any = translations[currentLanguage];
    
    for (const key of keys) {
      if (value && typeof value === 'object' && key in value) {
        value = value[key];
      } else {
        // Fallback to English if translation not found
        value = translations.en;
        for (const fallbackKey of keys) {
          if (value && typeof value === 'object' && fallbackKey in value) {
            value = value[fallbackKey];
          } else {
            return `Missing translation: ${path}`;
          }
        }
        break;
      }
    }
    
    return typeof value === 'string' ? value : `Invalid translation: ${path}`;
  };

  const contextValue: I18nContextType = {
    currentLanguage,
    setLanguage,
    t,
    availableLanguages: UI_LANGUAGES,
  };

  return (
    <I18nContext.Provider value={contextValue}>
      {children}
    </I18nContext.Provider>
  );
}

export function useI18n() {
  const context = useContext(I18nContext);
  if (context === undefined) {
    throw new Error('useI18n must be used within an I18nProvider');
  }
  return context;
}