export const LANGUAGES = [
  { code: "en", name: "English", flag: "🇺🇸" },
  { code: "tr", name: "Turkish", flag: "🇹🇷" },
  { code: "fr", name: "French", flag: "🇫🇷" },
  { code: "nl", name: "Dutch", flag: "🇳🇱" },
  { code: "no", name: "Norwegian", flag: "🇳🇴" },
  { code: "sv", name: "Swedish", flag: "🇸🇪" },
  { code: "de", name: "German", flag: "🇩🇪" },
  { code: "es", name: "Spanish", flag: "🇪🇸" },
  { code: "it", name: "Italian", flag: "🇮🇹" },
  { code: "pt", name: "Portuguese", flag: "🇵🇹" },
  { code: "ru", name: "Russian", flag: "🇷🇺" },
  { code: "ja", name: "Japanese", flag: "🇯🇵" },
  { code: "ko", name: "Korean", flag: "🇰🇷" },
  { code: "zh", name: "Chinese", flag: "🇨🇳" },
  { code: "ar", name: "Arabic", flag: "🇸🇦" },
];

export const AI_MODELS = [
  { id: "gpt-4o", name: "OpenAI GPT-4", provider: "OpenAI" },
  { id: "deepl", name: "DeepL Professional", provider: "DeepL" },
];

export const NAVIGATION_ITEMS = [
  {
    title: "Main Functions",
    items: [
      {
        title: "Text Translation",
        href: "/",
        icon: "exchange",
        description: "Translate text between languages"
      },
      {
        title: "Document Translation",
        href: "/document-translate",
        icon: "file-text",
        description: "Upload and translate documents"
      },
      {
        title: "Audio Transcription",
        href: "/audio-transcribe",
        icon: "mic",
        description: "Convert audio to text"
      },
      {
        title: "Speech to Text",
        href: "/speech-to-text",
        icon: "volume-2",
        description: "Real-time speech recognition"
      },
      {
        title: "Text Summarization",
        href: "/summarize",
        icon: "minimize-2",
        description: "Condense text content"
      }
    ]
  },
  {
    title: "Language Resources",
    items: [
      {
        title: "Glossary",
        href: "/glossary",
        icon: "book",
        description: "Manage custom terminology"
      },
      {
        title: "Translation Memory",
        href: "/translation-memory",
        icon: "database",
        description: "Previous translation segments"
      }
    ]
  },
  {
    title: "Collaboration",
    items: [
      {
        title: "Teams",
        href: "/teams",
        icon: "users",
        description: "Manage team members"
      },
      {
        title: "Projects",
        href: "/projects",
        icon: "folder",
        description: "Organize translation projects"
      }
    ]
  },
  {
    title: "Learning",
    items: [
      {
        title: "Language Learning",
        href: "/learn",
        icon: "graduation-cap",
        description: "AI-powered language lessons"
      }
    ]
  }
];
