import { Switch, Route, useLocation } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import { ThemeProvider } from "@/components/ui/theme-provider";
import { I18nProvider } from "@/lib/i18n/context";
import { AuthProvider } from "@/lib/auth/context";
import { AppSidebar } from "@/components/layout/app-sidebar";
import { Header } from "@/components/layout/header";
import Landing from "@/pages/landing";
import Dashboard from "@/pages/dashboard";
import DocumentTranslate from "@/pages/document-translate";
import AudioTranscribe from "@/pages/audio-transcribe";
import SpeechToText from "@/pages/speech-to-text";
import Summarize from "@/pages/summarize";
import Glossary from "@/pages/glossary";
import TranslationMemory from "@/pages/translation-memory";
import Teams from "@/pages/teams";
import Projects from "@/pages/projects";
import CatTools from "@/pages/cat-tools";
import Profile from "@/pages/profile";
import Pricing from "@/pages/pricing";
import NotFound from "@/pages/not-found";

function Router() {
  return (
    <Switch>
      <Route path="/" component={Landing} />
      <Route path="/dashboard" component={Dashboard} />
      <Route path="/document-translate" component={DocumentTranslate} />
      <Route path="/audio-transcribe" component={AudioTranscribe} />
      <Route path="/speech-to-text" component={SpeechToText} />
      <Route path="/summarize" component={Summarize} />
      <Route path="/glossary" component={Glossary} />
      <Route path="/translation-memory" component={TranslationMemory} />
      <Route path="/teams" component={Teams} />
      <Route path="/projects" component={Projects} />
      <Route path="/cat-tools" component={CatTools} />
      <Route path="/profile" component={Profile} />
      <Route path="/pricing" component={Pricing} />
      <Route component={NotFound} />
    </Switch>
  );
}

function AppLayout() {
  const [location] = useLocation();
  
  // Show landing page without sidebar and header
  if (location === '/') {
    return <Router />;
  }
  
  // Show app layout for other pages
  return (
    <div className="flex h-screen bg-gray-50 dark:bg-gray-900">
      <AppSidebar />
      <main className="flex-1 flex flex-col overflow-hidden">
        <Header />
        <div className="flex-1 overflow-y-auto p-6">
          <Router />
        </div>
      </main>
    </div>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <ThemeProvider defaultTheme="light" storageKey="linguaflow-ui-theme">
        <AuthProvider>
          <I18nProvider>
            <TooltipProvider>
              <Toaster />
              <AppLayout />
            </TooltipProvider>
          </I18nProvider>
        </AuthProvider>
      </ThemeProvider>
    </QueryClientProvider>
  );
}

export default App;
